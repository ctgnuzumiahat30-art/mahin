/* Scent finder quiz: 3 questions → best match (scores come from each perfume's time/season data + simple mood tags) */
(() => {
  const box = document.getElementById('fq'); if (!box) return;
  const { cat, per, size, cart, toast } = ELV;
  const MOOD = { 'vampire-blood': ['bold', 'sweet'], 'creed-aventus': ['fresh', 'bold'], 'adg-profumo': ['fresh', 'elegant'], 'layton': ['sweet', 'bold'], 'valentino': ['elegant', 'sweet'] };
  const Q = [
    { k: 'time', t: 'কোন সময়ের জন্য সুগন্ধি খুঁজছেন?', o: [['day', '☀️ দিনের বেলা / অফিস'], ['evening', '🌆 সন্ধ্যা'], ['night', '🌙 রাত / পার্টি']] },
    { k: 'mood', t: 'কেমন অনুভূতি পছন্দ?', o: [['fresh', '🍋 ফ্রেশ ও পরিষ্কার'], ['sweet', '🍯 মিষ্টি ও উষ্ণ'], ['bold', '🔥 গাঢ় ও সাহসী'], ['elegant', '🎩 মার্জিত ও স্মুথ']] },
    { k: 'season', t: 'বেশি কোন আবহাওয়ায় ব্যবহার করবেন?', o: [['summer', '🌞 গরম / গ্রীষ্ম'], ['autumn', '🍂 মৌসুমি / শরৎ'], ['winter', '❄️ শীত']] },
  ];
  const ans = {}; let step = 0;
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pick = () => cat.perfumes.map((p) => {
    let sc = 0; const why = [];
    if (p.times.includes(ans.time)) { sc += 3; why.push('এই সময়ে মানানসই'); }
    if ((MOOD[p.slug] || []).includes(ans.mood)) { sc += 3; why.push('আপনার পছন্দের মেজাজ'); }
    if (p.seasons.includes(ans.season)) { sc += 2; why.push('এই আবহাওয়ায় ভালো'); }
    return { p, sc, why };
  }).sort((a, b) => b.sc - a.sc);
  function render() {
    if (step < Q.length) {
      const q = Q[step];
      box.innerHTML = `<div class="fq-h"><span>প্রশ্ন ${step + 1}/${Q.length}</span><i style="width:${(step / Q.length) * 100}%"></i></div><h3>${q.t}</h3><div class="fq-o">${q.o.map(([v, l]) => `<button type="button" data-v="${v}">${l}</button>`).join('')}</div>`;
    } else {
      const [a, ...rest] = pick(), S6 = cat.sizes.find((s) => s.id === '6ml');
      box.innerHTML = `<div class="fq-res" style="--bg:${ELV.rgb(a.p.theme.bg)};--glow:${ELV.rgb(a.p.theme.glow)}"><img src="/assets/${a.p.slug}-sm.webp" alt="${esc(a.p.name)}" width="120" height="248"><div><span class="eyebrow">আপনার সেরা ম্যাচ</span><h3>${esc(a.p.name)}</h3><p>${esc(a.p.short)}</p><p class="why">${esc(a.why.join(' · ') || a.p.mood)}</p><div class="fq-b"><button class="btn btn-dark" data-add="${a.p.slug}" type="button">৬ ml কার্টে যোগ করুন · ৳${S6.price}</button><a class="btn btn-ghost" href="/perfume/${a.p.slug}">বিস্তারিত</a></div><p class="alt">আরও মানাতে পারে: ${rest.slice(0, 2).map((r) => `<a href="/perfume/${r.p.slug}">${esc(r.p.name)}</a>`).join(', ')}</p></div></div><button class="link" type="button" data-again>আবার চেষ্টা করুন</button>`;
    }
  }
  box.addEventListener('click', (e) => {
    const o = e.target.closest('[data-v]'), add = e.target.closest('[data-add]');
    if (o) { ans[Q[step].k] = o.dataset.v; step++; render(); }
    else if (add) { cart.add({ slug: add.dataset.add, size: '6ml', qty: 1 }); document.dispatchEvent(new CustomEvent('elv:added', { detail: { value: size['6ml'].price, contents: [{ id: add.dataset.add, quantity: 1 }] } })); toast(per[add.dataset.add].name + ' কার্টে যোগ হয়েছে'); }
    else if (e.target.closest('[data-again]')) { step = 0; render(); }
  });
  render();
})();
