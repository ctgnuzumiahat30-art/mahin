/* 3D scroll showcase — one bottle at a time, centred; colour, huge title, ingredients and particles change as you scroll. */
(() => {
  const sec = document.getElementById('showcase'); if (!sec) return;
  const $ = (s, r = sec) => r.querySelector(s), $$ = (s, r = sec) => [...r.querySelectorAll(s)];
  const st = $('.show-sticky'), N = +sec.dataset.n;
  const words = $$('.sw'), floats = $$('.sf'), bottles = $$('.sb'), bubs = $$('.sbub'), infos = $$('.si'), dots = $$('.dot');
  const stage = $('.show-stage'), counter = $('#show-cur'), badge = $('.sh-badge'), cv = $('.show-fx'), ctx = cv.getContext('2d');
  const FX = sec.dataset.fx.split(',');
  const parse = (k) => sec.dataset[k].split('|').map((s) => s.split(',').map(Number));
  const C1 = parse('c1'), C2 = parse('c2'), C3 = parse('c3');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const lerp = (a, b, t) => a + (b - a) * t;
  const mix = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
  const rgbs = (c) => c.map(Math.round).join(',');

  let target = 0, cur = 0, visible = true, mx = 0, my = 0, smx = 0, smy = 0, W = 0, H = 0, dpr = 1, last = performance.now();
  const t0 = last;

  /* scroll → continuous index; each bottle "rests" for a while before the next arrives */
  function readTarget() {
    const r = sec.getBoundingClientRect(), total = sec.offsetHeight - st.offsetHeight;
    const p = clamp(-r.top / total, 0, 1) * (N - 1);
    if (p >= N - 1) return N - 1;
    const i = Math.floor(p), f = p - i;
    return i + sstep(0.2, 0.8, f);
  }

  /* make each giant title fit the screen width */
  function fitWords() {
    const maxW = st.clientWidth * (innerWidth < 700 ? 0.94 : 0.88);
    words.forEach((w) => {
      w.style.fontSize = '';
      const cw = w.scrollWidth, fs = parseFloat(getComputedStyle(w).fontSize);
      if (cw > maxW) w.style.fontSize = (fs * maxW / cw).toFixed(1) + 'px';
    });
  }
  function resize() {
    dpr = Math.min(devicePixelRatio || 1, 1.6);
    W = st.clientWidth; H = st.clientHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    fitWords();
  }
  addEventListener('resize', resize); resize();
  document.fonts?.ready.then(fitWords);
  addEventListener('pointermove', (e) => { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; }, { passive: true });
  if ('IntersectionObserver' in window) new IntersectionObserver((es) => { visible = es[0].isIntersecting; if (visible) { last = performance.now(); loop(); } }, { rootMargin: '120px' }).observe(sec);

  dots.forEach((d) => d.addEventListener('click', () => {
    const i = +d.dataset.i, total = sec.offsetHeight - st.offsetHeight, top = sec.getBoundingClientRect().top + scrollY;
    scrollTo({ top: top + total * (i / (N - 1)) + 2, behavior: 'smooth' });
  }));

  /* ---------- particles (petals / sparkles / bubbles / embers / dust) ---------- */
  const PN = reduce ? 0 : (innerWidth < 800 ? 30 : 60), ps = [];
  for (let k = 0; k < PN; k++) ps.push({ x: Math.random(), y: Math.random(), s: .5 + Math.random(), v: .3 + Math.random() * .8, ph: Math.random() * 6.28, r: Math.random() });
  function drawFX(time, dt, idx, frac) {
    ctx.clearRect(0, 0, W, H);
    const fx = FX[idx] || 'spark', dip = 1 - .8 * sstep(.25, .5, Math.abs(frac));
    const c = mix(C2[idx], [255, 255, 255], .45), R = c[0] | 0, G = c[1] | 0, B = c[2] | 0;
    ctx.globalCompositeOperation = (fx === 'ember' || fx === 'dust' || fx === 'spark') ? 'lighter' : 'source-over';
    for (const p of ps) {
      const sway = Math.sin(time * .0007 * (.6 + p.v) + p.ph), up = fx === 'petal' ? -1 : 1;
      p.y -= up * dt * .00004 * p.v * (fx === 'ember' ? 2.4 : 1);
      if (p.y < -.05) p.y = 1.05; if (p.y > 1.05) p.y = -.05;
      const x = (p.x + sway * .02 * (fx === 'bubble' ? 2 : 1)) * W, y = p.y * H;
      ctx.beginPath();
      if (fx === 'petal') {
        ctx.save(); ctx.translate(x, y); ctx.rotate(p.ph + time * .0005 * p.v);
        ctx.fillStyle = `rgba(${R},${G},${B},${.5 * dip})`; ctx.beginPath(); ctx.ellipse(0, 0, 5 * p.s + 2, 9 * p.s + 3, 0, 0, 6.283); ctx.fill(); ctx.restore();
      } else if (fx === 'bubble') {
        const r = 3 + p.r * 14 * p.s; ctx.strokeStyle = `rgba(${R},${G},${B},${.55 * dip})`; ctx.lineWidth = 1.2; ctx.arc(x, y, r, 0, 6.283); ctx.stroke();
        ctx.fillStyle = `rgba(255,255,255,${.2 * dip})`; ctx.beginPath(); ctx.arc(x - r * .3, y - r * .3, r * .22, 0, 6.283); ctx.fill();
      } else if (fx === 'ember') {
        const fl = .55 + .45 * Math.sin(time * .008 * p.v + p.ph), r2 = 1.2 + p.s * 2.2, g = ctx.createRadialGradient(x, y, 0, x, y, r2 * 5);
        g.addColorStop(0, `rgba(${R},${G},${B},${.9 * fl * dip})`); g.addColorStop(1, `rgba(${R},${G},${B},0)`);
        ctx.fillStyle = g; ctx.arc(x, y, r2 * 5, 0, 6.283); ctx.fill();
      } else if (fx === 'dust') {
        const tw = Math.max(0, Math.sin(time * .003 * p.v + p.ph)), L = (3 + p.s * 7) * tw;
        ctx.strokeStyle = `rgba(${R},${G},${B},${.9 * tw * dip})`; ctx.lineWidth = 1; ctx.moveTo(x - L, y); ctx.lineTo(x + L, y); ctx.moveTo(x, y - L); ctx.lineTo(x, y + L); ctx.stroke();
      } else {
        const tw = .5 + .5 * Math.sin(time * .004 * p.v + p.ph);
        ctx.fillStyle = `rgba(${R},${G},${B},${.8 * tw * dip})`; ctx.arc(x, y, .8 + p.s * 1.6, 0, 6.283); ctx.fill();
      }
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  /* ---------- main loop ---------- */
  function loop(now) {
    if (!visible) return;
    now = now || performance.now();
    const dt = Math.min(48, now - last); last = now;
    target = readTarget();
    cur = reduce ? target : cur + (target - cur) * (1 - Math.pow(.0016, dt / 1000));
    smx += (mx - smx) * .06; smy += (my - smy) * .06;
    const time = now - t0, vw = innerWidth / 100, mobile = innerWidth < 960, X = mobile ? 78 : 58;

    const i0 = clamp(Math.floor(cur), 0, N - 1), i1 = Math.min(i0 + 1, N - 1), f = cur - i0;
    st.style.setProperty('--c1', rgbs(mix(C1[i0], C1[i1], f)));
    st.style.setProperty('--c2', rgbs(mix(C2[i0], C2[i1], f)));
    st.style.setProperty('--c3', rgbs(mix(C3[i0], C3[i1], f)));
    stage.style.transform = `rotateY(${smx * 6}deg) rotateX(${-smy * 3}deg)`;

    for (let i = 0; i < N; i++) {
      const d = i - cur, a = Math.abs(d), bob = Math.sin(time * .0015 + i) * 7;
      const vb = clamp(1 - a * 1.5, 0, 1), b = bottles[i];
      b.style.opacity = vb; b.style.visibility = vb > .01 ? 'visible' : 'hidden';
      b.style.transform = `translate3d(-50%,${bob}px,${-a * 340}px) translateX(${d * X * vw}px) rotateY(${-d * 72}deg) rotateZ(${d * 4}deg) scale(${1 - a * .1})`;
      const w = words[i], vw2 = clamp(1 - a * 1.25, 0, 1);
      w.style.opacity = vw2; w.style.visibility = vw2 > .01 ? 'visible' : 'hidden';
      w.style.transform = `translate(-50%,-50%) translateX(${-d * 62 * vw}px) scale(${1 + a * .18})`;
      const fl = floats[i], vf = clamp(1 - a * 2, 0, 1);
      fl.style.opacity = vf; fl.style.visibility = vf > .01 ? 'visible' : 'hidden';
      fl.style.transform = `translate3d(${d * 20 * vw + smx * -24}px,${smy * -16}px,0)`;
      const bu = bubs[i], vbb = clamp(1 - a * 2.2, 0, 1);
      bu.style.opacity = vbb; bu.style.visibility = vbb > .01 ? 'visible' : 'hidden';
      bu.style.transform = `translate3d(${d * 34 * vw + smx * 14}px,${smy * 10}px,0) scale(${1 - a * .3})`;
      const inf = infos[i], vi = clamp(1 - a * 2.4, 0, 1);
      inf.style.opacity = vi; inf.style.visibility = vi > .02 ? 'visible' : 'hidden';
      inf.style.transform = `translate3d(0,${d * 48}px,0)`;
    }
    const idx = clamp(Math.round(cur), 0, N - 1);
    dots.forEach((dd, k) => dd.classList.toggle('on', k === idx));
    if (counter) counter.textContent = '0' + (idx + 1);
    if (badge) badge.style.opacity = cur < .06 ? 1 : 0;
    if (PN) drawFX(time, dt, idx, cur - idx);
    requestAnimationFrame(loop);
  }
  loop();
})();
