/* Product page: size → quantity → add to cart */
(() => {
  const { $, $$, cart, per, toast } = ELV;
  const buy = $('#buy'); if (!buy) return;
  const slug = buy.dataset.slug, name = buy.dataset.name; let qty = 1;
  const radios = $$('input[name="size"]', buy);
  const cur = () => { const r = radios.find((x) => x.checked); return { id: r.value, label: r.dataset.label, price: +r.dataset.price, old: +r.dataset.old || 0 }; };
  const set = (id, t) => { const el = $(id); if (el) el.textContent = t; };

  function render() {
    const s = cur();
    set('#qty', qty); set('#pl-price', '৳' + s.price);
    set('#pl-old', s.old ? '৳' + s.old : ''); set('#pl-save', s.old ? '৳' + (s.old - s.price) + ' ছাড়' : '');
    set('#lt-size', s.label); set('#lt-qty', qty); set('#lt-total', '৳' + s.price * qty);
    set('#mb-size', s.label + ' · ' + name); set('#mb-price', '৳' + s.price); set('#mb-old', s.old ? '৳' + s.old : '');
  }
  radios.forEach((r) => r.addEventListener('change', render));
  $('#qty-minus').addEventListener('click', () => { if (qty > 1) { qty--; render(); } });
  $('#qty-plus').addEventListener('click', () => { if (qty < 20) { qty++; render(); } });
  render();

  function add() { const s = cur(); cart.add({ slug, size: s.id, qty }); document.dispatchEvent(new CustomEvent('elv:added', { detail: { value: s.price * qty, contents: [{ id: slug, quantity: qty }] } })); return s; }
  function addAndShow() {
    const s = add();
    $('#ad-text').textContent = `${name} (${s.label}) × ${qty} কার্টে যোগ হয়েছে।`;
    $('#added').classList.add('show');
  }
  $('#add-cart').addEventListener('click', addAndShow);
  $('#mb-add').addEventListener('click', addAndShow);
  $('#buy-now').addEventListener('click', () => { add(); location.href = '/cart'; });

  /* gallery */
  const img = $('#g-img'), scene = $('#pd-scene');
  $$('.thumb').forEach((t) => t.addEventListener('click', () => {
    $$('.thumb').forEach((x) => x.classList.remove('on')); t.classList.add('on');
    if (t.dataset.src) { img.src = t.dataset.src; img.hidden = false; scene.style.visibility = 'hidden'; } else { img.hidden = true; scene.style.visibility = ''; }
  }));
  const gm = $('#g-main');
  gm.addEventListener('pointermove', (e) => { const r = gm.getBoundingClientRect(); scene.style.setProperty('--mx', (((e.clientX - r.left) / r.width - .5) * 2).toFixed(2)); scene.style.setProperty('--my', (((e.clientY - r.top) / r.height - .5) * 2).toFixed(2)); });
  gm.addEventListener('pointerleave', () => { scene.style.setProperty('--mx', 0); scene.style.setProperty('--my', 0); });

  /* mobile sticky bar hides while the main buy buttons are visible */
  const mbar = $('.mbar'), cta = $('.cta-row');
  if (mbar && cta && 'IntersectionObserver' in window) new IntersectionObserver((es) => mbar.classList.toggle('hide', es[0].isIntersecting), { threshold: .4 }).observe(cta);
  /* add-ons */
  const XK = 'elv_extra', gift = $('#ao-gift');
  const rd = () => { try { return JSON.parse(localStorage.getItem(XK)) || {}; } catch { return {}; } };
  if (gift) { gift.checked = !!rd().gift; gift.addEventListener('change', () => { const x = rd(); x.gift = gift.checked; try { localStorage.setItem(XK, JSON.stringify(x)); } catch { /* ignore */ } toast(gift.checked ? 'গিফট র‍্যাপ যোগ হয়েছে — কার্টে মেসেজ লিখতে পারবেন' : 'গিফট র‍্যাপ বাদ দেওয়া হয়েছে'); }); }
  $$('[data-sample]').forEach((b) => b.addEventListener('click', () => { cart.add({ slug: b.dataset.sample, size: '3ml', qty: 1 }); toast(per[b.dataset.sample].name + ' (৩ ml স্যাম্পল) কার্টে যোগ হয়েছে'); }));
  $('#ao-set')?.addEventListener('click', () => { Object.keys(per).forEach((k) => cart.add({ slug: k, size: '6ml', qty: 1 })); location.href = '/cart'; });
  ELV.track && ELV.track('ViewContent', { content_ids: [slug], content_name: name, currency: 'BDT' });

  /* reviews (verified buyers only) */
  const rv = $('#rv-box');
  if (rv) ELV.api('/reviews/' + slug).then((r) => {
    const esc = (t) => String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
    rv.innerHTML = r.count ? `<div class="rv-sum"><b>${r.avg}</b><span class="stars">${stars(Math.round(r.avg))}</span><small>${r.count}টি ভেরিফাইড রিভিউ</small></div>` + r.reviews.map((x) => `<article class="rv"><div class="stars">${stars(x.rating)}</div><p>${esc(x.body || '')}</p><small>${esc(x.author)} · ✔ ভেরিফাইড ক্রেতা</small></article>`).join('') : '<p class="rv-empty">এখনও কোনো রিভিউ নেই। ডেলিভারি পাওয়ার পর ক্রেতারা “আমার অর্ডার” পেজ থেকে রিভিউ দিতে পারেন — শুধু আসল ক্রেতাদের রিভিউই এখানে দেখানো হয়।</p>';
  }).catch(() => { rv.textContent = ''; });
  if (!per[slug]) toast('পণ্যটি পাওয়া যায়নি', 'err');
})();
