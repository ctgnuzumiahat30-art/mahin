/* Account: order history with LIVE status (polled), saved cart */
(() => {
  const { $, $$, api, per, size, boot, toast } = ELV;
  const ST = Object.fromEntries(boot.statuses.map((s) => [s.key, s]));
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  const STEPS = boot.statuses.filter((s) => s.step >= 0).sort((a, b) => a.step - b.step);
  const fmt = (iso) => new Date(iso).toLocaleString('bn-BD', { dateStyle: 'medium', timeStyle: 'short' });
  const box = $('#orders'); let sig = {}, open = new Set(), timer, loaded = false;

  function card(o) {
    const s = ST[o.status] || ST.pending;
    const last = [...o.events].reverse().find((e) => e.status === o.status);
    const lastStep = (() => { let m = 0; for (const e of o.events) if (ST[e.status] && ST[e.status].step > m) m = ST[e.status].step; return m; })();
    const tl = s.step >= 0 ? `<ol class="tl">${STEPS.map((x) => `<li class="${x.step < s.step ? 'done' : x.step === s.step ? 'cur' : ''}${x.step === 5 ? ' final' : ''}"><span class="dotc">${CHECK}</span>${esc(x.bn.replace(/ \(.*\)/, ''))}</li>`).join('')}</ol>` : '';
    const alert = s.step < 0 ? `<div class="ord-alert tone-${s.tone}">${esc(s.bn)}${last && last.note ? ' — ' + esc(last.note) : ''}</div>` : '';
    const track = o.trackingId || o.courier ? `<div class="ord-track">${o.courier ? 'কুরিয়ার: <b>' + esc(o.courier) + '</b> ' : ''}${o.trackingId ? 'ট্র্যাকিং আইডি: <b>' + esc(o.trackingId) + '</b>' : ''}</div>` : '';
    const items = o.items.map((i) => `<div class="oi"><span class="thumbs" style="--glow:${per[i.slug] ? ELV.rgb(per[i.slug].theme.glow) : '200,200,200'};--bg:${per[i.slug] ? ELV.rgb(per[i.slug].theme.bg) : '240,240,240'}"><img src="/assets/${esc(i.slug)}-sm.webp" alt="" width="22" height="44"></span><div><b>${esc(i.name)}</b><small>${esc(i.sizeLabel)} × ${i.qty}</small></div><span>৳${i.lineTotal}</span>${o.status === 'delivered' ? (o.reviewed || []).includes(i.slug) ? '<small class="rv-done">✔ রিভিউ দিয়েছেন</small>' : `<button type="button" class="link rv-btn" data-rv="${esc(o.invoice)}|${esc(i.slug)}">রিভিউ দিন</button>` : ''}</div>`).join('');
    const hist = [...o.events].reverse().map((e) => `<div><time>${fmt(e.at)}</time><span>${esc((ST[e.status] || {}).bn || e.status)}${e.note ? ' · ' + esc(e.note) : ''}</span></div>`).join('');
    return `<article class="ord" id="${esc(o.invoice)}" data-inv="${esc(o.invoice)}">
      <div class="ord-h"><div><h3>${esc(o.invoice)}</h3><small>${fmt(o.createdAt)}</small></div><span class="st tone-${s.tone}">${esc(s.bn)}</span></div>
      ${tl}${alert}${track}
      <div class="ord-body"><div class="ord-items">${items}</div>
        <div class="ord-sum"><div><span>পণ্যের দাম</span><span>৳${o.subtotal}</span></div><div><span>ডেলিভারি (${esc(o.customer.district)})</span><span>৳${o.delivery.fee}</span></div><div class="tot"><span>সর্বমোট (COD)</span><span>৳${o.total}</span></div>
          <div class="ord-addr">${esc(o.customer.name)} · ${esc(o.customer.phone)}<br>${esc(o.customer.address)}</div></div></div>
      <div class="ord-f"><button type="button" class="btn btn-ghost btn-sm" data-hist>আপডেটের ইতিহাস</button><button type="button" class="btn btn-ghost btn-sm" data-again="${esc(o.invoice)}">আবার অর্ডার করুন</button></div>
      <div class="hist${open.has(o.invoice) ? ' open' : ''}">${hist}</div></article>`;
  }

  let data = [];
  function paint(orders, flash) {
    data = orders; $('#t-orders').textContent = orders.length;
    if (!orders.length) { box.innerHTML = '<div class="acc-empty"><p>এখনও কোনো অর্ডার নেই।</p><a class="btn btn-dark" href="/#collection">সুগন্ধি দেখুন</a></div>'; return; }
    box.innerHTML = orders.map(card).join('');
    if (flash) for (const o of orders) if (sig[o.invoice] && sig[o.invoice] !== o.status + o.updatedAt) $('#' + CSS.escape(o.invoice))?.classList.add('flash');
    for (const o of orders) sig[o.invoice] = o.status + o.updatedAt;
  }
  async function poll(manual) {
    try {
      const r = await api('/orders'); const prev = { ...sig };
      const changed = loaded && r.orders.some((o) => prev[o.invoice] && prev[o.invoice] !== o.status + o.updatedAt);
      if (box.querySelector('.rv-form')) { for (const o of r.orders) sig[o.invoice] = o.status + o.updatedAt; } else paint(r.orders, loaded);
      loaded = true;
      if (changed) toast('আপনার অর্ডারের স্ট্যাটাস আপডেট হয়েছে');
      $('#live-upd').textContent = 'সর্বশেষ আপডেট: ' + new Date().toLocaleTimeString('bn-BD');
      if (manual) toast('আপডেট হয়েছে');
    } catch (e) { if (e.status === 401) location.reload(); else $('#live-upd').textContent = 'সংযোগ সমস্যা — আবার চেষ্টা হচ্ছে…'; }
  }
  const loop = () => { clearInterval(timer); timer = setInterval(() => { if (!document.hidden) poll(); }, 15000); };
  document.addEventListener('visibilitychange', () => { if (!document.hidden && ELV.user) poll(); });
  $('#live-ref').addEventListener('click', () => poll(true));

  box.addEventListener('click', (e) => {
    const h = e.target.closest('[data-hist]'), a = e.target.closest('[data-again]');
    if (h) { const c = h.closest('.ord'), el = $('.hist', c); el.classList.toggle('open'); el.classList.contains('open') ? open.add(c.dataset.inv) : open.delete(c.dataset.inv); }
    if (a) { const o = data.find((x) => x.invoice === a.dataset.again); if (o) { o.items.forEach((i) => ELV.cart.add({ slug: i.slug, size: i.size, qty: i.qty })); location.href = '/cart'; } }
  });

  box.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-rv]'), sub = e.target.closest('[data-rvsend]');
    if (b) { const [inv, slug] = b.dataset.rv.split('|'); const f = document.createElement('form'); f.className = 'rv-form'; f.dataset.inv = inv; f.dataset.slug = slug;
      f.innerHTML = '<select name="r" aria-label="রেটিং"><option value="5">★★★★★ চমৎকার</option><option value="4">★★★★ ভালো</option><option value="3">★★★ ঠিকঠাক</option><option value="2">★★ মোটামুটি</option><option value="1">★ ভালো লাগেনি</option></select><input name="t" maxlength="400" placeholder="আপনার অভিজ্ঞতা লিখুন (ঐচ্ছিক)"><button type="submit" class="btn btn-dark btn-sm">জমা দিন</button>'; b.replaceWith(f); f.querySelector('input').focus(); }
    void sub;
  });
  box.addEventListener('submit', async (e) => {
    const f = e.target.closest('.rv-form'); if (!f) return; e.preventDefault();
    try { await api('/reviews', { method: 'POST', body: { invoice: f.dataset.inv, slug: f.dataset.slug, rating: +f.elements.r.value, body: f.elements.t.value } }); toast('রিভিউ দেওয়ার জন্য ধন্যবাদ!'); poll(); } catch (err) { toast(err.message, 'err'); }
  });

  /* ---------- saved cart ---------- */
  function paintCart() {
    const items = ELV.cart.items(), c = $('#acc-cart'); $('#t-cart').textContent = ELV.cart.count();
    c.innerHTML = items.length ? items.map((i) => { const p = per[i.slug], s = size[i.size]; return `<article class="ci" style="--bg:${ELV.rgb(p.theme.bg)};--glow:${ELV.rgb(p.theme.glow)}"><a class="ci-img" href="/perfume/${p.slug}"><img src="/assets/${p.slug}-sm.webp" alt="" width="46" height="94"></a><div><h3>${esc(p.name)}</h3><div class="meta">${s.label}</div><div class="unit">৳${s.price} × ${i.qty}</div></div><div class="ci-r"><strong>৳${s.price * i.qty}</strong></div></article>`; }).join('') + '<a class="btn btn-dark" href="/cart">চেকআউটে যান</a>' : '<div class="acc-empty"><p>সেভ করা কার্ট খালি।</p><a class="btn btn-dark" href="/#collection">সুগন্ধি দেখুন</a></div>';
  }
  document.addEventListener('elv:cart', paintCart);

  /* ---------- tabs / auth ---------- */
  $$('.acc-tabs button').forEach((b) => b.addEventListener('click', () => {
    $$('.acc-tabs button').forEach((x) => x.classList.toggle('on', x === b));
    $('#tab-orders').hidden = b.dataset.tab !== 'orders'; $('#tab-cart').hidden = b.dataset.tab !== 'cart';
  }));
  $('#acc-login').addEventListener('click', ELV.openLogin);
  $('#acc-logout').addEventListener('click', ELV.logout);
  ELV.onAuth((u) => {
    $('#acc-guest').hidden = !!u; $('#acc-user').hidden = !u;
    if (!u) { clearInterval(timer); return; }
    $('#acc-name').textContent = u.name || u.email; $('#acc-email').textContent = u.email;
    const av = $('#acc-av'); av.textContent = ''; if (u.picture) { const im = document.createElement('img'); im.src = u.picture; im.alt = ''; im.referrerPolicy = 'no-referrer'; im.width = im.height = 56; av.appendChild(im); } else av.textContent = (u.name || u.email)[0].toUpperCase();
    paintCart(); poll().then(() => { if (location.hash) $('#' + CSS.escape(location.hash.slice(1)))?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }); loop();
  });
})();
