/* Elvaren — shared client: boot data, auth (Google), cart (local + synced), header, toasts */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const boot = JSON.parse($('#boot').textContent);
  const cat = boot.catalog;
  const per = Object.fromEntries(cat.perfumes.map((p) => [p.slug, p]));
  const size = Object.fromEntries(cat.sizes.map((s) => [s.id, s]));
  const hexRgb = (h) => [0, 2, 4].map((i) => parseInt(h.replace('#', '').slice(i, i + 2), 16)).join(',');
  const ELV = (window.ELV = { boot, cat, per, size, user: null, profile: null, authReady: false, rgb: hexRgb, $, $$ });
  const listeners = [];

  /* ---------- API ---------- */
  ELV.api = async (path, { method = 'GET', body } = {}) => {
    let res;
    try {
      res = await fetch('/api' + path, { method, credentials: 'same-origin', headers: body ? { 'content-type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    } catch { const e = new Error('ইন্টারনেট সংযোগ নেই — আবার চেষ্টা করুন'); e.network = true; throw e; }
    let data = null; try { data = await res.json(); } catch { /* not json */ }
    if (!res.ok || (data && data.ok === false)) { const e = new Error((data && data.error) || 'কিছু একটা সমস্যা হয়েছে'); e.status = res.status; e.data = data; throw e; }
    return data;
  };

  /* ---------- toast ---------- */
  ELV.toast = (msg, type = '') => {
    const box = $('#toasts'); if (!box) return;
    const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 3800);
  };

  /* ---------- cart ---------- */
  const KEY = 'elv_cart_v2';
  let memCart = [];
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  function clean(list) {
    const m = new Map();
    for (const it of Array.isArray(list) ? list : []) {
      if (!per[it?.slug] || !size[it?.size]) continue;
      const k = it.slug + '|' + it.size;
      m.set(k, { slug: it.slug, size: it.size, qty: clamp((m.get(k)?.qty || 0) + (Math.floor(+it.qty) || 1), 1, 20) });
    }
    return [...m.values()].slice(0, 10);
  }
  const readLocal = () => { try { return clean(JSON.parse(localStorage.getItem(KEY))); } catch { return clean(memCart); } };
  let pushT;
  function writeLocal(items) {
    memCart = items;
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* private mode */ }
    document.dispatchEvent(new CustomEvent('elv:cart'));
    paintCount();
    if (ELV.user) { clearTimeout(pushT); pushT = setTimeout(() => ELV.api('/cart', { method: 'PUT', body: { items } }).catch(() => {}), 500); }
  }
  const Cart = (ELV.cart = {
    items: readLocal,
    count: () => readLocal().reduce((a, i) => a + i.qty, 0),
    subtotal: () => readLocal().reduce((a, i) => a + i.qty * size[i.size].price, 0),
    add(it) { writeLocal(clean([...readLocal(), { qty: 1, ...it }])); },
    set(slug, sz, qty) { writeLocal(readLocal().map((i) => (i.slug === slug && i.size === sz ? { ...i, qty: clamp(qty, 1, 20) } : i))); },
    remove(slug, sz) { writeLocal(readLocal().filter((i) => !(i.slug === slug && i.size === sz))); },
    clear() { writeLocal([]); },
    async pull() {   // after login: merge the saved cart with whatever is in this browser
      try {
        const r = await ELV.api('/cart'), m = new Map();
        for (const i of [...r.items, ...readLocal()]) { const k = i.slug + '|' + i.size; m.set(k, { ...i, qty: Math.max(m.get(k)?.qty || 0, i.qty) }); }
        const merged = clean([...m.values()]);
        memCart = merged; try { localStorage.setItem(KEY, JSON.stringify(merged)); } catch { /* ignore */ }
        await ELV.api('/cart', { method: 'PUT', body: { items: merged } });
        document.dispatchEvent(new CustomEvent('elv:cart')); paintCount();
      } catch { /* offline — keep local */ }
    },
  });
  function paintCount(bump) {
    const b = $('#cart-count'); if (!b) return;
    const n = Cart.count(); b.textContent = n; b.hidden = !n;
    if (bump) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); }
  }
  let lastN = Cart.count();
  document.addEventListener('elv:cart', () => { const n = Cart.count(); paintCount(n > lastN); lastN = n; });
  paintCount();
  window.addEventListener('storage', (e) => { if (e.key === KEY) { document.dispatchEvent(new CustomEvent('elv:cart')); paintCount(); } });

  /* ---------- auth ---------- */
  ELV.onAuth = (fn) => { listeners.push(fn); if (ELV.authReady) fn(ELV.user); };
  const emit = () => listeners.forEach((fn) => { try { fn(ELV.user); } catch (e) { console.error(e); } });
  const modal = $('#login-modal'), authBtn = $('#auth-btn');
  let menu;

  function paintAuth() {
    const u = ELV.user;
    authBtn.classList.toggle('in', !!u);
    if (!u) { authBtn.innerHTML = '<span class="lbl">Sign in</span>'; menu?.classList.remove('show'); return; }
    const first = (u.name || u.email).split(' ')[0];
    authBtn.innerHTML = (u.picture ? `<img class="av" src="${u.picture}" alt="" referrerpolicy="no-referrer" width="28" height="28">` : `<span class="av" style="display:grid;place-items:center;background:#16110d;color:#f3e3c3;font-weight:700;margin-left:0">${first[0].toUpperCase()}</span>`) + `<span class="lbl"></span>`;
    $('.lbl', authBtn).textContent = first;
    if (!menu) { menu = document.createElement('div'); menu.className = 'user-menu'; authBtn.parentElement.appendChild(menu); }
    menu.innerHTML = '<div class="um-h"></div><a href="/account">আমার অর্ডার ও ট্র্যাকিং</a><a href="/cart">আমার কার্ট</a><button type="button" data-logout>লগআউট</button>';
    $('.um-h', menu).textContent = u.email;
  }
  authBtn.addEventListener('click', (e) => { e.stopPropagation(); if (!ELV.user) return ELV.openLogin(); menu.classList.toggle('show'); });
  document.addEventListener('click', (e) => {
    if (menu && !menu.contains(e.target)) menu.classList.remove('show');
    if (e.target.closest('[data-logout]')) ELV.logout();
  });

  let gInit = false;
  function initGoogle() {
    if (gInit) return; gInit = true;
    if (!boot.google) { $('#g-missing').hidden = false; return; }
    let tries = 0;
    const t = setInterval(() => {
      if (window.google?.accounts?.id) {
        clearInterval(t);
        google.accounts.id.initialize({ client_id: boot.google, callback: onCredential, ux_mode: 'popup' });
        google.accounts.id.renderButton($('#g-btn-slot'), { theme: 'outline', size: 'large', shape: 'pill', text: 'continue_with', logo_alignment: 'left', width: 290 });
      } else if (++tries > 120) { clearInterval(t); $('#g-btn-slot').textContent = 'Google লোড হয়নি — ইন্টারনেট সংযোগ দেখুন'; }
    }, 100);
  }
  async function onCredential(resp) { await finishLogin(() => ELV.api('/auth/google', { method: 'POST', body: { credential: resp.credential } })); }
  async function finishLogin(call) {
    try {
      const r = await call();
      ELV.user = r.user; ELV.profile = r.profile; modal.classList.remove('show');
      await Cart.pull(); paintAuth(); emit();
      ELV.toast('স্বাগতম, ' + (r.user.name || '').split(' ')[0] + '!');
    } catch (e) { ELV.toast(e.message, 'err'); }
  }
  ELV.openLogin = () => { modal.classList.add('show'); initGoogle(); if (boot.devAuth) $('#dev-login').hidden = false; };
  ELV.logout = async () => {
    try { await ELV.api('/auth/logout', { method: 'POST', body: {} }); } catch { /* ignore */ }
    ELV.user = null; ELV.profile = null; Cart.clear(); paintAuth(); emit(); ELV.toast('লগআউট হয়েছে');
    if (/^\/(account)/.test(location.pathname)) location.reload();
  };
  $('#dev-login')?.addEventListener('submit', (e) => {
    e.preventDefault(); const f = new FormData(e.target);
    finishLogin(() => ELV.api('/auth/dev', { method: 'POST', body: { email: f.get('email'), name: f.get('name') } }));
  });

  ELV.ready = (async () => {
    try { const r = await ELV.api('/auth/me'); ELV.user = r.user; ELV.profile = r.profile; if (r.user) await Cart.pull(); } catch { /* guest */ }
    ELV.authReady = true; paintAuth(); emit();
  })();

  /* ---------- modals ---------- */
  document.addEventListener('click', (e) => {
    const m = e.target.closest('.modal');
    if (m && (e.target === m || e.target.closest('[data-close]'))) m.classList.remove('show');
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { $$('.modal.show').forEach((m) => m.classList.remove('show')); menu?.classList.remove('show'); } });

  /* ---------- newsletter / lead capture ---------- */
  $('#news-form')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.target, m = $('#news-msg');
    try { const r = await ELV.api('/leads', { method: 'POST', body: { email: $('#news-email').value, website: f.elements.website.value, source: 'footer' } }); m.textContent = r.message; m.className = 'news-msg ok'; f.reset(); }
    catch (err) { m.textContent = err.message; m.className = 'news-msg bad'; }
  });

  /* ---------- quick add ---------- */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-quick]'); if (!b) return;
    Cart.add({ slug: b.dataset.quick, size: '6ml', qty: 1 });
    document.dispatchEvent(new CustomEvent('elv:added', { detail: { value: size['6ml'].price, contents: [{ id: b.dataset.quick, quantity: 1 }] } }));
    ELV.toast(per[b.dataset.quick].name + ' (৬ ml) কার্টে যোগ হয়েছে');
  });

  /* ---------- header / reveal ---------- */
  const header = $('.site-header');
  const onScroll = () => header.classList.toggle('scrolled', scrollY > 8);
  onScroll(); addEventListener('scroll', onScroll, { passive: true });
  const burger = $('.burger');
  burger?.addEventListener('click', () => { const o = document.body.classList.toggle('menu-open'); burger.setAttribute('aria-expanded', o); });
  $$('#menu a').forEach((a) => a.addEventListener('click', () => document.body.classList.remove('menu-open')));
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.12 });
    $$('.reveal').forEach((el) => io.observe(el));
  } else $$('.reveal').forEach((el) => el.classList.add('in'));
})();
