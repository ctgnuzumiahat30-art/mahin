/* Cart page: items, login gate, validated order form, live delivery fee */
(() => {
  const { $, $$, cart, per, size, cat, api, toast } = ELV;
  const D = cat.delivery, bn = (n) => '৳' + n;
  const itemsBox = $('#cart-items'), grid = $('#cart-grid'), empty = $('#cart-empty');
  const form = $('#order-form'), gate = $('#login-gate'), msg = $('#form-msg'), btn = $('#submit-btn');
  const F = { name: $('#f-name'), phone: $('#f-phone'), whatsapp: $('#f-wa'), email: $('#f-email'), district: $('#f-dist'), address: $('#f-addr'), note: $('#f-note') };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let token = (crypto.randomUUID && crypto.randomUUID()) || String(Date.now()) + Math.random().toString(16).slice(2);
  let busy = false;

  /* ---------- items ---------- */
  function renderItems() {
    const items = cart.items();
    empty.hidden = items.length > 0; grid.hidden = items.length === 0;
    itemsBox.innerHTML = items.map((i) => {
      const p = per[i.slug], s = size[i.size];
      return `<article class="ci" style="--bg:${ELV.rgb(p.theme.bg)};--glow:${ELV.rgb(p.theme.glow)}">
        <a class="ci-img" href="/perfume/${p.slug}"><img src="/assets/${p.slug}-sm.webp" alt="${esc(p.name)}" width="46" height="94"></a>
        <div><h3>${esc(p.name)}</h3><div class="meta">${s.label}</div><div class="unit">${bn(s.price)} × ${i.qty}</div></div>
        <div class="ci-r"><strong>${bn(s.price * i.qty)}</strong>
          <div class="stepper" data-s="${p.slug}|${i.size}"><button type="button" data-d="-1" aria-label="কমান">−</button><output>${i.qty}</output><button type="button" data-d="1" aria-label="বাড়ান">+</button></div>
          <button type="button" class="link" data-rm="${p.slug}|${i.size}">মুছে ফেলুন</button></div></article>`;
    }).join('');
    upsell(); totals();
  }
  itemsBox.addEventListener('click', (e) => {
    const rm = e.target.closest('[data-rm]'), st = e.target.closest('.stepper button');
    if (rm) { const [a, b] = rm.dataset.rm.split('|'); cart.remove(a, b); }
    else if (st) { const [a, b] = st.parentElement.dataset.s.split('|'); const it = cart.items().find((x) => x.slug === a && x.size === b); if (it) { const q = it.qty + +st.dataset.d; q < 1 ? cart.remove(a, b) : cart.set(a, b, q); } }
  });
  document.addEventListener('elv:cart', renderItems);

  /* ---------- extras (coupon / gift) kept across pages ---------- */
  const XK = 'elv_extra';
  const ex = (() => { try { return JSON.parse(localStorage.getItem(XK)) || {}; } catch { return {}; } })();
  const saveEx = () => { try { localStorage.setItem(XK, JSON.stringify(ex)); } catch { /* ignore */ } };
  const O = cat.offers || {};

  /* ---------- totals: the server computes everything (same maths as the real order) ---------- */
  let Q = null, qT, qSeq = 0;
  const show = (id, on) => { const e = $(id); if (e) e.hidden = !on; };
  function paintQuote() {
    const q = Q, sub = cart.subtotal(), dist = F.district.value;
    $('#sum-count').textContent = cart.count(); $('#sum-sub').textContent = bn(q ? q.subtotal : sub);
    show('#row-bundle', q && q.bundle.off > 0); if (q && q.bundle.off) { $('#lbl-bundle').textContent = q.bundle.label || 'বান্ডেল ছাড়'; $('#sum-bundle').textContent = '−' + bn(q.bundle.off); }
    show('#row-coupon', q && q.coupon && q.coupon.off > 0); if (q && q.coupon) { $('#lbl-coupon').textContent = 'কুপন ' + q.coupon.code; $('#sum-coupon').textContent = '−' + bn(q.coupon.off); }
    show('#row-gift', q && q.giftWrapFee > 0); if (q && q.giftWrapFee) $('#sum-gift').textContent = '+' + bn(q.giftWrapFee);
    const d = q && q.delivery;
    $('#sum-zone').textContent = !d ? '' : d.free ? '(ফ্রি ডেলিভারি 🎉)' : D.insideDistricts.includes(dist) ? '(ঢাকা/চট্টগ্রাম)' : '(ঢাকা-চট্টগ্রামের বাইরে)';
    $('#sum-fee').textContent = !d ? 'জেলা বাছুন' : d.free ? '৳0 (ছিল ' + bn(d.raw) + ')' : bn(d.fee);
    $('#sum-tot').textContent = bn(q ? q.total : sub);
    const cm = $('#coupon-msg');
    if (q && q.couponError) { cm.textContent = q.couponError; cm.className = 'cmsg bad'; }
    else if (q && q.coupon) { cm.textContent = `✓ ${q.coupon.label || 'কুপন প্রয়োগ হয়েছে'}${q.coupon.pending ? ' (লগইন করলে যাচাই হবে)' : ''}`; cm.className = 'cmsg ok'; }
    else { cm.textContent = ''; cm.className = 'cmsg'; }
    // free-delivery progress + bundle nudge
    const fd = $('#fd-bar'), thr = O.freeDeliveryOver || 0;
    if (q && thr) {
      const pct = Math.min(100, Math.round((q.net / thr) * 100));
      $('#fd-fill').style.width = pct + '%';
      let t = q.freeDeliveryLeft > 0 ? `আর ${bn(q.freeDeliveryLeft)} যোগ করলেই <b>ডেলিভারি ফ্রি</b> 🚚` : '🎉 অভিনন্দন! আপনার ডেলিভারি ফ্রি';
      if (q.bundle.next) t += ` · আরও ${q.bundle.next.need}টি নিলে ${bn(q.bundle.next.off)} ছাড়`;
      $('#fd-text').innerHTML = t; fd.classList.toggle('done', q.freeDeliveryLeft <= 0);
    }
  }
  function refreshQuote() {
    paintQuote(); clearTimeout(qT);
    const items = cart.items(); if (!items.length) { Q = null; return; }
    const seq = ++qSeq;
    qT = setTimeout(async () => {
      try { const r = await api('/quote', { method: 'POST', body: { items, district: F.district.value, coupon: ex.coupon || '', giftWrap: !!ex.gift } }); if (seq === qSeq) { Q = r.quote; paintQuote(); } } catch { /* keep local numbers */ }
    }, 120);
  }
  const totals = refreshQuote;
  F.district.addEventListener('change', totals);
  const cInput = $('#f-coupon'), gift = $('#f-gift');
  cInput.value = ex.coupon || ''; gift.checked = !!ex.gift; show('#gift-note-f', gift.checked); $('#f-gnote').value = ex.note || '';
  $('#coupon-apply').addEventListener('click', () => { ex.coupon = cInput.value.trim().toUpperCase(); cInput.value = ex.coupon; saveEx(); refreshQuote(); });
  cInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#coupon-apply').click(); } });
  gift.addEventListener('change', () => { ex.gift = gift.checked; show('#gift-note-f', gift.checked); saveEx(); refreshQuote(); });
  $('#f-gnote').addEventListener('input', (e) => { ex.note = e.target.value; saveEx(); });

  /* ---------- upsell: 3 ml samples of scents not in the cart ---------- */
  function upsell() {
    const inCart = new Set(cart.items().map((i) => i.slug)), S3 = cat.sizes.find((s) => s.id === '3ml');
    const list = cat.perfumes.filter((p) => !inCart.has(p.slug)).slice(0, 3);
    show('#upsell', list.length > 0 && cart.items().length > 0);
    $('#up-grid').innerHTML = list.map((p) => `<div class="up" style="--bg:${ELV.rgb(p.theme.bg)};--glow:${ELV.rgb(p.theme.glow)}"><img src="/assets/${p.slug}-sm.webp" alt="" width="42" height="86" loading="lazy"><div><b>${esc(p.name)}</b><small>${esc(S3.label)} · ${bn(S3.price)}</small></div><button type="button" class="btn btn-ghost btn-sm" data-up="${p.slug}">+ যোগ</button></div>`).join('');
  }
  $('#up-grid').addEventListener('click', (e) => { const b = e.target.closest('[data-up]'); if (b) { cart.add({ slug: b.dataset.up, size: '3ml', qty: 1 }); toast(per[b.dataset.up].name + ' (৩ ml) যোগ হয়েছে'); } });

  /* ---------- validation (mirrors the server; the server is the real gatekeeper) ---------- */
  const PHONE = /^01\d{9}$/, MAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const TYPOS = { 'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gamil.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gmail.con': 'gmail.com', 'yaho.com': 'yahoo.com', 'hotmial.com': 'hotmail.com' };
  const rules = {
    name: (v) => (v.trim().length >= 2 ? '' : 'আপনার নাম লিখুন'),
    phone: (v) => (PHONE.test(v) ? '' : '01 দিয়ে শুরু করে ঠিক ১১ ডিজিটের নম্বর দিন (যেমন 01712345678)'),
    whatsapp: (v) => (PHONE.test(v) ? '' : 'WhatsApp নম্বর দিন — 01 দিয়ে শুরু, ১১ ডিজিট'),
    email: (v) => { if (!MAIL.test(v.trim())) return 'সঠিক ইমেইল দিন (যেমন name@gmail.com)'; const t = TYPOS[v.trim().split('@')[1].toLowerCase()]; return t ? `ইমেইল ডোমেইন ভুল মনে হচ্ছে — ${t} হবে?` : ''; },
    district: (v) => (v ? '' : 'জেলা নির্বাচন করুন'),
    address: (v) => (v.trim().length >= 10 ? '' : 'বাসা/রোড, এলাকা, থানাসহ পূর্ণ ঠিকানা লিখুন'),
  };
  const setErr = (k, m) => { const f = F[k].closest('.field'); f.classList.toggle('bad', !!m); f.classList.toggle('good', !m && !!F[k].value); const e = $('.err', f); if (e) e.textContent = m || ''; };
  const check = (k) => { const m = rules[k](F[k].value); setErr(k, m); return !m; };
  for (const k of Object.keys(rules)) { F[k].addEventListener('blur', () => F[k].value && check(k)); F[k].addEventListener('input', () => F[k].closest('.field').classList.contains('bad') && check(k)); }
  for (const k of ['phone', 'whatsapp']) F[k].addEventListener('input', () => { F[k].value = F[k].value.replace(/\D/g, '').slice(0, 11); });
  const same = $('#same-wa');
  const syncWa = () => { if (same.checked) { F.whatsapp.value = F.phone.value; F.whatsapp.readOnly = true; } else F.whatsapp.readOnly = false; };
  same.addEventListener('change', syncWa); F.phone.addEventListener('input', syncWa);

  /* ---------- auth gate ---------- */
  $('#gate-login').addEventListener('click', ELV.openLogin);
  ELV.onAuth((u) => {
    gate.hidden = !!u; form.hidden = !u;
    if (!u) return;
    $('#who-am').textContent = u.email;
    const p = ELV.profile || {};
    if (!F.name.value) F.name.value = p.name || u.name || '';
    if (!F.email.value) F.email.value = p.email || u.email || '';
    if (!F.phone.value && p.phone) F.phone.value = p.phone;
    if (!F.whatsapp.value && p.whatsapp) F.whatsapp.value = p.whatsapp;
    if (!F.district.value && p.district) F.district.value = p.district;
    if (!F.address.value && p.address) F.address.value = p.address;
    if (p.phone && p.phone === p.whatsapp) { same.checked = true; syncWa(); }
    totals();
  });

  /* ---------- submit ---------- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); if (busy) return; msg.textContent = '';
    const items = cart.items(); if (!items.length) return toast('কার্ট খালি', 'err');
    const ok = Object.keys(rules).map(check).every(Boolean);
    if (!ok) { const bad = $('.field.bad input, .field.bad select, .field.bad textarea', form); bad?.focus(); msg.textContent = 'লাল চিহ্নিত ঘরগুলো ঠিক করুন।'; return; }
    busy = true; btn.disabled = true; btn.textContent = 'অর্ডার হচ্ছে…';
    try {
      const body = { items, clientToken: token, website: form.elements.website.value };
      for (const k of Object.keys(F)) body[k] = F[k].value.trim();
      body.coupon = ex.coupon || ''; body.giftWrap = !!ex.gift; body.giftNote = ex.gift ? (ex.note || '') : '';
      if (window.ELV.track) ELV.track('InitiateCheckout', { value: Q ? Q.total : cart.subtotal(), currency: 'BDT' });
      const r = await api('/orders', { method: 'POST', body });
      ELV.track && ELV.track('Purchase', { value: r.order.total, currency: 'BDT', contents: r.order.items.map((i) => ({ id: i.slug, quantity: i.qty })) });
      delete ex.coupon; delete ex.gift; delete ex.note; saveEx();
      $('#done-share').href = 'https://wa.me/?text=' + encodeURIComponent('আমি Elvaren থেকে সুগন্ধি অর্ডার করেছি 🌸 তুমিও দেখো: ' + location.origin + ' — প্রথম অর্ডারে WELCOME10 কোডে ১০% ছাড়!');
      cart.clear(); token = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
      $('#done-name').textContent = body.name.split(' ')[0]; $('#done-oid').textContent = 'অর্ডার নং ' + r.order.invoice;
      $('#done-track').href = '/account#' + r.order.invoice; $('#done').classList.add('show'); form.reset();
    } catch (err) {
      if (err.status === 401) { ELV.user = null; ELV.openLogin(); }
      const errs = err.data && err.data.errors;
      if (errs) for (const k of Object.keys(errs)) { if (F[k]) setErr(k, errs[k]); if (k === 'coupon') { $('#coupon-msg').textContent = errs[k]; $('#coupon-msg').className = 'cmsg bad'; } }
      msg.textContent = err.message;
    } finally { busy = false; btn.disabled = false; btn.textContent = 'অর্ডার কনফার্ম করুন'; }
  });

  renderItems();
})();
