/* Hero carousel: bottle + its own ingredients, pastel background per scent */
(() => {
  const { $, $$, cat, rgb } = ELV;
  const vis = $('#h-vis'); if (!vis) return;
  const P = cat.perfumes, n = P.length, S6 = cat.sizes.find((s) => s.id === '6ml') || cat.sizes[cat.sizes.length - 1];
  const scenes = $$('.h-scene', vis), bgs = $$('.h-bgi'), q = $('#h-quote'), who = $('#h-who'), cards = $('#h-cards');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ARROW = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17L17 7M9 7h8v8"/></svg>';
  scenes.forEach((s, i) => s.style.setProperty('--glow', rgb(P[i].theme.glow)));

  const mini = (p) => `<a class="mc" href="/perfume/${p.slug}" style="--bg:${rgb(p.theme.bg)};--g:${rgb(p.theme.glow)};--w:${rgb(p.theme.pastel)}"><span class="mc-img"><img src="/assets/${p.slug}-sm.webp" alt="" width="100" height="206"></span><span class="mc-t"><b>${p.name}</b><small>(${S6.label} · ৳${S6.price})</small><span class="mc-b"><span class="pill-s">Explore Shop</span><span class="circ-s">${ARROW}</span></span></span></a>`;
  let cur = 0, timer, first = true;

  function show(i) {
    cur = (i + n) % n; const p = P[cur];
    scenes.forEach((s, k) => s.classList.toggle('on', k === cur));
    bgs.forEach((b, k) => b.classList.toggle('on', k === cur));
    $('#h-cur').textContent = '0' + (cur + 1);
    const swap = () => {
      q.textContent = p.quote; q.style.opacity = 1;
      who.href = '/perfume/' + p.slug;
      who.innerHTML = `<span class="who-img"><img src="/assets/${p.slug}-sm.webp" alt="" width="40" height="82"></span><span><b>${p.name}</b><small>${p.mood}</small></span>`;
      cards.innerHTML = mini(P[(cur + 1) % n]) + mini(P[(cur + 2) % n]);
    };
    if (first) { first = false; swap(); } else { q.style.opacity = 0; setTimeout(swap, 220); }
  }
  function restart() { clearInterval(timer); if (!reduce) timer = setInterval(() => { if (!document.hidden && !hovering) show(cur + 1); }, 6500); }
  let hovering = false;
  $('#h-next').addEventListener('click', () => { show(cur + 1); restart(); });
  $('#h-prev').addEventListener('click', () => { show(cur - 1); restart(); });
  const hero = $('#top');
  hero.addEventListener('mouseenter', () => { hovering = true; });
  hero.addEventListener('mouseleave', () => { hovering = false; vis.style.setProperty('--mx', 0); vis.style.setProperty('--my', 0); });
  hero.addEventListener('pointermove', (e) => {
    if (reduce) return; const r = vis.getBoundingClientRect();
    vis.style.setProperty('--mx', ((e.clientX - r.left) / r.width - .5).toFixed(3) * 2);
    vis.style.setProperty('--my', ((e.clientY - r.top) / r.height - .5).toFixed(3) * 2);
  });
  show(0); restart();
})();
