/* Optional marketing pixels (Facebook Pixel / Google Analytics 4) — only loaded when FB_PIXEL_ID / GA_MEASUREMENT_ID is set. */
(() => {
  const t = (window.ELV && ELV.boot.track) || {};
  const q = [];
  ELV.track = (ev, data = {}) => {
    try {
      if (t.fb && window.fbq) fbq('track', ev, data);
      if (t.ga && window.gtag) gtag('event', ({ ViewContent: 'view_item', AddToCart: 'add_to_cart', InitiateCheckout: 'begin_checkout', Purchase: 'purchase' })[ev] || ev, { currency: 'BDT', value: data.value, items: data.contents && data.contents.map((c) => ({ item_id: c.id, quantity: c.quantity })) });
    } catch { /* never break the shop */ }
  };
  if (t.fb) {
    window.fbq = function () { (fbq.q = fbq.q || []).push(arguments); }; window.fbq.queue = q; window._fbq = window.fbq; fbq.loaded = true; fbq.version = '2.0';
    const s = document.createElement('script'); s.async = true; s.src = 'https://connect.facebook.net/en_US/fbevents.js'; document.head.appendChild(s);
    fbq('init', t.fb); fbq('track', 'PageView');
  }
  if (t.ga) {
    window.dataLayer = window.dataLayer || []; window.gtag = function () { dataLayer.push(arguments); };
    const s = document.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(t.ga); document.head.appendChild(s);
    gtag('js', new Date()); gtag('config', t.ga);
  }
  document.addEventListener('elv:added', (e) => ELV.track('AddToCart', { value: e.detail.value, currency: 'BDT', contents: e.detail.contents }));
})();
