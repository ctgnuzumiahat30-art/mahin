import dns from 'node:dns/promises';

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';
export const toAsciiDigits = (s) => String(s ?? '').replace(/[০-৯]/g, (c) => String(BN_DIGITS.indexOf(c)));

/** Phone rule (as required): must start with 01 and be exactly 11 digits. */
export const PHONE_RE = /^01\d{9}$/;
export function validPhone(raw) {
  const p = toAsciiDigits(raw).replace(/[\s\-()]/g, '');
  return PHONE_RE.test(p) ? p : null;
}

const EMAIL_RE = /^(?!\.)(?!.*\.\.)[A-Za-z0-9._%+\-]{1,64}(?<!\.)@(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24}$/;
const DOMAIN_TYPOS = {
  'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gamil.com': 'gmail.com', 'gmail.con': 'gmail.com', 'gmail.co': 'gmail.com',
  'gmail.cm': 'gmail.com', 'gnail.com': 'gmail.com', 'gmaill.com': 'gmail.com', 'gmeil.com': 'gmail.com',
  'yaho.com': 'yahoo.com', 'yahooo.com': 'yahoo.com', 'yahoo.con': 'yahoo.com', 'hotmial.com': 'hotmail.com',
  'hotmail.con': 'hotmail.com', 'outlok.com': 'outlook.com', 'outlook.con': 'outlook.com',
};

/** Syntax + common-typo check. Returns { ok, email } or { ok:false, reason, suggestion? } */
export function checkEmail(raw) {
  const email = String(raw ?? '').trim().toLowerCase();
  if (!email || email.length > 254 || !EMAIL_RE.test(email)) return { ok: false, reason: 'invalid' };
  const [local, domain] = email.split('@');
  if (DOMAIN_TYPOS[domain]) return { ok: false, reason: 'typo', suggestion: `${local}@${DOMAIN_TYPOS[domain]}` };
  return { ok: true, email };
}

/** True unless DNS clearly says the domain cannot receive mail. Network hiccups never block an order. */
export async function domainCanReceiveMail(domain) {
  try {
    const mx = await dns.resolveMx(domain);
    if (mx.length) return true;
  } catch (e) {
    if (e.code !== 'ENOTFOUND' && e.code !== 'ENODATA') return true; // timeout / refused → don't punish the customer
  }
  try { return (await dns.resolve4(domain)).length > 0; } catch (e) {
    return e.code !== 'ENOTFOUND' && e.code !== 'ENODATA';
  }
}

export const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max);
