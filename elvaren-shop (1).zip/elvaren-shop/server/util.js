/** Tiny in-memory sliding-window rate limiter. */
export function rateLimit({ windowMs, max, key = (req) => req.ip, message = 'অনেকগুলো অনুরোধ — একটু পরে আবার চেষ্টা করুন' }) {
  const hits = new Map();
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) { const keep = v.filter((t) => now - t < windowMs); keep.length ? hits.set(k, keep) : hits.delete(k); } }, 60_000).unref();
  return (req, res, next) => {
    const k = key(req), now = Date.now();
    const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) { res.set('Retry-After', String(Math.ceil(windowMs / 1000))); return res.status(429).json({ ok: false, error: message }); }
    arr.push(now); hits.set(k, arr); next();
  };
}

/** CSRF defence for cookie-authenticated JSON endpoints: the Origin header must be our own site. */
export function sameOrigin(cfg) {
  const site = cfg.siteUrl ? new URL(cfg.siteUrl).host : null;
  return (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.get('origin');
    let host = null;
    try { host = origin ? new URL(origin).host : null; } catch { /* invalid */ }
    if (!host || (host !== req.get('host') && host !== site)) return res.status(403).json({ ok: false, error: 'অনুরোধটি গ্রহণযোগ্য নয় (origin)' });
    next();
  };
}

export function securityHeaders(cfg) {
  const fb = !!cfg.fbPixelId, ga = !!cfg.gaId;
  const csp = [
    "default-src 'self'",
    `script-src 'self' https://accounts.google.com/gsi/client${fb ? ' https://connect.facebook.net' : ''}${ga ? ' https://www.googletagmanager.com' : ''}`,
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://accounts.google.com/gsi/style",
    "font-src 'self' https://fonts.gstatic.com",
    `img-src 'self' data: https://*.googleusercontent.com${fb ? ' https://www.facebook.com' : ''}${ga ? ' https://www.google-analytics.com https://www.googletagmanager.com' : ''}`,
    `connect-src 'self' https://accounts.google.com${fb ? ' https://www.facebook.com https://connect.facebook.net' : ''}${ga ? ' https://www.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com' : ''}`,
    "frame-src https://accounts.google.com",
    "base-uri 'self'", "form-action 'self'", "object-src 'none'", "frame-ancestors 'self'",
  ].join('; ');
  return (req, res, next) => {
    res.set({
      'Content-Security-Policy': csp,
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'X-Frame-Options': 'SAMEORIGIN',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      'Cross-Origin-Opener-Policy': 'same-origin-allow-popups',
    });
    if (cfg.cookieSecure) res.set('Strict-Transport-Security', 'max-age=15552000');
    next();
  };
}
