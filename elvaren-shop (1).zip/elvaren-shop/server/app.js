import express from 'express';
import path from 'node:path';
import crypto from 'node:crypto';
import { config as defaultConfig, ROOT } from './config.js';
import { openDb } from './db.js';
import { perfumeBySlug, catalog } from './catalog.js';
import { STATUSES, STATUS_BY_KEY, normalizeStatus } from './statuses.js';
import { sessionUid, setSessionCookie, clearSessionCookie, verifyGoogleCredential, upsertUser, publicUser } from './auth.js';
import { rateLimit, sameOrigin, securityHeaders } from './util.js';
import { quote, normalizeCart as normCart } from './pricing.js';
import { validateOrder, createOrder, getOrder, listOrders, publicOrder, normalizeCart, setStatus } from './orders.js';
import { deliverOrderWebhook, startWebhookRetryLoop, postEvent } from './n8n.js';
import { checkEmail, validPhone, clean } from './validate.js';
import * as pages from './pages.js';

const jsonErr = (res, code, error, extra = {}) => res.status(code).json({ ok: false, error, ...extra });

export function createApp({ cfg = defaultConfig, db = openDb(cfg.dbFile), fetchImpl = fetch, retryLoop = true } = {}) {
  const app = express();
  app.disable('x-powered-by');
  if (cfg.trustProxy) app.set('trust proxy', cfg.trustProxy);
  app.use(securityHeaders(cfg));
  app.use(express.json({ limit: '32kb' }));

  const ctx = { cfg, build: Date.now().toString(36) };
  const cache = new Map();
  const html = (key, render) => (req, res) => {
    if (!cache.has(key)) cache.set(key, render());
    res.set('Cache-Control', 'no-cache').type('html').send(cache.get(key));
  };

  /* ---------------- static + pages ---------------- */
  app.use('/assets', express.static(path.join(ROOT, 'public', 'assets'), { maxAge: '7d' }));
  app.get('/healthz', (req, res) => res.json({ ok: true }));
  app.get('/', html('home', () => pages.renderHome(ctx)));
  app.get('/cart', html('cart', () => pages.renderCart(ctx)));
  app.get('/account', html('account', () => pages.renderAccount(ctx)));
  app.get('/policies', html('policies', () => pages.renderPolicies(ctx)));
  app.get('/perfume/:slug', (req, res, next) => {
    const p = perfumeBySlug[req.params.slug];
    if (!p) return next();
    return html('p:' + p.slug, () => pages.renderProduct(ctx, p))(req, res);
  });
  app.get('/robots.txt', (req, res) => {
    const base = cfg.siteUrl || `${req.protocol}://${req.get('host')}`;
    res.type('text').send(`User-agent: *\nDisallow: /api/\nDisallow: /account\nDisallow: /cart\nSitemap: ${base}/sitemap.xml\n`);
  });
  app.get('/sitemap.xml', (req, res) => {
    const base = cfg.siteUrl || `${req.protocol}://${req.get('host')}`;
    const urls = ['/', '/policies', ...catalog.perfumes.map((p) => `/perfume/${p.slug}`)];
    res.type('xml').send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map((u) => `<url><loc>${base}${u}</loc></url>`).join('')}</urlset>`);
  });

  /* ---------------- API ---------------- */
  const api = express.Router();
  // Browser (cookie) endpoints are protected against cross-site requests; n8n endpoints use an API key instead.
  api.use((req, res, next) => (req.path.startsWith('/n8n') ? next() : sameOrigin(cfg)(req, res, next)));
  api.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    const uid = sessionUid(req, cfg);
    req.user = uid ? db.prepare('SELECT * FROM users WHERE id = ?').get(uid) || null : null;
    next();
  });
  const needUser = (req, res, next) => (req.user ? next() : jsonErr(res, 401, 'অনুগ্রহ করে আগে লগইন করুন', { code: 'login_required' }));

  const profileFor = (u) => db.prepare('SELECT name, phone, whatsapp, email, address, district FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 1').get(u.id) || null;
  const me = (u) => ({ ok: true, user: publicUser(u), profile: u ? profileFor(u) : null });

  api.get('/auth/me', (req, res) => res.json(me(req.user)));

  const authLimiter = rateLimit({ windowMs: 10 * 60_000, max: 30 });
  api.post('/auth/google', authLimiter, async (req, res) => {
    try {
      const g = await verifyGoogleCredential(cfg, String(req.body?.credential || ''));
      const user = upsertUser(db, g);
      setSessionCookie(res, cfg, user.id);
      res.json(me(user));
    } catch (e) {
      console.warn('[auth] google verify failed:', e.message);
      jsonErr(res, 401, 'Google লগইন যাচাই করা যায়নি — আবার চেষ্টা করুন');
    }
  });
  if (cfg.devAuth) {
    // Test-only login (DEV_AUTH=1, never active in production).
    api.post('/auth/dev', (req, res) => {
      const email = String(req.body?.email || '').trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return jsonErr(res, 400, 'invalid email');
      const user = upsertUser(db, { sub: 'dev:' + email, email, name: String(req.body?.name || email.split('@')[0]).slice(0, 80), picture: '' });
      setSessionCookie(res, cfg, user.id);
      res.json(me(user));
    });
  }
  api.post('/auth/logout', (req, res) => { clearSessionCookie(res, cfg); res.json({ ok: true }); });

  api.get('/cart', needUser, (req, res) => {
    const r = db.prepare('SELECT items_json FROM carts WHERE user_id = ?').get(req.user.id);
    res.json({ ok: true, items: normalizeCart(r ? JSON.parse(r.items_json) : []) });
  });
  api.put('/cart', needUser, (req, res) => {
    const items = normalizeCart(req.body?.items);
    db.prepare(`INSERT INTO carts (user_id, items_json, updated_at) VALUES (?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET items_json = excluded.items_json, updated_at = excluded.updated_at`).run(req.user.id, JSON.stringify(items), new Date().toISOString());
    res.json({ ok: true, items });
  });

  const orderLimiter = rateLimit({ windowMs: 3600_000, max: 30, key: (req) => 'u' + req.user.id });
  api.post('/orders', needUser, orderLimiter, async (req, res) => {
    if (req.body?.website) return jsonErr(res, 400, 'অনুরোধটি গ্রহণযোগ্য নয়');
    const v = await validateOrder(req.body, cfg, { db, userId: req.user.id });
    if (v.errors) return jsonErr(res, 422, 'তথ্যে ভুল আছে — লাল চিহ্নিত ঘরগুলো ঠিক করুন', { errors: v.errors });
    const { order, duplicate } = createOrder(db, cfg, req.user, v.value);
    if (!duplicate) deliverOrderWebhook(db, cfg, order.id, fetchImpl).catch((e) => console.error('[webhook]', e.message));
    res.status(duplicate ? 200 : 201).json({ ok: true, duplicate, order: publicOrder(order) });
  });

  /* ---- live price quote (cart page): coupon / bundle / free delivery / gift — same maths as the real order ---- */
  const quoteLimiter = rateLimit({ windowMs: 60_000, max: 90 });
  api.post('/quote', quoteLimiter, (req, res) => {
    const b = req.body || {};
    const q = quote({ cart: normCart(b.items), district: String(b.district || ''), coupon: b.coupon, giftWrap: !!b.giftWrap }, { db, userId: req.user?.id });
    res.json({ ok: true, quote: q });
  });

  /* ---- newsletter / lead capture → n8n "lead.created" ---- */
  const leadLimiter = rateLimit({ windowMs: 3600_000, max: 8 });
  api.post('/leads', leadLimiter, async (req, res) => {
    if (req.body?.website) return jsonErr(res, 400, 'অনুরোধটি গ্রহণযোগ্য নয়');
    const em = checkEmail(req.body?.email);
    if (!em.ok) return jsonErr(res, 422, em.reason === 'typo' ? `ইমেইল ঠিক আছে তো? ${em.suggestion} বোঝাতে চেয়েছেন?` : 'সঠিক ইমেইল দিন');
    const wa = validPhone(req.body?.whatsapp) || '';
    const r = db.prepare('INSERT OR IGNORE INTO leads (email, whatsapp, source, created_at) VALUES (?, ?, ?, ?)').run(em.email, wa, String(req.body?.source || 'site').slice(0, 30), new Date().toISOString());
    if (r.changes) postEvent(cfg, 'lead.created', { lead: { email: em.email, whatsapp: wa, source: String(req.body?.source || 'site').slice(0, 30) } }, fetchImpl).catch(() => {});
    res.json({ ok: true, coupon: 'WELCOME10', message: 'ধন্যবাদ! প্রথম অর্ডারে WELCOME10 কোড ব্যবহার করুন।' });
  });

  /* ---- verified-buyer reviews (only from Delivered orders; nothing is ever pre-filled) ---- */
  api.get('/reviews/:slug', (req, res) => {
    const rows = db.prepare('SELECT rating, body, author, created_at FROM reviews WHERE slug = ? AND hidden = 0 ORDER BY id DESC LIMIT 30').all(req.params.slug);
    const agg = db.prepare('SELECT COUNT(*) AS n, AVG(rating) AS a FROM reviews WHERE slug = ? AND hidden = 0').get(req.params.slug);
    res.json({ ok: true, count: agg.n, avg: agg.n ? Math.round(agg.a * 10) / 10 : 0, reviews: rows.map((r) => ({ rating: r.rating, body: r.body, author: r.author, at: r.created_at })) });
  });
  api.post('/reviews', needUser, rateLimit({ windowMs: 3600_000, max: 20, key: (r) => 'u' + r.user.id }), (req, res) => {
    const o = getOrder(db, req.body?.invoice);
    const slug = String(req.body?.slug || ''), rating = Math.floor(Number(req.body?.rating));
    if (!o || o.userId !== req.user.id) return jsonErr(res, 404, 'অর্ডার পাওয়া যায়নি');
    if (o.status !== 'delivered') return jsonErr(res, 400, 'ডেলিভারি সম্পন্ন হওয়ার পর রিভিউ দিতে পারবেন');
    if (!o.items.some((i) => i.slug === slug)) return jsonErr(res, 400, 'এই অর্ডারে পণ্যটি নেই');
    if (!(rating >= 1 && rating <= 5)) return jsonErr(res, 422, '১ থেকে ৫ স্টার দিন');
    const author = (o.customer.name.split(' ')[0] || 'Customer').slice(0, 30);
    try { db.prepare('INSERT INTO reviews (user_id, order_id, slug, rating, body, author, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(req.user.id, o.id, slug, rating, clean(req.body?.body, 400), author, new Date().toISOString()); }
    catch { return jsonErr(res, 409, 'এই পণ্যের রিভিউ আপনি আগেই দিয়েছেন'); }
    res.json({ ok: true });
  });
  api.get('/orders', needUser, (req, res) => {
    const done = db.prepare('SELECT order_id, slug FROM reviews WHERE user_id = ?').all(req.user.id);
    res.json({ ok: true, serverTime: new Date().toISOString(), orders: listOrders(db, { userId: req.user.id, limit: 100 }).map((o) => ({ ...publicOrder(o), reviewed: done.filter((d) => d.order_id === o.id).map((d) => d.slug) })) });
  });
  api.get('/orders/:invoice', needUser, (req, res) => {
    const o = getOrder(db, req.params.invoice);
    if (!o || o.userId !== req.user.id) return jsonErr(res, 404, 'অর্ডার পাওয়া যায়নি');
    res.json({ ok: true, order: publicOrder(o) });
  });

  /* ---------------- n8n ↔ website ---------------- */
  function n8nAuth(req, res, next) {
    const key = cfg.n8n.apiKey;
    if (!key) return jsonErr(res, 503, 'N8N_API_KEY is not configured on the server');
    const a = Buffer.from(String(req.get('x-api-key') || '')), b = Buffer.from(key);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return jsonErr(res, 401, 'invalid api key');
    next();
  }
  const labels = STATUSES.map((s) => s.sheet).join(', ');

  api.get('/n8n/ping', n8nAuth, (req, res) => res.json({ ok: true, statuses: STATUSES.map((s) => s.sheet) }));

  // Update one order, or many:  { invoice, status, trackingId?, courier?, note? }  |  { updates: [ ... ] }
  api.post('/n8n/orders/status', n8nAuth, (req, res) => {
    const bulk = Array.isArray(req.body?.updates);
    const list = bulk ? req.body.updates.slice(0, 200) : [req.body || {}];
    const results = list.map((u) => {
      const invoice = String(u.invoice || u.orderId || '').trim();
      const key = normalizeStatus(u.status);
      if (!invoice) return { ok: false, code: 400, error: 'invoice is required' };
      if (!key) return { ok: false, code: 400, invoice, error: `unknown status "${u.status}". Use one of: ${labels}` };
      const r = setStatus(db, invoice, key, { note: u.note, courier: u.courier, trackingId: u.trackingId ?? u.tracking_id, source: 'n8n' });
      if (!r) return { ok: false, code: 404, invoice, error: 'order not found' };
      return { ok: true, code: 200, invoice: r.order.invoice, status: r.order.status, label: STATUS_BY_KEY[r.order.status].sheet, changed: r.changed };
    });
    if (!bulk) { const r = results[0]; return res.status(r.code).json(r); }
    res.json({ ok: results.every((r) => r.ok), results });
  });

  // Orders list for n8n (e.g. to reconcile with the sheet):  ?status=pending&since=2026-10-25T00:00:00Z&limit=50
  api.get('/n8n/orders', n8nAuth, (req, res) => {
    const status = req.query.status ? normalizeStatus(req.query.status) : undefined;
    const rows = listOrders(db, { status, since: req.query.since ? String(req.query.since) : undefined, limit: Number(req.query.limit) || 50 });
    res.json({ ok: true, orders: rows.map((o) => ({ invoice: o.invoice, status: o.status, label: STATUS_BY_KEY[o.status].sheet, createdAt: o.createdAt, customer: o.customer, items: o.items, subtotal: o.subtotal, deliveryFee: o.delivery.fee, total: o.total, trackingId: o.trackingId, courier: o.courier, webhook: o.webhook })) });
  });


  // Carts that were filled but never ordered — for abandoned-cart WhatsApp/email reminders:  ?minutes=60
  api.get('/n8n/abandoned-carts', n8nAuth, (req, res) => {
    const mins = Math.max(5, Number(req.query.minutes) || 60);
    const older = new Date(Date.now() - mins * 60_000).toISOString(), newer = new Date(Date.now() - 7 * 86400_000).toISOString();
    const rows = db.prepare(`SELECT u.email, u.name, c.items_json, c.updated_at FROM carts c JOIN users u ON u.id = c.user_id
      WHERE c.items_json != '[]' AND c.updated_at < ? AND c.updated_at > ?
      AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.user_id = u.id AND o.created_at > c.updated_at)`).all(older, newer);
    res.json({ ok: true, carts: rows.map((r) => { const q = quote({ cart: normCart(JSON.parse(r.items_json)) }); return { email: r.email, name: r.name, updatedAt: r.updated_at, items: q.items, subtotal: q.subtotal, link: (cfg.siteUrl || '') + '/cart', coupon: 'WELCOME10' }; }) });
  });

  // Hide an abusive review:  POST /api/n8n/reviews/12/hide
  api.post('/n8n/reviews/:id/hide', n8nAuth, (req, res) => {
    const r = db.prepare('UPDATE reviews SET hidden = 1 WHERE id = ?').run(Number(req.params.id) || 0);
    res.json({ ok: r.changes > 0 });
  });

  // Push an order to the n8n webhook again.
  api.post('/n8n/orders/:invoice/resend', n8nAuth, async (req, res) => {
    const o = getOrder(db, req.params.invoice);
    if (!o) return jsonErr(res, 404, 'order not found');
    db.prepare("UPDATE orders SET webhook_state = 'pending', webhook_attempts = 0, webhook_next_at = 0 WHERE id = ?").run(o.id);
    const r = await deliverOrderWebhook(db, cfg, o.id, fetchImpl);
    res.json({ ok: !!(r.ok || r.skipped), ...r });
  });

  api.use((req, res) => jsonErr(res, 404, 'not found'));
  app.use('/api', api);

  /* ---------------- 404 + errors ---------------- */
  app.use((req, res) => res.status(404).type('html').send(pages.renderNotFound(ctx)));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed' || err.status === 400) return jsonErr(res, 400, 'invalid request');
    console.error('[error]', err);
    if (req.path.startsWith('/api')) return jsonErr(res, 500, 'সার্ভারে সমস্যা হয়েছে — একটু পরে আবার চেষ্টা করুন');
    res.status(500).type('text').send('Server error');
  });

  const timer = retryLoop ? startWebhookRetryLoop(db, cfg) : null;
  return { app, db, cfg, stop: () => { if (timer) clearInterval(timer); try { db.close(); } catch { /* closed */ } } };
}
