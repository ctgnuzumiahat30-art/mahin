import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
try { process.loadEnvFile(path.join(ROOT, '.env')); } catch { /* .env is optional */ }

const env = process.env;
const bool = (v, d = false) => (v == null || v === '' ? d : /^(1|true|yes|on)$/i.test(String(v)));
const isProd = env.NODE_ENV === 'production';
const dbFile = env.DB_FILE || path.join(ROOT, 'data', 'elvaren.db');

function secret() {
  if (env.SESSION_SECRET && env.SESSION_SECRET.length >= 16) return env.SESSION_SECRET;
  if (isProd) console.warn('[config] SESSION_SECRET is not set — a random one is stored in data/session.secret. Set SESSION_SECRET in .env for production.');
  const f = path.join(path.dirname(dbFile), 'session.secret');
  try { return fs.readFileSync(f, 'utf8').trim(); } catch { /* create below */ }
  const s = crypto.randomBytes(32).toString('hex');
  try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, s, { mode: 0o600 }); } catch { /* ephemeral */ }
  return s;
}

export const config = {
  port: Number(env.PORT) || 3000,
  isProd,
  siteUrl: (env.SITE_URL || '').replace(/\/+$/, ''),
  dbFile,
  sessionSecret: secret(),
  sessionDays: Number(env.SESSION_DAYS) || 30,
  cookieSecure: bool(env.COOKIE_SECURE, isProd),
  trustProxy: env.TRUST_PROXY ? (Number.isNaN(Number(env.TRUST_PROXY)) ? env.TRUST_PROXY : Number(env.TRUST_PROXY)) : (isProd ? 1 : false),

  googleClientId: env.GOOGLE_CLIENT_ID || '',
  devAuth: bool(env.DEV_AUTH, false) && !isProd,

  fbPixelId: (env.FB_PIXEL_ID || '').replace(/\D/g, ''),
  gaId: (env.GA_MEASUREMENT_ID || '').replace(/[^A-Z0-9-]/gi, ''),
  checkEmailMx: bool(env.CHECK_EMAIL_MX, true),
  invoicePrefix: env.INVOICE_PREFIX || 'E',
  invoiceStart: Number(env.INVOICE_START) || 1003,
  payment: 'Cash on Delivery (COD)',

  n8n: {
    orderWebhookUrl: env.N8N_ORDER_WEBHOOK_URL || '',
    webhookSecret: env.N8N_WEBHOOK_SECRET || '',
    apiKey: env.N8N_API_KEY || '',
  },

  contact: {
    phone: env.CONTACT_PHONE || '',
    whatsapp: (env.CONTACT_WHATSAPP || '').replace(/\D/g, ''),
    facebook: env.FACEBOOK_URL || '',
    instagram: env.INSTAGRAM_URL || '',
    email: env.CONTACT_EMAIL || '',
  },
};

/** Per-test override helper */
export function withConfig(over) {
  return { ...config, ...over, n8n: { ...config.n8n, ...(over.n8n || {}) }, contact: { ...config.contact, ...(over.contact || {}) } };
}
