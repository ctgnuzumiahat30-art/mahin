import crypto from 'node:crypto';
import { OAuth2Client } from 'google-auth-library';

const COOKIE = 'elv_session';
const b64u = (buf) => Buffer.from(buf).toString('base64url');
const hmac = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest();

export function makeToken(secret, uid, days = 30) {
  const payload = b64u(JSON.stringify({ uid, exp: Date.now() + days * 86400_000 }));
  return `${payload}.${b64u(hmac(secret, payload))}`;
}

export function readToken(secret, token) {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const want = hmac(secret, payload), got = Buffer.from(sig, 'base64url');
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  try {
    const p = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return p.exp > Date.now() ? p.uid : null;
  } catch { return null; }
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return out;
}

export function setSessionCookie(res, cfg, uid) {
  const token = makeToken(cfg.sessionSecret, uid, cfg.sessionDays);
  res.append('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${cfg.sessionDays * 86400}${cfg.cookieSecure ? '; Secure' : ''}`);
}
export function clearSessionCookie(res, cfg) {
  res.append('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${cfg.cookieSecure ? '; Secure' : ''}`);
}
export const sessionUid = (req, cfg) => readToken(cfg.sessionSecret, parseCookies(req.headers.cookie)[COOKIE]);

let gclient;
/** Verifies a Google Sign-In ID token (credential) against your OAuth client ID. */
export async function verifyGoogleCredential(cfg, credential) {
  if (!cfg.googleClientId) throw new Error('GOOGLE_CLIENT_ID is not configured');
  gclient ||= new OAuth2Client(cfg.googleClientId);
  const ticket = await gclient.verifyIdToken({ idToken: credential, audience: cfg.googleClientId });
  const p = ticket.getPayload();
  if (!p?.sub || !p.email || p.email_verified === false) throw new Error('Google account email is not verified');
  return { sub: p.sub, email: p.email.toLowerCase(), name: p.name || p.email.split('@')[0], picture: p.picture || '' };
}

export function upsertUser(db, { sub, email, name, picture }) {
  const t = new Date().toISOString();
  db.prepare(`INSERT INTO users (google_sub, email, name, picture, created_at, last_login) VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(google_sub) DO UPDATE SET email = excluded.email, name = excluded.name, picture = excluded.picture, last_login = excluded.last_login`)
    .run(sub, email, name, picture, t, t);
  return db.prepare('SELECT * FROM users WHERE google_sub = ?').get(sub);
}

export const publicUser = (u) => (u ? { id: u.id, name: u.name, email: u.email, picture: u.picture } : null);
