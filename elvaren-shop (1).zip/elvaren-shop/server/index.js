import { config } from './config.js';
import { createApp } from './app.js';

const { app } = createApp();
app.listen(config.port, () => {
  console.log(`Elvaren shop running on http://localhost:${config.port}`);
  if (!config.googleClientId) console.warn('⚠  GOOGLE_CLIENT_ID is not set — customers cannot log in yet. See README.md');
  if (!config.n8n.orderWebhookUrl) console.warn('⚠  N8N_ORDER_WEBHOOK_URL is not set — new orders are saved but not sent to n8n yet (they are queued and will be sent once you set it).');
  if (!config.n8n.apiKey) console.warn('⚠  N8N_API_KEY is not set — n8n cannot update order status yet.');
  if (config.devAuth) console.warn('⚠  DEV_AUTH is ON — fake login enabled. Never use this on a live site.');
});
