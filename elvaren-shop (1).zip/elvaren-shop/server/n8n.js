import crypto from 'node:crypto';
import { rowToOrder } from './orders.js';

/** One row shaped exactly like your Google Sheet "Sales revenue" tab, so n8n can map it 1:1. */
export function sheetRow(o) {
  const d = new Date(o.createdAt);
  const bd = new Date(d.getTime() + 6 * 3600 * 1000); // Asia/Dhaka (UTC+6, no DST)
  const date = `${bd.getUTCMonth() + 1}/${bd.getUTCDate()}/${bd.getUTCFullYear()}`;
  const sizes = [...new Set(o.items.map((i) => i.sizeLabel))].join(' / ');
  const multi = o.items.length > 1;
  const itemName = o.items.map((i) => (multi && i.qty > 1 ? `${i.name} x${i.qty}` : i.name)).join(', ');
  return {
    'Date': date,
    'Invoice': o.invoice,
    'Customer': o.customer.name,
    'Item Name': itemName,
    'Variant': sizes,
    'Qty': o.totalQty,
    'Unit Price': Math.round((o.subtotal / o.totalQty) * 100) / 100,
    'Total Price': o.subtotal,
    'Discount': o.discount || 0,
    'Net Sales': o.subtotal - (o.discount || 0),
    'Payment': o.payment,
    'Courier Status': 'Pending',
  };
}

export function webhookPayload(o, siteUrl = '') {
  return {
    event: 'order.created',
    sentAt: new Date().toISOString(),
    order: {
      invoice: o.invoice,
      status: o.status,
      createdAt: o.createdAt,
      customer: o.customer,
      items: o.items.map((i) => ({ name: i.name, size: i.sizeLabel, qty: i.qty, unitPrice: i.unitPrice, lineTotal: i.lineTotal })),
      totalQty: o.totalQty,
      subtotal: o.subtotal,
      discount: o.discount || 0,
      couponCode: o.extras?.couponCode || '',
      giftWrap: o.extras?.giftWrapFee ? { fee: o.extras.giftWrapFee, note: o.extras.giftNote || '' } : null,
      deliveryZone: o.delivery.zone,
      deliveryFee: o.delivery.fee,
      freeDelivery: !!o.extras?.freeDelivery,
      total: o.total,
      payment: o.payment,
    },
    sheetRow: sheetRow(o),
    callback: { statusUrl: siteUrl ? `${siteUrl}/api/n8n/orders/status` : '/api/n8n/orders/status' },
  };
}

export function signBody(body, secret) {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
}

const MAX_ATTEMPTS = 15;

/** POST the order to your n8n webhook. Failures are kept and retried automatically (exponential back-off). */
export async function deliverOrderWebhook(db, cfg, orderId, fetchImpl = fetch) {
  const url = cfg.n8n.orderWebhookUrl;
  if (!url) return { skipped: true };
  const row = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!row) return { skipped: true };
  const events = db.prepare('SELECT * FROM order_events WHERE order_id = ? ORDER BY id').all(orderId);
  const order = rowToOrder(row, events);
  const body = JSON.stringify(webhookPayload(order, cfg.siteUrl));
  const headers = { 'content-type': 'application/json', 'x-elvaren-event': 'order.created', 'x-elvaren-delivery': crypto.randomUUID() };
  if (cfg.n8n.webhookSecret) headers['x-elvaren-signature'] = signBody(body, cfg.n8n.webhookSecret);
  try {
    const res = await fetchImpl(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    db.prepare("UPDATE orders SET webhook_state = 'sent', webhook_attempts = webhook_attempts + 1, webhook_error = '' WHERE id = ?").run(orderId);
    return { ok: true };
  } catch (e) {
    const attempts = row.webhook_attempts + 1;
    const give = attempts >= MAX_ATTEMPTS;
    const next = Date.now() + Math.min(30_000 * 2 ** attempts, 3_600_000);
    db.prepare('UPDATE orders SET webhook_state = ?, webhook_attempts = ?, webhook_next_at = ?, webhook_error = ? WHERE id = ?')
      .run(give ? 'failed' : 'pending', attempts, next, String(e.message || e).slice(0, 200), orderId);
    return { ok: false, error: String(e.message || e) };
  }
}

export function startWebhookRetryLoop(db, cfg, everyMs = 30_000) {
  let busy = false;
  const t = setInterval(async () => {
    if (busy || !cfg.n8n.orderWebhookUrl) return;
    busy = true;
    try {
      const due = db.prepare("SELECT id FROM orders WHERE webhook_state = 'pending' AND webhook_next_at <= ? ORDER BY id LIMIT 20").all(Date.now());
      for (const r of due) await deliverOrderWebhook(db, cfg, r.id);
    } catch (e) { console.error('[webhook retry]', e.message); } finally { busy = false; }
  }, everyMs);
  t.unref?.();
  return t;
}

/** Fire-and-forget event (e.g. lead.created) to the same n8n webhook. */
export async function postEvent(cfg, event, data, fetchImpl = fetch) {
  const url = cfg.n8n.orderWebhookUrl; if (!url) return { skipped: true };
  const body = JSON.stringify({ event, sentAt: new Date().toISOString(), ...data });
  const headers = { 'content-type': 'application/json', 'x-elvaren-event': event, 'x-elvaren-delivery': crypto.randomUUID() };
  if (cfg.n8n.webhookSecret) headers['x-elvaren-signature'] = signBody(body, cfg.n8n.webhookSecret);
  try { const r = await fetchImpl(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(8000) }); return { ok: r.ok }; } catch (e) { return { ok: false, error: String(e.message || e) }; }
}
