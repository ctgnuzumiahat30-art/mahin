import { DISTRICTS } from './catalog.js';
import { MAX_ITEMS, MAX_QTY, normalizeCart, priceItems, quote, normCode } from './pricing.js';
import { tx } from './db.js';
import { validPhone, checkEmail, domainCanReceiveMail, clean } from './validate.js';
import { STATUS_BY_KEY } from './statuses.js';

export { MAX_ITEMS, MAX_QTY, normalizeCart, priceItems };

const PHONE_MSG = '01 দিয়ে শুরু করে ঠিক ১১ ডিজিটের নম্বর দিন (যেমন 01712345678)';

export async function validateOrder(body, cfg, { db, userId } = {}) {
  const b = body && typeof body === 'object' ? body : {};
  const errors = {};

  const cart = normalizeCart(b.items);
  if (!cart.length) errors.items = 'কার্টে কোনো বৈধ পণ্য নেই';

  const name = clean(b.name, 80);
  if (name.length < 2) errors.name = 'আপনার নাম লিখুন (কমপক্ষে ২ অক্ষর)';

  const phone = validPhone(b.phone);
  if (!phone) errors.phone = `ফোন নম্বর: ${PHONE_MSG}`;
  const whatsapp = validPhone(b.whatsapp);
  if (!whatsapp) errors.whatsapp = `WhatsApp নম্বর: ${PHONE_MSG}`;

  let email = '';
  const em = checkEmail(b.email);
  if (!em.ok) errors.email = em.reason === 'typo' ? `ইমেইল ঠিক আছে তো? আপনি কি ${em.suggestion} বোঝাতে চেয়েছেন?` : 'সঠিক ইমেইল ঠিকানা দিন (যেমন name@gmail.com)';
  else {
    email = em.email;
    if (cfg.checkEmailMx && !(await domainCanReceiveMail(email.split('@')[1]))) errors.email = 'এই ইমেইল ডোমেইনে মেইল পাঠানো যায় না — সঠিক ইমেইল দিন';
  }

  const district = String(b.district ?? '');
  if (!DISTRICTS.includes(district)) errors.district = 'জেলা নির্বাচন করুন';

  const address = clean(b.address, 300);
  if (address.length < 10) errors.address = 'ডেলিভারির জন্য পূর্ণ ঠিকানা লিখুন (কমপক্ষে ১০ অক্ষর)';

  if (Object.keys(errors).length) return { errors };

  const giftWrap = !!b.giftWrap;
  const q = quote({ cart, district, coupon: b.coupon, giftWrap }, { db, userId });
  if (q.couponError) return { errors: { coupon: q.couponError } };
  return {
    value: {
      items: q.items, subtotal: q.subtotal, totalQty: q.totalQty, name, phone, whatsapp, email, district, address,
      note: clean(b.note, 300),
      clientToken: clean(b.clientToken, 64) || null,
      deliveryZone: q.delivery.zone, deliveryFee: q.delivery.fee,
      discount: q.discount,
      extras: { bundleOff: q.bundle.off, couponCode: q.coupon?.code || '', couponOff: q.coupon?.off || 0, giftWrapFee: q.giftWrapFee, giftNote: giftWrap ? clean(b.giftNote, 160) : '', deliveryRaw: q.delivery.raw, freeDelivery: q.delivery.free },
      total: q.total,
    },
  };
}

/* ---------- persistence ---------- */
const nowIso = () => new Date().toISOString();

export function rowToOrder(r, events = []) {
  if (!r) return null;
  return {
    id: r.id, invoice: r.invoice, userId: r.user_id, status: r.status,
    customer: { name: r.name, phone: r.phone, whatsapp: r.whatsapp, email: r.email, address: r.address, district: r.district, note: r.note },
    items: JSON.parse(r.items_json), totalQty: r.total_qty, subtotal: r.subtotal,
    delivery: { zone: r.delivery_zone, fee: r.delivery_fee }, discount: r.discount || 0, extras: JSON.parse(r.extras_json || '{}'), total: r.total, payment: r.payment,
    courier: r.courier, trackingId: r.tracking_id, createdAt: r.created_at, updatedAt: r.updated_at,
    events: events.map((e) => ({ status: e.status, note: e.note, source: e.source, at: e.created_at })),
    webhook: { state: r.webhook_state, attempts: r.webhook_attempts, error: r.webhook_error },
  };
}

/** What a customer is allowed to see. */
export function publicOrder(o) {
  const { userId, webhook, ...rest } = o;
  return { ...rest, statusInfo: STATUS_BY_KEY[o.status] };
}

export function createOrder(db, cfg, user, v) {
  return tx(db, () => {
    if (v.clientToken) {
      const dup = db.prepare('SELECT * FROM orders WHERE user_id = ? AND client_token = ?').get(user.id, v.clientToken);
      if (dup) return { order: getOrder(db, dup.invoice), duplicate: true };
    }
    const last = db.prepare('SELECT MAX(id) AS m FROM orders').get().m || 0;
    const id = Math.max(last, cfg.invoiceStart - 1) + 1;
    const invoice = `${cfg.invoicePrefix}${id}`;
    const t = nowIso();
    db.prepare(`INSERT INTO orders (id, invoice, user_id, client_token, status, name, phone, whatsapp, email, address, district, note,
      items_json, total_qty, subtotal, delivery_zone, delivery_fee, total, payment, discount, extras_json, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(id, invoice, user.id, v.clientToken, v.name, v.phone, v.whatsapp, v.email, v.address, v.district, v.note,
        JSON.stringify(v.items), v.totalQty, v.subtotal, v.deliveryZone, v.deliveryFee, v.total, cfg.payment, v.discount, JSON.stringify(v.extras), t, t);
    db.prepare('INSERT INTO order_events (order_id, status, note, source, created_at) VALUES (?, ?, ?, ?, ?)').run(id, 'pending', 'অর্ডার গ্রহণ করা হয়েছে', 'website', t);
    db.prepare("UPDATE carts SET items_json = '[]', updated_at = ? WHERE user_id = ?").run(t, user.id);
    return { order: getOrder(db, invoice), duplicate: false };
  });
}

function eventsFor(db, ids) {
  if (!ids.length) return new Map();
  const rows = db.prepare(`SELECT * FROM order_events WHERE order_id IN (${ids.map(() => '?').join(',')}) ORDER BY id`).all(...ids);
  const m = new Map();
  for (const e of rows) { if (!m.has(e.order_id)) m.set(e.order_id, []); m.get(e.order_id).push(e); }
  return m;
}

export function getOrder(db, invoice) {
  const r = db.prepare('SELECT * FROM orders WHERE invoice = ? COLLATE NOCASE').get(String(invoice || '').trim());
  return r ? rowToOrder(r, eventsFor(db, [r.id]).get(r.id) || []) : null;
}

export function listOrders(db, { userId, status, since, limit = 50 } = {}) {
  const where = [], args = [];
  if (userId) { where.push('user_id = ?'); args.push(userId); }
  if (status) { where.push('status = ?'); args.push(status); }
  if (since) { where.push('created_at > ?'); args.push(since); }
  const rows = db.prepare(`SELECT * FROM orders ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`).all(...args, Math.min(200, limit));
  const ev = eventsFor(db, rows.map((r) => r.id));
  return rows.map((r) => rowToOrder(r, ev.get(r.id) || []));
}

/** Change status (called by n8n). Returns { order, changed }. */
export function setStatus(db, invoice, statusKey, { note = '', courier, trackingId, source = 'n8n' } = {}) {
  return tx(db, () => {
    const cur = db.prepare('SELECT * FROM orders WHERE invoice = ? COLLATE NOCASE').get(String(invoice || '').trim());
    if (!cur) return null;
    const changed = cur.status !== statusKey;
    const t = nowIso();
    db.prepare('UPDATE orders SET status = ?, courier = ?, tracking_id = ?, updated_at = ? WHERE id = ?')
      .run(statusKey, courier != null ? clean(courier, 60) : cur.courier, trackingId != null ? clean(trackingId, 80) : cur.tracking_id, changed || note ? t : cur.updated_at, cur.id);
    if (changed || note) db.prepare('INSERT INTO order_events (order_id, status, note, source, created_at) VALUES (?, ?, ?, ?, ?)').run(cur.id, statusKey, clean(note, 200), source, t);
    return { order: getOrder(db, cur.invoice), changed };
  });
}
