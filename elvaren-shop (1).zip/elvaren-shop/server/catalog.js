import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './config.js';

export const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'server', 'catalog.json'), 'utf8'));

export const perfumeBySlug = Object.fromEntries(catalog.perfumes.map((p) => [p.slug, p]));
export const sizeById = Object.fromEntries(catalog.sizes.map((s) => [s.id, s]));

export const DISTRICTS = [
  'Bagerhat', 'Bandarban', 'Barguna', 'Barishal', 'Bhola', 'Bogura', 'Brahmanbaria', 'Chandpur', 'Chattogram', 'Chuadanga',
  'Cox\'s Bazar', 'Cumilla', 'Dhaka', 'Dinajpur', 'Faridpur', 'Feni', 'Gaibandha', 'Gazipur', 'Gopalganj', 'Habiganj',
  'Jamalpur', 'Jashore', 'Jhalokathi', 'Jhenaidah', 'Joypurhat', 'Khagrachhari', 'Khulna', 'Kishoreganj', 'Kurigram', 'Kushtia',
  'Lakshmipur', 'Lalmonirhat', 'Madaripur', 'Magura', 'Manikganj', 'Meherpur', 'Moulvibazar', 'Munshiganj', 'Mymensingh', 'Naogaon',
  'Narail', 'Narayanganj', 'Narsingdi', 'Natore', 'Netrokona', 'Nilphamari', 'Noakhali', 'Pabna', 'Panchagarh', 'Patuakhali',
  'Pirojpur', 'Rajbari', 'Rajshahi', 'Rangamati', 'Rangpur', 'Satkhira', 'Shariatpur', 'Sherpur', 'Sirajganj', 'Sunamganj',
  'Sylhet', 'Tangail', 'Thakurgaon',
];

/** Delivery charge by district: inside (Dhaka, Chattogram) vs outside. */
export function deliveryFor(district) {
  const inside = catalog.delivery.insideDistricts.includes(district);
  return { zone: inside ? 'inside' : 'outside', fee: inside ? catalog.delivery.insideFee : catalog.delivery.outsideFee };
}

/** Public (browser-safe) slice of the catalog. */
export function publicCatalog() {
  return {
    sizes: catalog.sizes,
    delivery: catalog.delivery,
    offers: { ...catalog.offers, coupons: undefined },
    districts: DISTRICTS,
    ingredients: catalog.ingredients,
    perfumes: catalog.perfumes.map((p) => ({ slug: p.slug, name: p.name, mood: p.mood, short: p.short, quote: p.quote, orbit: p.orbit, theme: p.theme, times: p.times, seasons: p.seasons, family: p.family, best: p.best })),
  };
}
