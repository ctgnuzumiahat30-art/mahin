// Server-side HTML for every page. Content comes from catalog.json (single source of truth).
import { catalog, publicCatalog, DISTRICTS } from './catalog.js';
import { STATUSES } from './statuses.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rgbOf = (hex) => { const h = hex.replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)).join(','); };
const S3 = catalog.sizes.find((s) => s.id === '3ml') || catalog.sizes[0];
const S6 = catalog.sizes.find((s) => s.id === '6ml') || catalog.sizes[catalog.sizes.length - 1];
const SAVE6 = S6.compareAt ? S6.compareAt - S6.price : 0;
const D = catalog.delivery;
const OFF = catalog.offers || {};
const ING = catalog.ingredients;
const FX = { 'vampire-blood': 'petal', 'creed-aventus': 'spark', 'adg-profumo': 'bubble', 'layton': 'ember', 'valentino': 'dust' };
const ing = (k) => ING[k] || { en: k, bn: k, img: `${k}.svg` };

const ICON = {
  bag: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 8h12l1 12H5L6 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17L17 7M9 7h8v8"/></svg>',
  left: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
  right: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  quote: '<svg viewBox="0 0 32 24" aria-hidden="true"><path d="M0 24V14C0 6 4 1 12 0v5C8 6 6 8.5 6 12h6v12H0zm18 0V14C18 6 22 1 30 0v5c-4 1-6 3.500-6 7h6v12H18z"/></svg>',
  wa: '<svg viewBox="0 0 24 24"><path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.95L2 22l5.2-1.5A9.9 9.9 0 1 0 12.04 2Zm5.8 14c-.25.7-1.45 1.33-2 1.4-.52.07-1.17.1-1.9-.12a17 17 0 0 1-1.72-.64c-3-1.3-4.95-4.34-5.1-4.54-.15-.2-1.2-1.6-1.2-3.05 0-1.450.76-2.16 1.03-2.46.27-.3.6-.37.8-.37h.57c.18 0 .43-.07.67.52.25.6.84 2.06.92 2.2.07.16.12.33.02.53-.1.2-.15.32-.3.5-.15.17-.32.38-.45.5-.15.16-.3.33-.13.64.17.3.77 1.27 1.65 2.05 1.14 1 2.1 1.32 2.4 1.46.3.15.47.12.65-.07.17-.2.75-.87.95-1.17.2-.3.4-.25.67-.15.27.1 1.72.8 2.02.96.3.15.5.22.57.35.07.12.07.72-.18 1.4Z"/></svg>',
  check: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12l4 4L19 6"/></svg>',
  truck: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7zM7 19a1.600 1.600 0 1 0 0 .01M17 19a1.600 1.600 0 1 0 0 .01"/></svg>',
  cash: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.800"/><path d="M6 9v.01M18 15v.01"/></svg>',
  pin: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-6.100 7-11a7 7 0 0 0-14 0c0 4.900 7 11 7 11z"/><circle cx="12" cy="10" r="2.500"/></svg>',
  user: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-4.500 4.500-6.500 8-6.500s7 2 8 6.500"/></svg>',
  star: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.500 5.500L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.500-.5z"/></svg>',
};

/* ------------------------------------------------------------------ layout */
function layout(ctx, { title, desc, path = '/', ogImage = '/assets/vampire-blood-g1.webp', body, cls = '', scripts = [], head = '', style = '' }) {
  const { cfg, build } = ctx;
  const base = cfg.siteUrl;
  const boot = {
    catalog: publicCatalog(),
    google: cfg.googleClientId || null,
    devAuth: !!cfg.devAuth,
    contact: { phone: cfg.contact.phone, whatsapp: cfg.contact.whatsapp, email: cfg.contact.email, facebook: cfg.contact.facebook, instagram: cfg.contact.instagram },
    statuses: STATUSES,
    track: { fb: cfg.fbPixelId || '', ga: cfg.gaId || '' },
  };
  const v = `?v=${build}`;
  const c = cfg.contact;
  return `<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${base ? `<link rel="canonical" href="${esc(base + path)}">` : ''}
<meta name="theme-color" content="#F4EBDF">
<meta property="og:type" content="website"><meta property="og:site_name" content="Elvaren">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:image" content="${esc(base + ogImage)}">
<link rel="icon" href="/assets/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500;1,600&family=Hind+Siliguri:wght@400;500;600;700&family=Syncopate:wght@400;700&family=Abril+Fatface&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css${v}">
${head}
</head>
<body class="${cls}"${style ? ` style="${style}"` : ''}>
${OFF.announce ? `<div class="announce"><span>${esc(OFF.announce)}</span></div>` : ''}
<header class="site-header">
  <div class="wrap nav">
    <a class="brand" href="/" aria-label="Elvaren home"><img src="/assets/logo.png" alt="Elvaren" width="42" height="42"><span>ELVAREN</span></a>
    <nav class="nav-pill" id="menu" aria-label="Main">
      <a href="/">Home</a><a href="/#collection">Collection</a><a href="/#showcase">Scents</a><a href="/#delivery">Delivery</a><a href="/#faq">FAQ</a>
    </nav>
    <div class="nav-right">
      <a class="pill-btn cart-pill" href="/cart" aria-label="কার্ট"><span class="bagc">${ICON.bag}</span><span class="lbl">Cart</span><b id="cart-count" hidden>0</b></a>
      <button class="pill-btn" id="auth-btn" type="button"><span class="lbl">Sign in</span></button>
      <button class="burger" aria-label="মেনু" aria-expanded="false" aria-controls="menu"><span></span></button>
    </div>
  </div>
</header>
<main id="main">
${body}
</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="foot">
      <div>
        <a class="brand" href="/"><img src="/assets/logo.png" alt="" width="42" height="42"><span>ELVAREN</span></a>
        <p class="foot-tag">More than a fragrance, a feeling.<br>৫টি সিগনেচার সুগন্ধি · ৩ ml ও ৬ ml সাইজে।</p>
        <form class="news" id="news-form" novalidate><label for="news-email">নতুন অফার সবার আগে পেতে <b>WELCOME10</b> কুপন নিন</label><div class="news-row"><input id="news-email" type="email" placeholder="আপনার ইমেইল" autocomplete="email" maxlength="254"><button class="btn btn-cream btn-sm" type="submit">কুপন নিন</button></div><div class="hp" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div><p class="news-msg" id="news-msg" role="status"></p></form>
      </div>
      <div><h4>Collection</h4><ul>${catalog.perfumes.map((p) => `<li><a href="/perfume/${p.slug}">${esc(p.name)}</a></li>`).join('')}</ul></div>
      <div><h4>Help</h4><ul>
        <li><a href="/account">আমার অর্ডার ও ট্র্যাকিং</a></li>
        <li><a href="/#delivery">ডেলিভারি চার্জ</a></li>
        <li><a href="/policies">নীতিমালা (Policies)</a></li>
        <li><a href="/#faq">সাধারণ প্রশ্ন</a></li>
      </ul></div>
      <div><h4>Contact</h4><ul>
        ${c.phone ? `<li><a href="tel:${esc(c.phone)}">${esc(c.phone)}</a></li>` : ''}
        ${c.whatsapp ? `<li><a href="https://wa.me/${esc(c.whatsapp)}" target="_blank" rel="noopener">WhatsApp</a></li>` : ''}
        ${c.email ? `<li><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></li>` : ''}
        ${c.facebook ? `<li><a href="${esc(c.facebook)}" target="_blank" rel="noopener">Facebook</a></li>` : ''}
        ${c.instagram ? `<li><a href="${esc(c.instagram)}" target="_blank" rel="noopener">Instagram</a></li>` : ''}
        ${!(c.phone || c.whatsapp || c.email || c.facebook || c.instagram) ? '<li>যোগাযোগের তথ্য শীঘ্রই যুক্ত হবে</li>' : ''}
      </ul></div>
    </div>
    <div class="copy">
      <span>© ${new Date().getFullYear()} Elvaren. সর্বস্বত্ব সংরক্ষিত।</span>
      <span>সুগন্ধির নামগুলো শুধু সুগন্ধির ঘরানা বোঝাতে ব্যবহৃত; সংশ্লিষ্ট ব্র্যান্ডগুলোর সাথে Elvaren-এর কোনো সম্পর্ক বা অনুমোদন নেই।</span>
    </div>
  </div>
</footer>
${c.whatsapp ? `<a class="wa-float on" href="https://wa.me/${esc(c.whatsapp)}" target="_blank" rel="noopener" aria-label="WhatsApp-এ মেসেজ করুন">${ICON.wa}</a>` : ''}

<div class="modal" id="login-modal" role="dialog" aria-modal="true" aria-labelledby="lg-h">
  <div class="modal-box">
    <button class="modal-x" data-close aria-label="বন্ধ করুন">×</button>
    <div class="tick">${ICON.user}</div>
    <h3 id="lg-h">লগইন করুন</h3>
    <p>অর্ডার করতে, কার্ট সেভ রাখতে এবং অর্ডারের লাইভ স্ট্যাটাস দেখতে আপনার Google অ্যাকাউন্ট দিয়ে লগইন করুন।</p>
    <div id="g-btn-slot" class="g-slot"></div>
    <p class="g-missing" id="g-missing" hidden>Google লগইন এখনও চালু হয়নি (GOOGLE_CLIENT_ID সেট করা হয়নি)।</p>
    <form id="dev-login" class="dev-login" hidden>
      <small>Dev login (শুধু টেস্টিং)</small>
      <input name="email" type="email" placeholder="test@gmail.com" required>
      <input name="name" placeholder="Test User">
      <button class="btn btn-dark" type="submit">Dev login</button>
    </form>
  </div>
</div>
<div class="toasts" id="toasts" aria-live="polite"></div>

<script type="application/json" id="boot">${JSON.stringify(boot).replace(/</g, '\\u003c')}</script>
${cfg.googleClientId ? '<script src="https://accounts.google.com/gsi/client" async defer></script>' : ''}
<script src="/assets/app.js${v}"></script>
<script src="/assets/track.js${v}"></script>
${scripts.map((s) => `<script src="/assets/${s}${v}"></script>`).join('\n')}
</body>
</html>`;
}

/* ------------------------------------------------------------------ pieces */
function ingImg(k, cls = '', eager = false) {
  const i = ing(k);
  return `<img class="${cls}" src="/assets/ing/${esc(i.img)}" alt="${esc(i.en)}" width="300" height="300" loading="${eager ? 'eager' : 'lazy'}" decoding="async">`;
}

function heroScene(p, i, extra = '') {
  const ings = p.orbit.map((k, j) => `<span class="ing s${j}" style="--d:${j * 70}ms">${ingImg(k, '', i === 0)}</span>`).join('');
  return `<div class="h-scene${i === 0 ? ' on' : ''}" data-i="${i}"${extra}>
    <span class="halo"></span>
    ${ings}
    <div class="h-bottle bt"><i class="cs"></i><i class="rf" style="--img:url(/assets/${p.slug}.webp)"></i><img src="/assets/${p.slug}.webp" alt="Elvaren ${esc(p.name)} perfume" width="701" height="1445" ${i === 0 ? 'fetchpriority="high"' : 'loading="lazy"'}><i class="sh" style="--img:url(/assets/${p.slug}.webp)"></i></div>
  </div>`;
}

function miniCard(p) {
  return `<a class="mc" href="/perfume/${p.slug}" style="--bg:${rgbOf(p.theme.bg)};--g:${rgbOf(p.theme.glow)};--w:${rgbOf(p.theme.pastel)}">
    <span class="mc-img"><img src="/assets/${p.slug}-sm.webp" alt="" width="100" height="206" loading="lazy"></span>
    <span class="mc-t"><b>${esc(p.name)}</b><small>(${esc(S6.label)} · ৳${S6.price})</small>
    <span class="mc-b"><span class="pill-s">Explore Shop</span><span class="circ-s">${ICON.arrow}</span></span></span>
  </a>`;
}

function card(p) {
  const t = p.theme;
  return `<article class="card reveal" style="--bg:${rgbOf(t.bg)};--glow:${rgbOf(t.glow)}">
  ${SAVE6 ? `<span class="badge">${esc(S6.label)}-এ ৳${SAVE6} ছাড়</span>` : ''}
  <a class="pic" href="/perfume/${p.slug}" aria-label="${esc(p.name)} দেখুন"><img src="/assets/${p.slug}-sm.webp" alt="Elvaren ${esc(p.name)}" loading="lazy" width="210" height="430"></a>
  <div class="info">
    <span class="mood">${esc(p.mood)}</span>
    <h3>${esc(p.name)}</h3>
    <div class="ing-row">${p.orbit.slice(0, 4).map((k) => `<img src="/assets/ing/${esc(ing(k).img)}" alt="${esc(ing(k).en)}" title="${esc(ing(k).en)}" width="30" height="30" loading="lazy">`).join('')}</div>
    <div class="price"><s>${S6.compareAt ? '৳' + S6.compareAt : ''}</s><strong>৳${S6.price}</strong><small>${esc(S6.label)}</small></div>
    <p class="alt-size">${esc(S3.label)} — ৳${S3.price}</p>
    <div class="card-btns"><a class="btn btn-light" href="/perfume/${p.slug}">দেখুন ও অর্ডার</a><button class="btn-add" type="button" data-quick="${p.slug}" aria-label="${esc(p.name)} ৬ ml কার্টে যোগ করুন" title="৬ ml কার্টে যোগ করুন">+</button></div>
  </div>
</article>`;
}

/* ------------------------------------------------------------------ HOME */
function showcase() {
  const P = catalog.perfumes;
  const words = P.map((p, i) => `<div class="sw" data-i="${i}" aria-hidden="true"><span>${esc(p.headline[0])}</span><span>${esc(p.headline[1] || '')}</span></div>`).join('');
  const floaters = P.map((p, i) => `<div class="sf" data-i="${i}" aria-hidden="true">${p.orbit.slice(1).map((k, j) => `<span class="f f${j}">${ingImg(k)}</span>`).join('')}</div>`).join('');
  const bottles = P.map((p) => `<div class="sb bt"><i class="cs"></i><i class="rf" style="--img:url(/assets/${p.slug}.webp)"></i><img src="/assets/${p.slug}.webp" alt="Elvaren ${esc(p.name)}" width="701" height="1445"><i class="sh" style="--img:url(/assets/${p.slug}.webp)"></i></div>`).join('');
  const bubbles = P.map((p, i) => `<div class="sbub" data-i="${i}" aria-hidden="true"><span class="ring"><span class="spin">${ingImg(p.orbit[0])}</span></span><small>${esc(ing(p.orbit[0]).en)}</small></div>`).join('');
  const infos = P.map((p, i) => {
    const notes = [...new Set([...p.pyramid.top, ...p.pyramid.heart, ...p.pyramid.base])].slice(0, 5).map((k) => `<span>${esc(ing(k).en)}</span>`).join('');
    return `<div class="si" data-i="${i}">
      <div class="si-l"><span class="si-num">0${i + 1} <i></i> ${esc(p.family)}</span><p class="si-mood">${esc(p.mood)}</p><p class="si-desc">${esc(p.desc)}</p><div class="si-notes">${notes}</div></div>
      <div class="si-r"><div class="si-price"><s>${S6.compareAt ? '৳' + S6.compareAt : ''}</s><strong>৳${S6.price}</strong><small>${esc(S6.label)}</small></div><a class="btn btn-cream" href="/perfume/${p.slug}">বিস্তারিত ও অর্ডার</a></div>
    </div>`;
  }).join('');
  const dots = P.map((p, i) => `<button class="dot" data-i="${i}" aria-label="${esc(p.name)}"></button>`).join('');
  return `<section class="show" id="showcase" aria-label="Elvaren scent showcase" data-n="${P.length}"
  data-fx="${P.map((p) => FX[p.slug] || 'spark').join(',')}"
  data-c1="${P.map((p) => rgbOf(p.theme.bg)).join('|')}" data-c2="${P.map((p) => rgbOf(p.theme.glow)).join('|')}" data-c3="${P.map((p) => rgbOf(p.theme.bg2)).join('|')}">
  <div class="show-sticky">
    <div class="sh-bg"></div><div class="sh-noise"></div>
    <canvas class="show-fx" aria-hidden="true"></canvas>
    <div class="sh-words">${words}</div>
    <div class="sh-floaters">${floaters}</div>
    <div class="show-stage">${bottles}</div>
    <div class="sh-bubbles">${bubbles}</div>
    <div class="sh-info">${infos}</div>
    <div class="sh-badge" aria-hidden="true"><svg viewBox="0 0 120 120"><defs><path id="cp" d="M60,60 m-44,0 a44,44 0 1,1 88,0 a44,44 0 1,1 -88,0"/></defs><text><textPath href="#cp" startOffset="0">SCROLL TO EXPLORE · SCROLL TO EXPLORE ·</textPath></text></svg><span>${ICON.arrow}</span></div>
    <div class="show-top"><span class="sh-brand">ELVAREN · SCENT COLLECTION</span><span class="show-count"><b id="show-cur">01</b> / 0${P.length}</span></div>
    <nav class="show-dots" aria-label="সুগন্ধি বদলান">${dots}</nav>
  </div>
</section>`;
}

const FAQ = [
  ['কীভাবে অর্ডার করবো?', 'পছন্দের সুগন্ধির পেজে গিয়ে সাইজ (৩ ml / ৬ ml) বেছে “কার্টে যোগ করুন” চাপুন। কার্টে গিয়ে Google দিয়ে লগইন করে নাম, মোবাইল নম্বর, WhatsApp নম্বর, ইমেইল ও ঠিকানা দিয়ে অর্ডার কনফার্ম করুন। এক অর্ডারে একাধিক সুগন্ধি নিতে পারবেন।'],
  ['ডেলিভারি চার্জ কত?', `ঢাকা ও চট্টগ্রামে ডেলিভারি চার্জ ৳${D.insideFee}। এর বাইরে সব জেলায় ৳${D.outsideFee}। জেলা বাছাই করলেই চেকআউটে চার্জ হিসাব হয়ে যায়।`],
  ['পেমেন্ট কীভাবে করবো?', 'ক্যাশ অন ডেলিভারি (COD) — পণ্য হাতে পেয়ে টাকা দিন।'],
  ['অর্ডার কোথায় পৌঁছালো দেখবো কীভাবে?', 'লগইন করে “আমার অর্ডার” পেজে গেলে লাইভ স্ট্যাটাস দেখা যায় — Pending, Confirmed, Packed, In Transit, Delivered, Returned ইত্যাদি। স্ট্যাটাস বদলালে পেজ নিজে থেকেই আপডেট হয়।'],
  ['কেন Google লগইন দরকার?', 'আপনার অর্ডারের ইতিহাস, কার্ট ও লাইভ ট্র্যাকিং নিরাপদে এক জায়গায় রাখতে। আমরা শুধু আপনার নাম ও ইমেইল সংরক্ষণ করি।'],
  ['৩ ml আর ৬ ml এর পার্থক্য কী?', `সুগন্ধি একই, শুধু পরিমাণ আলাদা। নতুন সুগন্ধি ট্রাই করতে ${S3.label} (৳${S3.price}), আর নিয়মিত ব্যবহারে ${S6.label} (৳${S6.price}${S6.compareAt ? `, আগের দাম ৳${S6.compareAt}` : ''})।`],
];
const faqHtml = () => FAQ.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('');

export function renderHome(ctx) {
  const P = catalog.perfumes;
  const p0 = P[0];
  const stripItems = ['More than a fragrance', `৬ ml মাত্র ৳${S6.price}`, '৫টি সিগনেচার সুগন্ধি', `ঢাকা-চট্টগ্রামে ডেলিভারি ৳${D.insideFee}`, 'ক্যাশ অন ডেলিভারি', 'A feeling'];
  const strip = [...stripItems, ...stripItems].map((t, i) => `<span>${esc(t)}</span><img src="/assets/ing/${esc(ing(P[i % P.length].orbit[0]).img)}" alt="" width="28" height="28">`).join('');
  const flow = STATUSES.filter((s) => s.step >= 0).map((s) => `<li><span>${esc(s.sheet)}</span><small>${esc(s.bn)}</small></li>`).join('');
  const body = `
<section class="hero2" id="top" data-n="${P.length}">
  <div class="h-bg" aria-hidden="true">${P.map((p, i) => `<i class="h-bgi${i === 0 ? ' on' : ''}" style="--w:${rgbOf(p.theme.pastel)};--g:${rgbOf(p.theme.glow)}"></i>`).join('')}</div>
  <div class="wrap h-grid">
    <div class="h-copy">
      <div class="h-pill"><span class="h-ings">${['bergamot', 'rose', 'amber'].map((k) => `<img src="/assets/ing/${esc(ing(k).img)}" alt="" width="30" height="30">`).join('')}</span><span class="h-pill-t"><b>5</b> signature scents · ${esc(S3.label)} &amp; ${esc(S6.label)}</span></div>
      <h1>Discover your<br>signature <em>Perfume</em><br>today</h1>
      <p class="lead">প্রতিটি সুগন্ধি একেকটি অনুভূতি। আপনার মেজাজ, ঋতু আর গল্পের সাথে মিলিয়ে বেছে নিন নিজের সিগনেচার সেন্ট — ফল, ফুল আর কাঠের আসল ঘ্রাণের ঘরানায়।</p>
      <div class="h-cta"><a class="btn-pill dark" href="#collection">Explore Shop</a><a class="btn-circ" href="#collection" aria-label="Explore">${ICON.arrow}</a></div>
    </div>

    <div class="h-vis" id="h-vis">
      <span class="h-ring r1"></span><span class="h-ring r2"></span>
      ${P.map((p, i) => heroScene(p, i)).join('')}
      <img class="h-drop d1" src="/assets/ing/droplet.svg" alt="" width="30" height="40"><img class="h-drop d2" src="/assets/ing/droplet.svg" alt="" width="22" height="30"><img class="h-drop d3" src="/assets/ing/sparkle-gold.svg" alt="" width="34" height="34"><img class="h-drop d4" src="/assets/ing/sparkle-gold.svg" alt="" width="22" height="22">
      <div class="h-cards" id="h-cards">${miniCard(P[1])}${miniCard(P[2])}</div>
    </div>

    <div class="h-story glass" id="h-story">
      <span class="qi">${ICON.quote}</span>
      <p class="q" id="h-quote">${esc(p0.quote)}</p>
      <div class="h-who">
        <a class="who" id="h-who" href="/perfume/${p0.slug}"><span class="who-img"><img src="/assets/${p0.slug}-sm.webp" alt="" width="40" height="82"></span><span><b>${esc(p0.name)}</b><small>${esc(p0.mood)}</small></span></a>
        <div class="h-nav"><span class="h-count"><b id="h-cur">01</b>/0${P.length}</span><button type="button" class="circ" id="h-prev" aria-label="আগেরটি">${ICON.left}</button><button type="button" class="circ dark" id="h-next" aria-label="পরেরটি">${ICON.right}</button></div>
      </div>
    </div>
  </div>
</section>
<div class="strip" aria-hidden="true"><div class="strip-track">${strip}</div></div>

${showcase()}

<section class="section" id="collection">
  <div class="wrap">
    <div class="section-head reveal">
      <span class="eyebrow">The Collection</span>
      <h2>আপনার পছন্দের সুগন্ধি বেছে নিন</h2>
      <p>${esc(S6.label)} — ${S6.compareAt ? `<s>৳${S6.compareAt}</s> ` : ''}<b>৳${S6.price}</b> · ${esc(S3.label)} — <b>৳${S3.price}</b>। ঢাকা ও চট্টগ্রামে ডেলিভারি ৳${D.insideFee}, অন্যত্র ৳${D.outsideFee}।</p>
    </div>
    <div class="grid">${P.map(card).join('')}</div>
  </div>
</section>

<section class="section features" id="why">
  <div class="wrap">
    <div class="section-head reveal"><span class="eyebrow">Why Elvaren</span><h2>ছোট বোতলে বড় অনুভূতি</h2></div>
    <div class="feat-grid">
      <div class="feat reveal">${ICON.star}<h3>৫টি আলাদা মেজাজ</h3><p>ফ্রেশ, বোল্ড, উষ্ণ কিংবা মার্জিত — প্রতিটির নোটস, ঋতু ও সময় পেজেই দেখে নিন।</p></div>
      <div class="feat reveal">${ICON.pin}<h3>ঢাকা ও চট্টগ্রামে ৳${D.insideFee}</h3><p>বাকি সব জেলায় ডেলিভারি ৳${D.outsideFee}। চেকআউটে জেলা বাছলেই চার্জ হিসাব।</p></div>
      <div class="feat reveal">${ICON.cash}<h3>ক্যাশ অন ডেলিভারি</h3><p>পণ্য হাতে পেয়ে টাকা দিন। আগে থেকে কোনো পেমেন্ট নেই।</p></div>
      <div class="feat reveal">${ICON.truck}<h3>লাইভ অর্ডার ট্র্যাকিং</h3><p>লগইন করে দেখুন আপনার অর্ডার এখন কোথায় — Packed, In Transit, Delivered।</p></div>
    </div>
  </div>
</section>

<section class="section finder" id="finder">
  <div class="wrap narrow">
    <div class="section-head reveal"><span class="eyebrow">Scent Finder</span><h2>আপনার সিগনেচার সেন্ট খুঁজে নিন</h2><p>মাত্র ৩টি প্রশ্ন — আপনার জন্য কোনটি মানানসই, আমরা বলে দেবো।</p></div>
    <div class="fq reveal" id="fq" aria-live="polite"></div>
  </div>
</section>

<section class="section" id="delivery">
  <div class="wrap">
    <div class="section-head reveal"><span class="eyebrow">Delivery &amp; Payment</span><h2>ডেলিভারি ও অর্ডারের ধাপ</h2></div>
    <div class="del-grid">
      <div class="del reveal"><b>৳${D.insideFee}</b><h3>ঢাকা ও চট্টগ্রাম</h3><p>ঢাকা ও চট্টগ্রাম জেলার ভেতরে ডেলিভারি চার্জ।</p></div>
      <div class="del reveal"><b>৳${D.outsideFee}</b><h3>অন্যান্য সব জেলা</h3><p>ঢাকা ও চট্টগ্রামের বাইরে সারা বাংলাদেশে।</p></div>
      <div class="del reveal"><b>COD</b><h3>ক্যাশ অন ডেলিভারি</h3><p>পণ্য হাতে পেয়ে পেমেন্ট করুন।</p></div>
    </div>
    <div class="flow reveal"><h3>আপনার অর্ডার যেভাবে এগোয়</h3><ol>${flow}</ol><p>লগইন করে “আমার অর্ডার” পেজে এই স্ট্যাটাস লাইভ দেখতে পাবেন। ডেলিভারি না হলে <b>Returned</b>, বাতিল হলে <b>Cancelled</b> দেখাবে।</p></div>
  </div>
</section>

<section class="section" id="faq" style="padding-top:0">
  <div class="wrap narrow">
    <div class="section-head reveal"><span class="eyebrow">FAQ</span><h2>সাধারণ প্রশ্ন</h2></div>
    <div class="faq">${faqHtml()}</div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="wrap">
    <div class="cta-band reveal"><h2>আজই বেছে নিন আপনার সিগনেচার সেন্ট</h2><p>${esc(S6.label)} মাত্র ৳${S6.price} — ৫টি সুগন্ধি, এক অনন্য অনুভূতি।</p><a class="btn" href="#collection">এখনই অর্ডার করুন</a></div>
  </div>
</section>`;
  return layout(ctx, {
    title: 'Elvaren — Discover your signature perfume | ৩ ml ৳110 · ৬ ml ৳190',
    desc: `Elvaren: ৫টি সিগনেচার সুগন্ধি — ${S6.label} মাত্র ৳${S6.price}, ${S3.label} ৳${S3.price}। ঢাকা ও চট্টগ্রামে ডেলিভারি ৳${D.insideFee}, ক্যাশ অন ডেলিভারি।`,
    path: '/', body, cls: 'home', scripts: ['home.js', 'showcase.js', 'finder.js'],
    head: '<link rel="preload" as="image" href="/assets/vampire-blood.webp">',
  });
}

/* ------------------------------------------------------------------ PRODUCT */
const LV = {
  longevity: ['খুব হালকা', 'হালকা', 'মাঝারি', 'দীর্ঘস্থায়ী', 'খুব দীর্ঘস্থায়ী'],
  projection: ['কাছাকাছি', 'মৃদু', 'মাঝারি', 'জোরালো', 'খুব জোরালো'],
  intensity: ['মৃদু', 'হালকা', 'মাঝারি', 'গাঢ়', 'খুব গাঢ়'],
};
const SEASONS = [['spring', 'বসন্ত'], ['summer', 'গ্রীষ্ম'], ['autumn', 'শরৎ'], ['winter', 'শীত']];
const TIMES = [['day', 'দিন'], ['evening', 'সন্ধ্যা'], ['night', 'রাত']];

export function renderProduct(ctx, p) {
  const t = p.theme;
  const others = catalog.perfumes.filter((q) => q.slug !== p.slug);
  const idx = catalog.perfumes.indexOf(p);
  const sizes = catalog.sizes.map((s) => {
    const sel = s.id === S6.id ? ' checked' : '';
    const h = s.id === '3ml' ? 40 : 52;
    return `<label class="size"><input type="radio" name="size" value="${s.id}" data-label="${esc(s.label)}" data-price="${s.price}" data-old="${s.compareAt || ''}"${sel}>
      <span class="size-in"><svg class="bt" viewBox="0 0 40 60" style="height:${h}px" aria-hidden="true"><rect x="12" y="2" width="16" height="16" rx="3" fill="currentColor"/><rect x="4" y="20" width="32" height="38" rx="6" fill="none" stroke="currentColor" stroke-width="3"/><rect x="8" y="34" width="24" height="20" rx="3" fill="currentColor" opacity=".35"/></svg>
      <b>${esc(s.label)}</b><span class="sp">${s.compareAt ? `<s>৳${s.compareAt}</s>` : ''}<strong>৳${s.price}</strong></span>${s.compareAt ? `<em>৳${s.compareAt - s.price} ছাড়</em>` : ''}</span></label>`;
  }).join('');

  const tier = (name, bn, hint, keys) => `<div class="tier reveal"><div class="tier-h"><b>${name}</b><span>${bn}</span><small>${hint}</small></div><div class="tier-c">${keys.map((k) => `<figure class="ingc"><span class="ingc-i">${ingImg(k)}</span><figcaption><b>${esc(ing(k).en)}</b><small>${esc(ing(k).bn)}</small></figcaption></figure>`).join('')}</div></div>`;
  const pyramid = tier('Top Notes', 'শুরুর ঘ্রাণ', 'প্রথম ১৫ মিনিট', p.pyramid.top) + tier('Heart Notes', 'মূল ঘ্রাণ', '১৫ মিনিট – ৩ ঘণ্টা', p.pyramid.heart) + tier('Base Notes', 'শেষের ঘ্রাণ', '৩ ঘণ্টা+', p.pyramid.base);

  const meter = (label, bn, key) => {
    const v = p.meters[key];
    return `<div class="meter"><div class="m-t"><b>${label}</b><small>${bn}</small></div><div class="bars">${[1, 2, 3, 4, 5].map((n) => `<i class="${n <= v ? 'on' : ''}"></i>`).join('')}</div><span class="m-v">${LV[key][v - 1]}</span></div>`;
  };
  const pills = (list, have) => list.map(([k, bn]) => `<span class="pl${have.includes(k) ? ' on' : ''}">${bn}</span>`).join('');

  const rows = [
    ['ব্র্যান্ড', 'Elvaren'], ['সুগন্ধি', p.name], ['সাইজ', catalog.sizes.map((s) => s.label).join(' / ')],
    ['ঘরানা', p.family], ['মেজাজ', p.mood], ['প্রধান নোটস', [...new Set([...p.pyramid.top, ...p.pyramid.heart, ...p.pyramid.base])].map((k) => ing(k).en).join(', ')],
    ['উপযোগী সময়', p.best], ['বোতল', 'গ্লাস বোতল, ব্ল্যাক ক্যাপ'], ['পেমেন্ট', 'ক্যাশ অন ডেলিভারি (COD)'],
    ['ডেলিভারি', `ঢাকা ও চট্টগ্রাম ৳${D.insideFee} · অন্যত্র ৳${D.outsideFee}`],
  ].map(([a, b]) => `<tr><th>${esc(a)}</th><td>${esc(b)}</td></tr>`).join('');

  const thumbs = `<button type="button" class="thumb on" data-scene="1" aria-label="দৃশ্য"><span class="th-sc">${ingImg(p.orbit[0])}</span></button>` +
    [2, 3, 4].map((n) => `<button type="button" class="thumb" data-src="/assets/${p.slug}-g${n}.webp" aria-label="ছবি ${n}"><img src="/assets/${p.slug}-g${n}.webp" alt="" width="120" height="120" loading="lazy"></button>`).join('');

  const occ = p.occasions.map((o) => `<div class="occ reveal">${ICON.star}<h3>${esc(o)}</h3></div>`).join('');
  const more = others.map((q) => `<a class="mini" href="/perfume/${q.slug}" style="--bg:${rgbOf(q.theme.bg)};--glow:${rgbOf(q.theme.glow)}"><img src="/assets/${q.slug}-sm.webp" alt="Elvaren ${esc(q.name)}" loading="lazy" width="98" height="200"><h3>${esc(q.name)}</h3><span>${S6.compareAt ? `<s>৳${S6.compareAt}</s>` : ''}<b>৳${S6.price}</b></span></a>`).join('');
  const steps = [['অল্প করে লাগান', 'কব্জি ও গলার পাশের মতো উষ্ণ জায়গায় অল্প পরিমাণে লাগান।'], ['ঘষবেন না', 'ঘষলে সুগন্ধির গঠন নষ্ট হয় — নিজে থেকে ত্বকে মিশতে দিন।'], ['ঠিকভাবে রাখুন', 'সরাসরি রোদ ও গরম থেকে দূরে, ঠান্ডা ও শুকনো জায়গায় রাখুন।']]
    .map(([a, b]) => `<div class="step reveal"><h3>${a}</h3><p>${b}</p></div>`).join('');

  const jsonld = {
    '@context': 'https://schema.org', '@type': 'Product', name: p.name, brand: { '@type': 'Brand', name: 'Elvaren' },
    description: p.desc, image: `${ctx.cfg.siteUrl}/assets/${p.slug}-g1.webp`,
    offers: catalog.sizes.map((s) => ({ '@type': 'Offer', name: s.label, priceCurrency: 'BDT', price: s.price, availability: 'https://schema.org/InStock', url: `${ctx.cfg.siteUrl}/perfume/${p.slug}` })),
  };

  const body = `
<div class="wrap">
  <nav class="crumbs" aria-label="breadcrumb"><a href="/">হোম</a> / <a href="/#collection">কালেকশন</a> / ${esc(p.name)}</nav>
  <section class="pdp">
    <div class="gallery">
      <div class="g-main" id="g-main">
        ${SAVE6 ? `<span class="badge">${esc(S6.label)}-এ ৳${SAVE6} ছাড়</span>` : ''}
        <div class="pd-scene" id="pd-scene">${heroScene(p, 0).replace('h-scene', 'h-scene pd')}<span class="h-ring r1"></span><span class="h-ring r2"></span></div>
        <img class="g-img" id="g-img" alt="" hidden width="900" height="900">
      </div>
      <div class="g-thumbs">${thumbs}</div>
    </div>
    <div class="buy" id="buy" data-slug="${p.slug}" data-name="${esc(p.name)}">
      <span class="eyebrow">Elvaren · ${esc(p.family)}</span>
      <h1>${esc(p.name)}</h1>
      <span class="mood">${esc(p.mood)}</span>
      <div class="price-live" aria-live="polite"><s id="pl-old">${S6.compareAt ? '৳' + S6.compareAt : ''}</s><strong id="pl-price">৳${S6.price}</strong><em id="pl-save">${SAVE6 ? '৳' + SAVE6 + ' ছাড়' : ''}</em></div>
      <p class="desc">${esc(p.desc)}</p>
      <div class="ing-chips">${[...new Set([...p.pyramid.top, ...p.pyramid.heart, ...p.pyramid.base])].map((k) => `<span class="ichip"><img src="/assets/ing/${esc(ing(k).img)}" alt="" width="24" height="24">${esc(ing(k).en)}</span>`).join('')}</div>
      <fieldset class="sizes"><legend>১. সাইজ বেছে নিন</legend><div class="size-row">${sizes}</div></fieldset>
      <div class="qty-row"><label for="qty">২. পরিমাণ</label>
        <div class="stepper"><button type="button" id="qty-minus" aria-label="কমান">−</button><output id="qty" aria-live="polite">1</output><button type="button" id="qty-plus" aria-label="বাড়ান">+</button></div></div>
      <div class="line-total"><span>মোট (<span id="lt-size">${esc(S6.label)}</span> × <span id="lt-qty">1</span>)</span><strong id="lt-total">৳${S6.price}</strong></div>
      <div class="cta-row">
        <button class="btn btn-dark" id="add-cart" type="button">কার্টে যোগ করুন</button>
        <button class="btn btn-ghost" id="buy-now" type="button">এখনই কিনুন</button>
      </div>
      <div class="addons" id="addons">
        <h4>অ্যাড-অন ও অফার</h4>
        <label class="ao"><input type="checkbox" id="ao-gift"><span>🎁 ${esc(OFF.giftWrap?.label || 'গিফট র‍্যাপ')} <b>+৳${OFF.giftWrap?.price || 0}</b></span></label>
        <div class="ao-row"><span>চেষ্টা করতে ${esc(S3.label)} স্যাম্পল যোগ করুন (৳${S3.price}):</span><div class="ao-chips">${catalog.perfumes.filter((q) => q.slug !== p.slug).map((q) => `<button type="button" data-sample="${q.slug}">${esc(q.name)}</button>`).join('')}</div></div>
        <button class="ao-set" id="ao-set" type="button">🎁 পুরো কালেকশন (৫টি × ${esc(S6.label)}) কার্টে যোগ করুন — ${esc((OFF.bundle || []).slice(-1)[0]?.label || '')}</button>
        <p class="ao-note">${esc((OFF.bundle || []).map((b) => b.label).join(' · '))} · ৳${OFF.freeDeliveryOver || 0}+ অর্ডারে ডেলিভারি ফ্রি</p>
      </div>
      <ul class="trust">
        <li>ঢাকা ও চট্টগ্রামে ডেলিভারি ৳${D.insideFee} · অন্যত্র ৳${D.outsideFee}</li>
        <li>ক্যাশ অন ডেলিভারি (COD)</li>
        <li>লগইন করে লাইভ অর্ডার ট্র্যাকিং</li>
      </ul>
    </div>
  </section>
</div>

<section class="section notes-sec">
  <div class="wrap">
    <div class="section-head reveal"><span class="eyebrow">Scent Notes</span><h2>যে ঘ্রাণগুলো আপনি পাবেন</h2><p>সুগন্ধি ত্বকে মেশার সাথে সাথে ঘ্রাণ ধাপে ধাপে বদলায় — শুরু, মাঝ আর শেষ।</p></div>
    <div class="pyramid">${pyramid}</div>
    <p class="note-foot">* ঘ্রাণের বিবরণ সাধারণ ঘরানা অনুযায়ী; ত্বক, আবহাওয়া ও ব্যবহারভেদে অনুভূতি আলাদা হতে পারে।</p>
  </div>
</section>

<section class="story" style="--bg:${rgbOf(t.bg)};--glow:${rgbOf(t.glow)}">
  <div class="wrap story-grid">
    <div class="story-img reveal"><img src="/assets/${p.slug}.webp" alt="" width="350" height="722" loading="lazy"></div>
    <div class="story-text reveal">
      <span class="eyebrow">About the scent</span>
      <h2>${esc(p.name)} — অনুভূতির গল্প</h2>
      <p>${esc(p.story)}</p>
      <div class="chips light"><span class="chip"><b>ঘরানা:</b> ${esc(p.family)}</span><span class="chip"><b>উপযোগী:</b> ${esc(p.best)}</span></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap two">
    <div class="reveal"><span class="eyebrow">Performance</span><h2>পারফরম্যান্স</h2>
      <div class="meters">${meter('Longevity', 'স্থায়িত্ব', 'longevity')}${meter('Projection', 'ছড়ানোর ক্ষমতা (Sillage)', 'projection')}${meter('Intensity', 'ঘ্রাণের গাঢ়তা', 'intensity')}</div>
      <p class="note-foot">* আনুমানিক ধারণা। ত্বকের ধরন, আবহাওয়া ও কতটা লাগানো হলো — এসবের উপর নির্ভর করে।</p>
    </div>
    <div class="reveal"><span class="eyebrow">Best for</span><h2>কখন মানাবে</h2>
      <h4 class="mini-h">ঋতু</h4><div class="pls">${pills(SEASONS, p.seasons)}</div>
      <h4 class="mini-h">সময়</h4><div class="pls">${pills(TIMES, p.times)}</div>
      <div class="occ-grid">${occ}</div>
    </div>
  </div>
</section>

<section class="section details">
  <div class="wrap two">
    <div class="reveal"><span class="eyebrow">Details</span><h2>পণ্যের বিবরণ</h2><table class="spec">${rows}</table></div>
    <div class="reveal"><span class="eyebrow">How to use</span><h2>ব্যবহারের নিয়ম</h2><div class="steps one">${steps}</div></div>
  </div>
</section>

<section class="section" id="reviews" style="padding-bottom:10px">
  <div class="wrap narrow"><div class="section-head reveal"><span class="eyebrow">Reviews</span><h2>ক্রেতাদের রিভিউ</h2></div><div class="rv-box" id="rv-box">লোড হচ্ছে…</div></div>
</section>

<section class="section" style="padding-top:20px">
  <div class="wrap narrow"><div class="section-head reveal"><span class="eyebrow">FAQ</span><h2>সাধারণ প্রশ্ন</h2></div><div class="faq">${faqHtml()}</div></div>
</section>

<section class="more"><div class="wrap"><h2>আরও সুগন্ধি দেখুন</h2><div class="mini-grid">${more}</div></div></section>

<div class="mbar"><div><small id="mb-size">${esc(S6.label)}</small><div class="price"><s id="mb-old">${S6.compareAt ? '৳' + S6.compareAt : ''}</s><strong id="mb-price">৳${S6.price}</strong></div></div><button class="btn btn-dark" id="mb-add" type="button">কার্টে যোগ করুন</button></div>
<div class="modal" id="added" role="dialog" aria-modal="true" aria-labelledby="ad-h">
  <div class="modal-box"><div class="tick">${ICON.check}</div><h3 id="ad-h">কার্টে যোগ হয়েছে</h3><p id="ad-text"></p>
    <a class="btn btn-dark" href="/cart">কার্ট দেখুন ও অর্ডার করুন</a><button class="btn btn-ghost" data-close>আরও কেনাকাটা করুন</button></div>
</div>
<script type="application/ld+json">${JSON.stringify(jsonld).replace(/</g, '\\u003c')}</script>`;
  return layout(ctx, {
    title: `${p.name} — Elvaren | ${S6.label} মাত্র ৳${S6.price}`,
    desc: `${p.name} (${p.mood}) — ${p.short} ${S3.label} ৳${S3.price}, ${S6.label} ৳${S6.price}। এখনই অর্ডার করুন।`,
    path: `/perfume/${p.slug}`, ogImage: `/assets/${p.slug}-g1.webp`, body, cls: 'pdp-page', scripts: ['product.js'],
    style: `--bg:${rgbOf(t.bg)};--glow:${rgbOf(t.glow)};--pastel:${rgbOf(t.pastel)}`,
  });
}

/* ------------------------------------------------------------------ CART */
export function renderCart(ctx) {
  const inside = DISTRICTS.filter((d) => D.insideDistricts.includes(d));
  const outside = DISTRICTS.filter((d) => !D.insideDistricts.includes(d));
  const body = `
<div class="wrap cart-wrap">
  <nav class="crumbs" aria-label="breadcrumb"><a href="/">হোম</a> / কার্ট</nav>
  <h1 class="cart-title">আপনার কার্ট</h1>
  <div id="cart-empty" class="cart-empty" hidden><p>আপনার কার্ট এখন খালি।</p><a class="btn btn-dark" href="/#collection">সুগন্ধি দেখুন</a></div>
  <div class="cart-grid" id="cart-grid" hidden>
    <section>
      <div class="fd-bar" id="fd-bar"><p id="fd-text"></p><div class="bar"><i id="fd-fill"></i></div></div>
      <div id="cart-items" class="cart-items"></div>
      <div class="upsell" id="upsell" hidden><h3>সাথে ট্রাই করুন</h3><div class="up-grid" id="up-grid"></div></div>
      <div class="cart-more"><h3>আরও যোগ করতে চান?</h3><div class="mini-grid small">${catalog.perfumes.map((q) => `<a class="mini" href="/perfume/${q.slug}" style="--bg:${rgbOf(q.theme.bg)};--glow:${rgbOf(q.theme.glow)}"><img src="/assets/${q.slug}-sm.webp" alt="" loading="lazy" width="98" height="200"><h3>${esc(q.name)}</h3></a>`).join('')}</div></div>
    </section>
    <aside class="order" id="checkout" aria-labelledby="co-h">
      <h2 id="co-h">অর্ডার করুন</h2>
      <div id="login-gate" class="login-gate" hidden>
        <p>অর্ডার করতে Google অ্যাকাউন্ট দিয়ে লগইন করা বাধ্যতামূলক। লগইন করলে আপনার কার্ট ও অর্ডারের লাইভ স্ট্যাটাস সেভ থাকবে।</p>
        <button class="btn btn-dark" id="gate-login" type="button">Google দিয়ে লগইন করুন</button>
      </div>
      <form id="order-form" novalidate hidden>
        <p class="sub">নিচের তথ্য দিন — আমরা কল বা মেসেজে কনফার্ম করবো। <span class="who-am" id="who-am"></span></p>
        <div class="field"><label for="f-name">আপনার নাম</label><input id="f-name" name="name" autocomplete="name" maxlength="80" placeholder="যেমন: রাহুল আহমেদ"><div class="err"></div></div>
        <div class="row2">
          <div class="field"><label for="f-phone">মোবাইল নম্বর</label><input id="f-phone" name="phone" type="tel" inputmode="numeric" autocomplete="tel" maxlength="11" placeholder="01XXXXXXXXX"><div class="err"></div></div>
          <div class="field"><label for="f-wa">WhatsApp নম্বর</label><input id="f-wa" name="whatsapp" type="tel" inputmode="numeric" maxlength="11" placeholder="01XXXXXXXXX"><div class="err"></div></div>
        </div>
        <label class="same"><input type="checkbox" id="same-wa"> মোবাইল নম্বরই আমার WhatsApp নম্বর</label>
        <div class="field"><label for="f-email">ইমেইল</label><input id="f-email" name="email" type="email" autocomplete="email" maxlength="254" placeholder="name@gmail.com"><div class="err"></div></div>
        <div class="field"><label for="f-dist">জেলা</label>
          <select id="f-dist" name="district"><option value="">জেলা নির্বাচন করুন</option>
            <optgroup label="ঢাকা ও চট্টগ্রাম — ডেলিভারি ৳${D.insideFee}">${inside.map((d) => `<option>${esc(d)}</option>`).join('')}</optgroup>
            <optgroup label="অন্যান্য জেলা — ডেলিভারি ৳${D.outsideFee}">${outside.map((d) => `<option>${esc(d)}</option>`).join('')}</optgroup>
          </select><div class="err"></div></div>
        <div class="field"><label for="f-addr">পূর্ণ ঠিকানা</label><textarea id="f-addr" name="address" autocomplete="street-address" maxlength="300" placeholder="বাসা/রোড, এলাকা, থানা"></textarea><div class="err"></div></div>
        <div class="field"><label for="f-note">বিশেষ নোট <i>(ঐচ্ছিক)</i></label><input id="f-note" name="note" maxlength="300" placeholder="কিছু জানানোর থাকলে লিখুন"></div>
        <div class="hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>
        <div class="field coupon"><label for="f-coupon">কুপন কোড <i>(থাকলে)</i></label><div class="coupon-row"><input id="f-coupon" maxlength="24" placeholder="WELCOME10" autocapitalize="characters" autocomplete="off"><button type="button" class="btn btn-ghost btn-sm" id="coupon-apply">প্রয়োগ</button></div><div class="cmsg" id="coupon-msg" role="status"></div></div>
        <label class="same gift"><input type="checkbox" id="f-gift"> 🎁 ${esc(OFF.giftWrap?.label || 'গিফট র‍্যাপ')} (+৳${OFF.giftWrap?.price || 0})</label>
        <div class="field" id="gift-note-f" hidden><input id="f-gnote" maxlength="160" placeholder="কার্ডে কী লিখতে চান? (যেমন: শুভ জন্মদিন!)"></div>
        <div class="pay"><span class="dot-on"></span><div><b>ক্যাশ অন ডেলিভারি (COD)</b><small>পণ্য হাতে পেয়ে টাকা দিন</small></div></div>
        <div class="sum">
          <div><span>পণ্যের দাম (<span id="sum-count">0</span>টি)</span><span id="sum-sub">৳0</span></div>
          <div class="disc" id="row-bundle" hidden><span id="lbl-bundle">বান্ডেল ছাড়</span><span id="sum-bundle"></span></div>
          <div class="disc" id="row-coupon" hidden><span id="lbl-coupon">কুপন</span><span id="sum-coupon"></span></div>
          <div id="row-gift" hidden><span>গিফট র‍্যাপ</span><span id="sum-gift"></span></div>
          <div><span>ডেলিভারি চার্জ <small id="sum-zone"></small></span><span id="sum-fee">জেলা বাছুন</span></div>
          <div class="tot"><span>সর্বমোট</span><span id="sum-tot">৳0</span></div>
        </div>
        <button class="btn btn-dark" id="submit-btn" type="submit">অর্ডার কনফার্ম করুন</button>
        <p class="form-msg" id="form-msg" role="alert"></p>
        <p class="secure">আপনার তথ্য শুধু অর্ডার প্রসেসের জন্য ব্যবহৃত হবে।</p>
      </form>
    </aside>
  </div>
</div>
<div class="modal" id="done" role="dialog" aria-modal="true" aria-labelledby="dn-h">
  <div class="modal-box"><div class="tick">${ICON.check}</div><h3 id="dn-h">ধন্যবাদ!</h3>
    <p><b id="done-name"></b>, আপনার অর্ডার পেয়েছি। শীঘ্রই কল বা মেসেজে কনফার্ম করা হবে।</p>
    <div class="oid" id="done-oid"></div>
    <a class="btn btn-dark" id="done-track" href="/account">অর্ডার ট্র্যাক করুন</a><a class="btn btn-wa" id="done-share" target="_blank" rel="noopener" href="#">বন্ধুকে শেয়ার করুন (WhatsApp)</a><a class="btn btn-ghost" href="/">হোমে ফিরুন</a></div>
</div>`;
  return layout(ctx, { title: 'আপনার কার্ট — Elvaren', desc: 'Elvaren কার্ট ও অর্ডার', path: '/cart', body, cls: 'cart-page', scripts: ['cart.js'] });
}

/* ------------------------------------------------------------------ ACCOUNT */
export function renderAccount(ctx) {
  const body = `
<div class="wrap acc-wrap">
  <nav class="crumbs" aria-label="breadcrumb"><a href="/">হোম</a> / আমার অ্যাকাউন্ট</nav>
  <div id="acc-guest" class="acc-guest" hidden>
    <h1 class="cart-title">আমার অর্ডার</h1>
    <p>অর্ডারের ইতিহাস, কার্ট ও লাইভ ডেলিভারি স্ট্যাটাস দেখতে Google দিয়ে লগইন করুন।</p>
    <button class="btn btn-dark" id="acc-login" type="button">Google দিয়ে লগইন করুন</button>
  </div>
  <div id="acc-user" hidden>
    <div class="acc-head"><span class="acc-av" id="acc-av"></span><div><h1 id="acc-name"></h1><p id="acc-email"></p></div><button class="btn btn-ghost btn-sm" id="acc-logout" type="button">লগআউট</button></div>
    <div class="acc-tabs" role="tablist"><button role="tab" class="on" data-tab="orders">আমার অর্ডার <b id="t-orders">0</b></button><button role="tab" data-tab="cart">সেভ করা কার্ট <b id="t-cart">0</b></button></div>
    <section id="tab-orders"><div class="live-bar"><span class="live"><i></i> Live</span><span id="live-upd">আপডেট হচ্ছে…</span><button type="button" class="link" id="live-ref">এখনই রিফ্রেশ</button></div><div id="orders" class="orders"></div></section>
    <section id="tab-cart" hidden><div id="acc-cart" class="cart-items"></div></section>
  </div>
</div>`;
  return layout(ctx, { title: 'আমার অর্ডার — Elvaren', desc: 'আপনার অর্ডার ও লাইভ ট্র্যাকিং', path: '/account', body, cls: 'acc-page', scripts: ['account.js'] });
}

/* ------------------------------------------------------------------ POLICIES */
export function renderPolicies(ctx) {
  const sec = (id, h, html) => `<section id="${id}" class="pol"><h2>${h}</h2>${html}</section>`;
  const body = `<div class="wrap narrow pol-wrap"><nav class="crumbs"><a href="/">হোম</a> / নীতিমালা</nav><h1 class="cart-title">নীতিমালা</h1>
${sec('delivery', 'ডেলিভারি', `<p>ঢাকা ও চট্টগ্রাম জেলায় ডেলিভারি চার্জ ৳${D.insideFee}; এর বাইরে সব জেলায় ৳${D.outsideFee}। অর্ডার কনফার্মেশনের পর পণ্য কুরিয়ারে পাঠানো হয়। অর্ডারের বর্তমান অবস্থা “আমার অর্ডার” পেজে লাইভ দেখা যায়।</p>`)}
${sec('payment', 'পেমেন্ট', '<p>বর্তমানে শুধু ক্যাশ অন ডেলিভারি (COD) — পণ্য হাতে পেয়ে মূল্য পরিশোধ করতে হবে।</p>')}
${sec('returns', 'রিটার্ন ও ভুল/ক্ষতিগ্রস্ত পণ্য', '<p>ডেলিভারির সময় বোতল ভাঙা/ক্ষতিগ্রস্ত বা ভুল সুগন্ধি পেলে ডেলিভারির দিনই আমাদের জানান এবং ছবি পাঠান। যাচাই করে সমাধান করা হবে। ব্যবহৃত বা সিল খোলা পণ্য ফেরতযোগ্য নয়।</p>')}
${sec('privacy', 'গোপনীয়তা', '<p>Google লগইনের মাধ্যমে আমরা শুধু আপনার নাম, ইমেইল ও প্রোফাইল ছবি পাই। অর্ডারের সময় দেওয়া নাম, ফোন, WhatsApp, ইমেইল ও ঠিকানা শুধু অর্ডার প্রসেস, ডেলিভারি ও আপনার সাথে যোগাযোগের জন্য ব্যবহৃত হয়; তৃতীয় পক্ষের কাছে বিক্রি করা হয় না (কুরিয়ার ও আমাদের অর্ডার-অটোমেশন সেবা ছাড়া)।</p>')}
${sec('terms', 'শর্তাবলি', '<p>ওয়েবসাইটে দেখানো দাম ও পণ্যের তথ্য পরিবর্তন হতে পারে। সুগন্ধির নামগুলো ঘরানা বোঝাতে ব্যবহৃত; সংশ্লিষ্ট ব্র্যান্ডের সাথে Elvaren-এর কোনো সম্পর্ক নেই। ভুল তথ্য (ফোন/ঠিকানা) দিয়ে অর্ডার করলে ডেলিভারি ব্যর্থ হতে পারে।</p>')}
</div>`;
  return layout(ctx, { title: 'নীতিমালা — Elvaren', desc: 'ডেলিভারি, পেমেন্ট, রিটার্ন ও গোপনীয়তা নীতি', path: '/policies', body, cls: 'pol-page' });
}

export function renderNotFound(ctx) {
  return layout(ctx, { title: 'পেজ পাওয়া যায়নি — Elvaren', desc: '404', path: '/404', cls: 'pol-page',
    body: '<div class="wrap narrow pol-wrap" style="text-align:center;padding:90px 0"><h1 class="cart-title">৪০৪</h1><p>পেজটি খুঁজে পাওয়া যায়নি।</p><p style="margin-top:24px"><a class="btn btn-dark" href="/">হোমে ফিরুন</a></p></div>' });
}
