// Order statuses. n8n / your Google Sheet "Courier Status" dropdown should use the "sheet" labels.
export const STATUSES = [
  { key: 'pending',          sheet: 'Pending',          bn: 'অর্ডার পেয়েছি (অপেক্ষমাণ)', step: 0, tone: 'wait' },
  { key: 'confirmed',        sheet: 'Confirmed',        bn: 'কনফার্ম হয়েছে',              step: 1, tone: 'ok' },
  { key: 'processing',       sheet: 'Packed',           bn: 'প্যাকিং হচ্ছে',               step: 2, tone: 'ok' },
  { key: 'in_transit',       sheet: 'In Transit',       bn: 'ট্রানজিটে (পথে আছে)',          step: 3, tone: 'go' },
  { key: 'out_for_delivery', sheet: 'Out for Delivery', bn: 'ডেলিভারির জন্য বের হয়েছে',     step: 4, tone: 'go' },
  { key: 'delivered',        sheet: 'Delivered',        bn: 'ডেলিভারি সম্পন্ন',             step: 5, tone: 'done' },
  { key: 'returned',         sheet: 'Returned',         bn: 'রিটার্ন হয়েছে',               step: -1, tone: 'bad' },
  { key: 'cancelled',        sheet: 'Cancelled',        bn: 'বাতিল হয়েছে',                step: -1, tone: 'bad' },
  { key: 'on_hold',          sheet: 'On Hold',          bn: 'হোল্ডে আছে',                  step: -1, tone: 'wait' },
];

export const STATUS_BY_KEY = Object.fromEntries(STATUSES.map((s) => [s.key, s]));

const ALIASES = {
  new: 'pending', placed: 'pending', pending: 'pending', unconfirmed: 'pending',
  confirm: 'confirmed', confirmed: 'confirmed',
  processing: 'processing', packed: 'processing', packing: 'processing', ready: 'processing', ready_to_ship: 'processing',
  in_transit: 'in_transit', intransit: 'in_transit', transit: 'in_transit', shipped: 'in_transit', dispatched: 'in_transit', on_the_way: 'in_transit', picked_up: 'in_transit',
  out_for_delivery: 'out_for_delivery', ofd: 'out_for_delivery', out_for_deliver: 'out_for_delivery',
  delivered: 'delivered', complete: 'delivered', completed: 'delivered', done: 'delivered',
  returned: 'returned', return: 'returned', rto: 'returned', returning: 'returned',
  cancelled: 'cancelled', canceled: 'cancelled', cancel: 'cancelled',
  on_hold: 'on_hold', hold: 'on_hold', onhold: 'on_hold', paused: 'on_hold',
};

/** "In Transit", "in-transit", "IN_TRANSIT", "shipped" … → "in_transit" (or null) */
export function normalizeStatus(input) {
  const k = String(input ?? '').trim().toLowerCase().replace(/[^a-z]+/g, '_').replace(/^_+|_+$/g, '');
  return ALIASES[k] || null;
}
