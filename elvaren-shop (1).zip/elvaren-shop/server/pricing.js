import { catalog, perfumeBySlug, sizeById, deliveryFor } from './catalog.js';

export const MAX_ITEMS = 10;
export const MAX_QTY = 20;
const O = catalog.offers || {};

/** [{slug,size,qty}] → cleaned, merged, capped. Unknown products/sizes are dropped. */
export function normalizeCart(raw) {
  const map = new Map();
  for (const it of Array.isArray(raw) ? raw : []) {
    const slug = String(it?.slug ?? ''), size = String(it?.size ?? '');
    if (!perfumeBySlug[slug] || !sizeById[size]) continue;
    const qty = Math.max(1, Math.min(MAX_QTY, Math.floor(Number(it.qty)) || 1));
    const k = `${slug}|${size}`;
    map.set(k, { slug, size, qty: Math.min(MAX_QTY, (map.get(k)?.qty || 0) + qty) });
  }
  return [...map.values()].slice(0, MAX_ITEMS);
}

/** Prices always come from the server catalog — never from the browser. */
export function priceItems(cart) {
  const items = cart.map((c) => {
    const p = perfumeBySlug[c.slug], s = sizeById[c.size];
    return { slug: p.slug, name: p.name, size: s.id, sizeLabel: s.label, qty: c.qty, unitPrice: s.price, lineTotal: s.price * c.qty };
  });
  return { items, subtotal: items.reduce((a, i) => a + i.lineTotal, 0), totalQty: items.reduce((a, i) => a + i.qty, 0) };
}

export const normCode = (c) => String(c ?? '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 24);

function bundleFor(totalQty) {
  const tiers = [...(O.bundle || [])].sort((a, b) => a.minQty - b.minQty);
  const hit = [...tiers].reverse().find((t) => totalQty >= t.minQty);
  const next = tiers.find((t) => totalQty < t.minQty);
  return { off: hit?.off || 0, label: hit?.label || '', next: next ? { need: next.minQty - totalQty, off: next.off, label: next.label } : null };
}

function checkCoupon(code, net, { db, userId } = {}) {
  const c = (O.coupons || []).find((x) => x.code === code);
  if (!c) return { error: 'কুপন কোডটি সঠিক নয়' };
  if (net < (c.minSubtotal || 0)) return { error: `এই কুপনের জন্য কমপক্ষে ৳${c.minSubtotal} এর পণ্য লাগবে` };
  let pending = false;
  if (c.firstOrderOnly) {
    if (!userId || !db) pending = true; // can only be verified after login
    else if (db.prepare("SELECT 1 FROM orders WHERE user_id = ? AND status != 'cancelled' LIMIT 1").get(userId)) return { error: 'এই কুপনটি শুধু প্রথম অর্ডারে প্রযোজ্য' };
  }
  let off = c.flat || 0;
  if (c.percent) off = Math.round((net * c.percent) / 100);
  if (c.maxOff) off = Math.min(off, c.maxOff);
  return { code: c.code, off: Math.min(off, net), label: c.label, pending };
}

/**
 * The single source of truth for what an order costs.
 * cart + district + coupon + gift → every number the customer, the database and n8n will see.
 */
export function quote({ cart, district, coupon, giftWrap }, ctx = {}) {
  const priced = priceItems(cart);
  const bundle = bundleFor(priced.totalQty);
  const afterBundle = Math.max(0, priced.subtotal - bundle.off);
  const code = normCode(coupon);
  let couponInfo = null, couponError = null;
  if (code) { const r = checkCoupon(code, afterBundle, ctx); if (r.error) couponError = r.error; else couponInfo = r; }
  const couponOff = couponInfo?.off || 0;
  const discount = bundle.off + couponOff;
  const net = priced.subtotal - discount;
  const giftWrapFee = giftWrap ? (O.giftWrap?.price || 0) : 0;
  const threshold = O.freeDeliveryOver || 0;
  let delivery = null;
  if (district) {
    const d = deliveryFor(district);
    const free = threshold > 0 && net >= threshold;
    delivery = { zone: d.zone, raw: d.fee, fee: free ? 0 : d.fee, free };
  }
  return {
    ...priced, bundle, coupon: couponInfo, couponError, discount, net, giftWrapFee, delivery,
    freeDeliveryLeft: threshold > 0 ? Math.max(0, threshold - net) : 0, freeDeliveryOver: threshold,
    total: net + giftWrapFee + (delivery ? delivery.fee : 0),
  };
}
