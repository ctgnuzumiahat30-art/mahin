# Elvaren — Full-stack Perfume Shop

Node.js (Express 5 + SQLite) ওয়েবসাইট + API। Google লগইন বাধ্যতামূলক, অর্ডার n8n-এ যায়, n8n থেকে স্ট্যাটাস এলে কাস্টমার লাইভ দেখে। **Google Sheets-এর কোনো কোড এই প্রজেক্টে নেই** — শিট হ্যান্ডেল করবে n8n।

## ১. চালু করুন (লোকাল)
```bash
node -v                # 22.13 বা তার বেশি লাগবে
npm install
cp .env.example .env   # তারপর .env ফাইল এডিট করুন
npm start              # http://localhost:3000
```
টেস্ট: `npm test` (৭টি API টেস্ট)।
লোকালে Google ছাড়া চেক করতে `.env`-এ `DEV_AUTH=1` দিন (শুধু development-এ কাজ করে, production-এ বন্ধ)।

## ২. Google লগইন চালু করা
1. console.cloud.google.com → APIs & Services → Credentials → **Create OAuth client ID → Web application**
2. *Authorized JavaScript origins*-এ আপনার সাইটের ঠিকানা (`https://yourdomain.com`) ও টেস্টের জন্য `http://localhost:3000` দিন।
3. পাওয়া Client ID `.env`-এর `GOOGLE_CLIENT_ID`-এ বসান। (Client secret লাগবে না।)

## ৩. নিয়মগুলো (কোডে ফিক্সড)
- মোবাইল ও WhatsApp: `01` দিয়ে শুরু, ঠিক ১১ ডিজিট — নাহলে অর্ডার হবে না।
- ইমেইল বাধ্যতামূলক ও valid হতে হবে (ডোমেইন টাইপো ও MX চেক সহ)।
- ডেলিভারি: ঢাকা ও চট্টগ্রাম ৳60, বাকি সব জেলা ৳120 (`server/catalog.json`-এ বদলানো যায়)।
- দাম সবসময় সার্ভার থেকে ধরা হয়, ব্রাউজার থেকে নয়।
- ইনভয়েস নম্বর E1003 থেকে শুরু (`INVOICE_START`)।

## ৪. অফার ও মার্কেটিং ফিচার (সব `server/catalog.json` → `offers`-এ বদলানো যায়)
- **ফ্রি ডেলিভারি:** ৳750+ অর্ডারে (কার্টে প্রগ্রেস বার দেখায়)
- **বান্ডেল ছাড়:** ৩টি+ → ৳30, ৫টি+ → ৳100 (অটো)
- **কুপন:** `WELCOME10` (প্রথম অর্ডারে ১০%, সর্বোচ্চ ৳100), `FRIEND30` (৳30, ন্যূনতম ৳400) — নতুন কুপন যোগ করতে `coupons` লিস্টে লিখুন
- **অ্যাড-অন:** গিফট র‍্যাপ + মেসেজ কার্ড (৳40), ৩ ml স্যাম্পল আপসেল, পুরো কালেকশন বাটন
- **Scent Finder কুইজ**, WhatsApp-এ শেয়ার, ফুটারে ইমেইল/লিড ক্যাপচার (n8n-এ `lead.created` যায়)
- **ভেরিফাইড রিভিউ:** শুধু *Delivered* অর্ডারের ক্রেতা রিভিউ দিতে পারে — কোনো নকল রিভিউ নেই
- **Facebook Pixel / GA4:** `.env`-এ `FB_PIXEL_ID` / `GA_MEASUREMENT_ID` দিলেই চালু (ViewContent, AddToCart, InitiateCheckout, Purchase)
- ⚠️ ছাড়/ফ্রি-ডেলিভারির সংখ্যাগুলো আমার ধরে নেওয়া — আপনার লাভের হিসাব দেখে বদলে নিন।

## ৫. পারফিউমের তথ্য এডিট
`server/catalog.json` — নাম, দাম, নোট/ইনগ্রিডিয়েন্ট, মিটার (longevity/sillage), কোট, রং। *নোট ও মিটারগুলো আন্দাজে লেখা — আপনার আসল তথ্য দিয়ে বদলে নিন।* সেভ করে সার্ভার রিস্টার্ট দিন।

## ৬. ডিপ্লয়
**Docker:** `.env` বানিয়ে `docker compose up -d --build`।
**VPS:** `npm ci --omit=dev` → `pm2 start "node --no-warnings server/index.js" --name elvaren` → nginx reverse proxy + HTTPS (certbot)।

⚠️ `data/` ফোল্ডারে SQLite ডাটাবেস থাকে — **persistent disk/volume** লাগবে (Vercel/Netlify-র মতো serverless চলবে না; Railway/Render-এ Volume/Disk যোগ করুন)। নিয়মিত `data/elvaren.db` ব্যাকআপ নিন।
প্রোডাকশনে অবশ্যই: `NODE_ENV=production`, `COOKIE_SECURE=1`, `SESSION_SECRET` (লম্বা র‍্যান্ডম), `SITE_URL`, `DEV_AUTH` বন্ধ।

## ৭. n8n ইন্টিগ্রেশন
দেখুন [docs/N8N.md](docs/N8N.md)।
