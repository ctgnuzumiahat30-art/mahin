# n8n ইন্টিগ্রেশন

## A) ওয়েবসাইট → n8n (নতুন অর্ডার)
n8n-এ **Webhook** নোড (POST) বানিয়ে URL `.env`-এর `N8N_ORDER_WEBHOOK_URL`-এ দিন। প্রতিটি অর্ডারে এই JSON আসে:
```json
{ "event":"order.created", "sentAt":"…",
  "order":{ "invoice":"E1003","status":"pending",
            "customer":{"name":"","phone":"","whatsapp":"","email":"","address":"","district":"","note":""},
            "items":[{"name":"Valentino","sizeLabel":"6 ml","qty":2,"unitPrice":190,"lineTotal":380}],
            "totalQty":2,"subtotal":380,"deliveryZone":"inside","deliveryFee":60,"total":440,"payment":"Cash on Delivery (COD)" },
  "sheetRow":{ "Date":"10/25/2026","Invoice":"E1003","Customer":"…","Item Name":"…","Variant":"6 ml","Qty":2,
               "Unit Price":190,"Total Price":380,"Discount":0,"Net Sales":380,"Payment":"…","Courier Status":"Pending" },
  "callback":{"statusUrl":"https://yoursite/api/n8n/orders/status"} }
```
`discount`, `couponCode`, `giftWrap {fee, note}`, `freeDelivery` ফিল্ডও `order`-এ আছে। `sheetRow.Discount` = বান্ডেল + কুপন ছাড়, `Net Sales` = পণ্যের দাম − ছাড় (ডেলিভারি/গিফট ছাড়া)।

`sheetRow`-এর কী-গুলো "Sales revenue" শিটের কলামের নামের সাথে মিলানো — Google Sheets নোডে *Append Row* করে ম্যাপ করুন।
`N8N_WEBHOOK_SECRET` দিলে `x-elvaren-signature` হেডারে body-র HMAC-SHA256 (hex) আসে — যাচাই করা যায়।
n8n ডাউন থাকলে অর্ডার সেভ থাকে ও ব্যাকঅফসহ আবার পাঠানো হয়।

## B) n8n → ওয়েবসাইট (লাইভ স্ট্যাটাস)
সব রিকোয়েস্টে হেডার: `x-api-key: <N8N_API_KEY>`
```bash
# একটি অর্ডার
curl -X POST https://yoursite/api/n8n/orders/status -H "x-api-key: KEY" -H "content-type: application/json" \
  -d '{"invoice":"E1003","status":"Delivered","courier":"Pathao","trackingId":"PT123","note":"হাতে পৌঁছেছে"}'
# একসাথে অনেক
curl -X POST https://yoursite/api/n8n/orders/status -H "x-api-key: KEY" -H "content-type: application/json" \
  -d '{"updates":[{"invoice":"E1003","status":"In Transit"},{"invoice":"E1004","status":"Returned"}]}'
```
- `GET /api/n8n/orders?status=pending` — অর্ডারের তালিকা
- `POST /api/n8n/orders/E1003/resend` — n8n-এ আবার পাঠান

### শিটের "Courier Status" ড্রপডাউনে এই মানগুলো দিন
| শিটে লিখুন | ওয়েবসাইটে দেখায় |
|---|---|
| Pending | অর্ডার পেয়েছি |
| Confirmed | কনফার্ম হয়েছে |
| Packed | প্যাকিং হচ্ছে |
| In Transit | ট্রানজিটে |
| Out for Delivery | ডেলিভারির জন্য বের হয়েছে |
| Delivered | ডেলিভারি সম্পন্ন |
| Returned | রিটার্ন |
| Cancelled | বাতিল |
| On Hold | হোল্ডে |

### ওয়ার্কফ্লো (পরে একসাথে বানাবো)
Google Sheets Trigger (Row updated, "Courier Status") → HTTP Request (POST `/api/n8n/orders/status`, body `{invoice, status}`)।
কাস্টমারের অর্ডার পেজ প্রতি ১৫ সেকেন্ডে নিজে আপডেট হয়।

## C) মার্কেটিং অটোমেশন (n8n)
- **নতুন লিড:** ফুটারে ইমেইল দিলে একই Webhook-এ `{"event":"lead.created","lead":{"email","whatsapp","source"}}` আসে (Switch নোডে `event` দিয়ে আলাদা করুন) → Welcome ইমেইল/শিটে সেভ।
- **অ্যাবান্ডনড কার্ট:** `GET /api/n8n/abandoned-carts?minutes=60` — যাদের কার্ট ভরা কিন্তু অর্ডার নেই (ইমেইল, নাম, আইটেম, মোট)। Schedule Trigger (প্রতি ঘণ্টায়) → এই API → Email/WhatsApp রিমাইন্ডার (কুপন `WELCOME10` সহ)।
- **রিভিউ হাইড:** `POST /api/n8n/reviews/<id>/hide`
- **ডেলিভারির পর রিভিউ রিকোয়েস্ট:** শিটে *Delivered* হলে n8n থেকে কাস্টমারকে মেসেজ দিন: "আমার অর্ডার পেজে গিয়ে রিভিউ দিন"।
