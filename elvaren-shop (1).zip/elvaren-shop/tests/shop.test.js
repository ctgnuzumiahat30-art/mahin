import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.js';
import { openDb } from '../server/db.js';
import { withConfig } from '../server/config.js';

async function start(over = {}) {
  const sent = [];
  const cfg = withConfig({ devAuth: true, isProd: false, checkEmailMx: false, cookieSecure: false, siteUrl: '', n8n: { orderWebhookUrl: 'http://n8n.test/hook', apiKey: 'k', webhookSecret: 's' }, ...over });
  const fetchImpl = async (url, o) => { sent.push({ url, body: JSON.parse(o.body), headers: o.headers }); return { ok: true, status: 200, text: async () => 'ok' }; };
  const { app, stop } = createApp({ cfg, db: openDb(':memory:'), fetchImpl, retryLoop: false });
  const srv = app.listen(0); await new Promise((r) => srv.once('listening', r));
  const base = `http://127.0.0.1:${srv.address().port}`;
  const call = async (path, { method = 'GET', body, cookie, headers = {} } = {}) => {
    const res = await fetch(base + '/api' + path, { method, headers: { 'content-type': 'application/json', origin: base, ...(cookie ? { cookie } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    return { status: res.status, json: await res.json().catch(() => null), cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
  };
  const login = async (email = 'a@gmail.com') => (await call('/auth/dev', { method: 'POST', body: { email, name: 'Test User' } })).cookie;
  return { call, login, sent, close: () => { stop?.(); srv.close(); } };
}
const good = (o = {}) => ({ name: 'Rahim Uddin', phone: '01712345678', whatsapp: '01812345678', email: 'rahim@gmail.com', district: 'Dhaka', address: 'House 5, Road 3, Uttara, Dhaka', items: [{ slug: 'valentino', size: '6ml', qty: 2 }], clientToken: 't' + Math.random(), ...o });

test('login is mandatory to order', async () => {
  const s = await start(); const r = await s.call('/orders', { method: 'POST', body: good() });
  assert.equal(r.status, 401); s.close();
});

test('phone / whatsapp / email rules', async () => {
  const s = await start(); const c = await s.login();
  for (const [field, val] of [['phone', '0271234567'], ['phone', '0171234567'], ['phone', '017123456789'], ['whatsapp', ''], ['whatsapp', '12345'], ['email', 'bad@'], ['email', 'nope'], ['email', '']]) {
    const r = await s.call('/orders', { method: 'POST', cookie: c, body: good({ [field]: val }) });
    assert.equal(r.status, 422, `${field}=${val}`); assert.ok(r.json.errors[field]);
  }
  assert.equal(s.sent.length, 0); s.close();
});

test('delivery fee: 60 Dhaka/Chattogram, 120 elsewhere; prices come from the server', async () => {
  const s = await start(); const c = await s.login();
  const a = await s.call('/orders', { method: 'POST', cookie: c, body: good({ district: 'Dhaka', items: [{ slug: 'valentino', size: '6ml', qty: 2, price: 1 }] }) });
  assert.equal(a.status, 201); assert.equal(a.json.order.delivery.fee, 60); assert.equal(a.json.order.subtotal, 380); assert.equal(a.json.order.total, 440);
  const d = await s.call('/orders', { method: 'POST', cookie: c, body: good({ district: 'Rajshahi' }) });
  assert.equal(d.json.order.delivery.fee, 120);
  assert.equal(a.json.order.invoice, 'E1003'); assert.equal(d.json.order.invoice, 'E1004'); s.close();
});

test('duplicate clientToken is idempotent; n8n gets sheetRow', async () => {
  const s = await start(); const c = await s.login(); const body = good({ clientToken: 'same' });
  const a = await s.call('/orders', { method: 'POST', cookie: c, body }); const b = await s.call('/orders', { method: 'POST', cookie: c, body });
  assert.equal(a.json.order.invoice, b.json.order.invoice); assert.equal(b.json.duplicate, true);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(s.sent.length, 1); assert.equal(s.sent[0].body.event, 'order.created'); assert.equal(s.sent[0].body.sheetRow['Courier Status'], 'Pending'); s.close();
});

test('n8n key required; status change is visible to the customer only', async () => {
  const s = await start(); const c = await s.login(); const other = await s.login('b@gmail.com');
  const o = (await s.call('/orders', { method: 'POST', cookie: c, body: good() })).json.order;
  assert.equal((await s.call('/n8n/orders/status', { method: 'POST', body: { invoice: o.invoice, status: 'Delivered' } })).status, 401);
  assert.equal((await s.call('/n8n/orders/status', { method: 'POST', headers: { 'x-api-key': 'wrong' }, body: { invoice: o.invoice, status: 'Delivered' } })).status, 401);
  const up = await s.call('/n8n/orders/status', { method: 'POST', headers: { 'x-api-key': 'k' }, body: { invoice: o.invoice, status: 'In Transit', trackingId: 'T1' } });
  assert.equal(up.json.status, 'in_transit');
  let mine = (await s.call('/orders', { cookie: c })).json.orders; assert.equal(mine[0].status, 'in_transit'); assert.equal(mine[0].trackingId, 'T1');
  assert.equal((await s.call('/orders', { cookie: other })).json.orders.length, 0);
  await s.call('/n8n/orders/status', { method: 'POST', headers: { 'x-api-key': 'k' }, body: { updates: [{ invoice: o.invoice, status: 'delivered' }] } });
  mine = (await s.call('/orders', { cookie: c })).json.orders; assert.equal(mine[0].status, 'delivered');
  assert.equal((await s.call('/n8n/orders/status', { method: 'POST', headers: { 'x-api-key': 'k' }, body: { invoice: o.invoice, status: 'weird' } })).status, 400); s.close();
});

test('bundle, coupon (first order only), gift wrap and free delivery are priced on the server', async () => {
  const s = await start(); const c = await s.login();
  // 4 x 6ml = 760 → bundle ৳30 off (3+), WELCOME10 10% of 730 = 73, gift 40, delivery free (net ≥ 750? 760-30-73=657 → NOT free)
  const body = good({ items: [{ slug: 'valentino', size: '6ml', qty: 4 }], coupon: 'welcome10', giftWrap: true, giftNote: 'Happy birthday', district: 'Rajshahi' });
  const r = await s.call('/orders', { method: 'POST', cookie: c, body });
  assert.equal(r.status, 201); const o = r.json.order;
  assert.equal(o.subtotal, 760); assert.equal(o.discount, 30 + 73); assert.equal(o.delivery.fee, 120); assert.equal(o.total, 760 - 103 + 40 + 120);
  assert.equal(o.extras.couponCode, 'WELCOME10'); assert.equal(o.extras.giftNote, 'Happy birthday');
  await new Promise((x) => setTimeout(x, 50));
  const row = s.sent[0].body.sheetRow; assert.equal(row.Discount, 103); assert.equal(row['Net Sales'], 657);
  // second use of a first-order coupon is rejected
  const again = await s.call('/orders', { method: 'POST', cookie: c, body: good({ coupon: 'WELCOME10' }) });
  assert.equal(again.status, 422); assert.ok(again.json.errors.coupon);
  // free delivery over the threshold
  const big = await s.call('/orders', { method: 'POST', cookie: c, body: good({ items: [{ slug: 'layton', size: '6ml', qty: 5 }], district: 'Sylhet' }) });
  assert.equal(big.json.order.delivery.fee, 0); assert.equal(big.json.order.extras.freeDelivery, true); s.close();
});

test('quote endpoint works for guests; leads; reviews only for delivered orders', async () => {
  const s = await start();
  const q = await s.call('/quote', { method: 'POST', body: { items: [{ slug: 'layton', size: '3ml', qty: 1 }], district: 'Dhaka', coupon: 'NOPE' } });
  assert.equal(q.json.quote.total, 110 + 60); assert.ok(q.json.quote.couponError);
  assert.equal((await s.call('/leads', { method: 'POST', body: { email: 'bad@' } })).status, 422);
  assert.equal((await s.call('/leads', { method: 'POST', body: { email: 'new@gmail.com' } })).json.coupon, 'WELCOME10');
  const c = await s.login(); const o = (await s.call('/orders', { method: 'POST', cookie: c, body: good() })).json.order;
  assert.equal((await s.call('/reviews', { method: 'POST', cookie: c, body: { invoice: o.invoice, slug: 'valentino', rating: 5 } })).status, 400);
  await s.call('/n8n/orders/status', { method: 'POST', headers: { 'x-api-key': 'k' }, body: { invoice: o.invoice, status: 'Delivered' } });
  assert.equal((await s.call('/reviews', { method: 'POST', cookie: c, body: { invoice: o.invoice, slug: 'valentino', rating: 5, body: 'দারুণ' } })).status, 200);
  assert.equal((await s.call('/reviews', { method: 'POST', cookie: c, body: { invoice: o.invoice, slug: 'valentino', rating: 4 } })).status, 409);
  const pub = (await s.call('/reviews/valentino')).json; assert.equal(pub.count, 1); assert.equal(pub.reviews[0].author, 'Rahim');
  const ab = await s.call('/n8n/abandoned-carts', { headers: { 'x-api-key': 'k' } }); assert.equal(ab.status, 200); s.close();
});
