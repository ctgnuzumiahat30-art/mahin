// Generates the ingredient illustrations (SVG) used around the bottles.
// Run:  node tools/make-ingredients.mjs
import fs from 'node:fs';

const OUT = new URL('../public/assets/ing/', import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });

/* ---------- helpers ---------- */
const f = (n) => Math.round(n * 100) / 100;
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const stops = (s) => s.map(([o, c, a]) => `<stop offset="${o}" stop-color="${c}"${a != null ? ` stop-opacity="${a}"` : ''}/>`).join('');
const rg = (id, s, a = {}) => `<radialGradient id="${id}" ${Object.entries({ cx: .5, cy: .5, r: .5, ...a }).map(([k, v]) => `${k}="${v}"`).join(' ')}>${stops(s)}</radialGradient>`;
const lg = (id, s, a = {}) => `<linearGradient id="${id}" ${Object.entries({ x1: 0, y1: 0, x2: 0, y2: 1, ...a }).map(([k, v]) => `${k}="${v}"`).join(' ')}>${stops(s)}</linearGradient>`;
const svg = (w, h, defs, body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}"><defs>${defs}</defs>${body}</svg>\n`;
const save = (name, s) => fs.writeFileSync(OUT + name + '.svg', s);
const polar = (cx, cy, r, a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];

/* ---------- citrus slice ---------- */
function citrus(name, { rind, pith = '#f6f3cf', flesh, n = 10 }) {
  const R = rng(name.length * 97 + n);
  const defs = rg('rind', [[0, rind[1]], [1, rind[0]]], { cx: .38, cy: .32, r: .85 }) +
    `<radialGradient id="fl" gradientUnits="userSpaceOnUse" cx="200" cy="200" r="165">${stops([[0, flesh[0]], [.55, flesh[1]], [1, flesh[2]]])}</radialGradient>` +
    rg('gloss', [[0, '#fff', .55], [1, '#fff', 0]], { cx: .3, cy: .25, r: .5 });
  let b = `<circle cx="200" cy="200" r="192" fill="url(#rind)"/><circle cx="200" cy="200" r="176" fill="${pith}"/>`;
  b += `<circle cx="200" cy="200" r="176" fill="none" stroke="#000" stroke-opacity=".06" stroke-width="3"/>`;
  const ri = 24, ro = 160, gap = 0.06;
  for (let i = 0; i < n; i++) {
    const a0 = i * 2 * Math.PI / n + gap, a1 = (i + 1) * 2 * Math.PI / n - gap;
    const [x0, y0] = polar(200, 200, ri, a0), [x1, y1] = polar(200, 200, ro, a0), [x2, y2] = polar(200, 200, ro, a1), [x3, y3] = polar(200, 200, ri, a1);
    b += `<path d="M${f(x0)} ${f(y0)}L${f(x1)} ${f(y1)}A${ro} ${ro} 0 0 1 ${f(x2)} ${f(y2)}L${f(x3)} ${f(y3)}A${ri} ${ri} 0 0 0 ${f(x0)} ${f(y0)}Z" fill="url(#fl)" stroke="${flesh[2]}" stroke-opacity=".55" stroke-width="7" stroke-linejoin="round"/>`;
    const am = (a0 + a1) / 2;
    for (let k = 0; k < 9; k++) {
      const rr = 42 + R() * 104, aa = a0 + (a1 - a0) * (.18 + R() * .64), [vx, vy] = polar(200, 200, rr, aa);
      b += `<ellipse cx="${f(vx)}" cy="${f(vy)}" rx="2.4" ry="${f(7 + R() * 9)}" transform="rotate(${f(am * 180 / Math.PI + 90)} ${f(vx)} ${f(vy)})" fill="#fff" fill-opacity="${f(.16 + R() * .22)}"/>`;
    }
  }
  b += `<circle cx="200" cy="200" r="9" fill="${pith}"/>`;
  b += `<path d="M58 128A160 160 0 0 1 150 50" stroke="#fff" stroke-opacity=".5" stroke-width="9" fill="none" stroke-linecap="round"/><ellipse cx="140" cy="120" rx="120" ry="95" fill="url(#gloss)"/>`;
  save(name, svg(400, 400, defs, b));
}
citrus('bergamot', { rind: ['#3f7416', '#a5cf3d'], pith: '#f5f8d6', flesh: ['#f1fb9a', '#cfe541', '#9dbf1c'], n: 10 });
citrus('lemon', { rind: ['#d49a00', '#ffe65c'], pith: '#fffbe0', flesh: ['#fffbb8', '#ffe45a', '#f3c10a'], n: 9 });
citrus('mandarin', { rind: ['#d9560a', '#ffab3d'], pith: '#fff0d8', flesh: ['#ffd089', '#ffa22e', '#ea7a0c'], n: 9 });
citrus('bloodorange', { rind: ['#9c2410', '#ee7326'], pith: '#fae6d2', flesh: ['#ee5a6c', '#c01832', '#7d0a22'], n: 9 });

/* ---------- pineapple ---------- */
{
  const defs = lg('body', [[0, '#ffd75a'], [.5, '#f0a21a'], [1, '#a65a0a']], { x1: .1, y1: 0, x2: .9, y2: 1 }) +
    lg('leaf', [[0, '#8ccf4a'], [1, '#1f6d2e']]) + `<clipPath id="c"><ellipse cx="200" cy="262" rx="118" ry="150"/></clipPath>` +
    rg('hl', [[0, '#fff', .5], [1, '#fff', 0]], { cx: .3, cy: .25, r: .55 });
  let b = '';
  const leaves = [[-62, .82], [62, .82], [-42, .95], [42, .95], [-20, 1.05], [20, 1.05], [0, 1.18]];
  for (const [ang, s] of leaves) b += `<g transform="translate(200 128) rotate(${ang}) scale(${s})"><path d="M0 0C-26 -50 -18 -118 0 -168C18 -118 26 -50 0 0Z" fill="url(#leaf)" stroke="#16521f" stroke-opacity=".5" stroke-width="2"/><path d="M0 -6C-2 -60 -1 -110 0 -150" stroke="#d6f0a8" stroke-opacity=".5" stroke-width="2" fill="none"/></g>`;
  b += `<ellipse cx="200" cy="262" rx="118" ry="150" fill="url(#body)"/><g clip-path="url(#c)">`;
  const dx = 29, dy = 38;
  for (let i = -6; i <= 6; i++) for (let j = -6; j <= 6; j++) {
    const x = 200 + dx * i, y = 262 + dy * j;
    if ((i + j) % 2 === 0) b += `<path d="M${x} ${y}l${dx} ${dy}M${x} ${y}l${dx} ${-dy}" stroke="#7a3f06" stroke-opacity=".55" stroke-width="3.4" stroke-linecap="round"/>`;
    else b += `<path d="M${x - 7} ${y - 4}L${x} ${y + 6}L${x + 7} ${y - 4}" stroke="#4d2803" stroke-opacity=".8" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  }
  b += `</g><ellipse cx="200" cy="262" rx="118" ry="150" fill="url(#hl)"/>`;
  save('pineapple', svg(400, 440, defs, b));
}

/* ---------- apple ---------- */
{
  const defs = rg('ap', [[0, '#ff8a7a'], [.35, '#e5242e'], [1, '#7d0714']], { cx: .36, cy: .3, r: .78 }) + lg('lf', [[0, '#9ad45a'], [1, '#2a7a2c']]) + lg('st', [[0, '#8a5a30'], [1, '#4a2a12']]);
  const b = `<path d="M200 130C150 88 62 108 56 224C52 322 120 392 200 372C280 392 348 322 344 224C338 108 250 88 200 130Z" fill="url(#ap)"/>` +
    `<path d="M200 130C170 118 150 128 148 150C170 142 188 146 200 160C212 146 230 142 252 150C250 128 230 118 200 130Z" fill="#6b0a14" fill-opacity=".45"/>` +
    `<path d="M92 190C88 150 120 124 150 122" stroke="#fff" stroke-opacity=".55" stroke-width="12" stroke-linecap="round" fill="none"/>` +
    `<ellipse cx="270" cy="300" rx="52" ry="34" fill="#ff7a5a" fill-opacity=".28" transform="rotate(-30 270 300)"/>` +
    `<path d="M200 132C196 100 204 74 224 52" stroke="url(#st)" stroke-width="12" stroke-linecap="round" fill="none"/>` +
    `<path d="M214 78C246 40 298 40 322 66C290 100 244 100 214 78Z" fill="url(#lf)"/><path d="M220 78C250 66 284 62 314 68" stroke="#d9f0b0" stroke-opacity=".6" stroke-width="2.4" fill="none"/>`;
  save('apple', svg(400, 400, defs, b));
}

/* ---------- berries ---------- */
function berries(name, { cols, rows, r, calyx = true, blob = false }) {
  const R = rng(name.length * 31);
  const defs = rg('bb', [[0, cols[0]], [.55, cols[1]], [1, cols[2]]], { cx: .35, cy: .3, r: .8 }) + lg('lf', [[0, '#8ccf4a'], [1, '#1f6d2e']]);
  let list = [];
  rows.forEach((cnt, ri) => { for (let k = 0; k < cnt; k++) list.push([200 + (k - (cnt - 1) / 2) * r * 1.78 + (R() - .5) * 5, 100 + ri * r * 1.55 + (R() - .5) * 4]); });
  let b = '';
  b += `<g transform="translate(200 96)">${[-50, -18, 18, 50, 84, -84].map((a, i) => `<path d="M0 0C-16 -22 -10 -52 0 -68C10 -52 16 -22 0 0Z" fill="url(#lf)" transform="rotate(${a}) scale(${.9 + (i % 2) * .15})"/>`).join('')}</g>`;
  list.sort((a, c) => a[1] - c[1]);
  for (const [x, y] of list) {
    b += `<circle cx="${f(x)}" cy="${f(y + 20)}" r="${r}" fill="url(#bb)"/>`;
    if (!blob) for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 + R(); const [px, py] = polar(x, y + 20, r * .55, a); b += `<circle cx="${f(px)}" cy="${f(py)}" r="${f(r * .3)}" fill="#fff" fill-opacity=".07"/>`; }
    b += `<ellipse cx="${f(x - r * .35)}" cy="${f(y + 20 - r * .42)}" rx="${f(r * .22)}" ry="${f(r * .14)}" fill="#fff" fill-opacity=".6" transform="rotate(-30 ${f(x - r * .35)} ${f(y + 20 - r * .42)})"/>`;
    if (calyx) b += `<path d="M${f(x)} ${f(y + 20 + r * .72)}l-4 -7 4 3 4 -3z" fill="#1c0a2e" fill-opacity=".7"/>`;
  }
  save(name, svg(400, 400, defs, b));
}
berries('raspberry', { cols: ['#ff7088', '#d50f3c', '#6e0620'], rows: [3, 4, 5, 4, 3, 2], r: 28, calyx: false });
berries('blackcurrant', { cols: ['#8a62b8', '#3d2163', '#150a2a'], rows: [2, 3, 3, 2], r: 36, blob: true });

/* ---------- lavender ---------- */
{
  const defs = lg('fl', [[0, '#c9b0ff'], [.55, '#8e6bdc'], [1, '#5a3aa6']], { x1: 0, y1: 0, x2: 1, y2: 1 }) + lg('stem', [[0, '#9cc26a'], [1, '#4d7a30']]);
  const R = rng(7);
  let b = '';
  const spike = (h, off) => {
    let s = `<path d="M150 410C150 330 ${150 + off} 250 ${150 + off * 1.4} ${410 - h}" stroke="url(#stem)" stroke-width="5" fill="none" stroke-linecap="round"/>`;
    const n = 15; for (let i = 0; i < n; i++) {
      const t = i / n, y = 410 - h + t * (h * .62), cx = 150 + off * 1.4 - off * 1.4 * t * .45, sc = .55 + t * .5;
      for (const side of [-1, 1]) s += `<ellipse cx="${f(cx + side * 9 * sc)}" cy="${f(y)}" rx="${f(10 * sc)}" ry="${f(17 * sc)}" transform="rotate(${side * (24 + R() * 8)} ${f(cx + side * 9 * sc)} ${f(y)})" fill="url(#fl)" stroke="#43298a" stroke-opacity=".35" stroke-width="1"/>`;
    }
    s += `<ellipse cx="${150 + off * 1.4}" cy="${410 - h - 6}" rx="8" ry="15" fill="url(#fl)"/>`;
    return s;
  };
  b += `<g transform="rotate(-16 150 410)">${spike(300, -4)}</g><g transform="rotate(15 150 410)">${spike(280, 4)}</g><g>${spike(340, 0)}</g>`;
  b += `<path d="M150 410C120 380 100 340 96 300C126 330 144 366 150 410Z" fill="#6f9a45"/><path d="M150 410C184 384 206 350 212 312C178 340 156 372 150 410Z" fill="#5f8a3a"/>`;
  save('lavender', svg(300, 420, defs, b));
}

/* ---------- flowers (rose / jasmine / violet) ---------- */
function rose(name, c) {
  const defs = [0, 1, 2, 3].map((i) => rg('p' + i, [[0, c[3] ?? '#ffb0bb'], [.45, c[0]], [1, c[1]]], { cx: .5, cy: 1.05, r: 1.1 })).join('');
  let b = `<circle cx="200" cy="200" r="168" fill="${c[2]}" fill-opacity=".25"/>`;
  const layers = [[9, 150, 62, 80], [8, 112, 54, 68], [6, 78, 46, 56], [5, 46, 36, 42]];
  layers.forEach(([n, rad, rx, ry], li) => { for (let i = 0; i < n; i++) { const a = i * 360 / n + li * 21; b += `<ellipse cx="0" cy="${-rad * .62}" rx="${rx}" ry="${ry}" transform="translate(200 200) rotate(${a})" fill="url(#p${li})" stroke="${c[2]}" stroke-opacity=".55" stroke-width="2.2"/>`; } });
  b += `<path d="M200 200m-18 0a18 18 0 1 1 18 18a10 10 0 1 1 -10 -10" stroke="${c[2]}" stroke-opacity=".7" stroke-width="3" fill="none" stroke-linecap="round"/>`;
  save(name, svg(400, 400, defs, b));
}
rose('rose', ['#e8284a', '#8f0e2a', '#5e0618', '#ff9fb0']);
function flower(name, { petal, center, n = 5, len = 120, wid = 34 }) {
  const defs = lg('pt', [[0, petal[0]], [1, petal[1]]]) + rg('ct', [[0, center[0]], [1, center[1]]]);
  let b = '';
  for (let i = 0; i < n; i++) b += `<path d="M0 0C${-wid} ${-len * .35} ${-wid * .8} ${-len * .85} 0 ${-len}C${wid * .8} ${-len * .85} ${wid} ${-len * .35} 0 0Z" transform="translate(150 150) rotate(${i * 360 / n})" fill="url(#pt)" stroke="${petal[2]}" stroke-opacity=".5" stroke-width="1.6"/><path d="M0 -14L0 ${-len * .72}" transform="translate(150 150) rotate(${i * 360 / n})" stroke="${petal[2]}" stroke-opacity=".28" stroke-width="2"/>`;
  b += `<circle cx="150" cy="150" r="17" fill="url(#ct)"/>` + [0, 1, 2, 3, 4, 5].map((k) => { const [x, y] = polar(150, 150, 9, k * 1.05); return `<circle cx="${f(x)}" cy="${f(y)}" r="2.6" fill="#fff" fill-opacity=".6"/>`; }).join('');
  save(name, svg(300, 300, defs, b));
}
flower('jasmine', { petal: ['#ffffff', '#efe6d0', '#b9a97f'], center: ['#ffe27a', '#d9a21a'], n: 6, len: 118, wid: 26 });
flower('violet', { petal: ['#cfa8f2', '#6d3fb8', '#3d1f78'], center: ['#fff3a0', '#e0a21a'], n: 5, len: 112, wid: 40 });

/* ---------- vanilla ---------- */
{
  const defs = lg('pt', [[0, '#fffbe8'], [1, '#e9dcae']]);
  const pod = (dy, k) => `<path d="M24 ${196 + dy}C150 ${176 + dy} 280 ${126 + dy} 396 ${52 + dy + k}" stroke="#241208" stroke-width="24" stroke-linecap="round" fill="none"/><path d="M40 ${190 + dy}C160 ${170 + dy} 280 ${120 + dy} 380 ${52 + dy + k}" stroke="#7b4c2a" stroke-opacity=".65" stroke-width="4" stroke-linecap="round" fill="none"/><path d="M30 ${204 + dy}C150 ${186 + dy} 280 ${136 + dy} 388 ${64 + dy + k}" stroke="#000" stroke-opacity=".35" stroke-width="3" stroke-linecap="round" fill="none"/>`;
  let b = pod(-34, 8) + pod(18, 0) + pod(70, -8);
  let fl = ''; for (let i = 0; i < 6; i++) fl += `<path d="M0 0C-18 -22 -14 -52 0 -64C14 -52 18 -22 0 0Z" transform="translate(310 262) rotate(${i * 60})" fill="url(#pt)" stroke="#c6b57a" stroke-opacity=".6" stroke-width="1.4"/>`;
  b += fl + `<circle cx="310" cy="262" r="9" fill="#e8b830"/>`;
  save('vanilla', svg(420, 340, defs, b));
}

/* ---------- wood ---------- */
function wood(name, { body, face, ring, marks }) {
  const R = rng(name.length * 53);
  const defs = lg('b', [[0, body[0]], [.45, body[1]], [1, body[2]]], { x1: 0, y1: 0, x2: 0, y2: 1 }) + rg('fc', [[0, face[0]], [1, face[1]]], { cx: .5, cy: .5, r: .6 });
  let b = `<g transform="rotate(-20 250 150)">`;
  b += `<path d="M60 96C80 84 120 98 160 92L360 92L360 212L150 214C112 222 78 208 60 200C70 170 54 130 60 96Z" fill="url(#b)"/>`;
  if (marks === 'birch') { for (let i = 0; i < 26; i++) { const x = 80 + R() * 260, y = 98 + R() * 108, w = 10 + R() * 34; b += `<rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="${f(2.4 + R() * 3.4)}" rx="2" fill="#1d1a17" fill-opacity="${f(.45 + R() * .45)}"/>`; } }
  else { for (let i = 0; i < 14; i++) { const y = 100 + i * 8 + R() * 4; b += `<path d="M${f(70 + R() * 30)} ${f(y)}C170 ${f(y + R() * 8 - 4)} 260 ${f(y - R() * 8)} 355 ${f(y + R() * 4)}" stroke="${ring}" stroke-opacity="${f(.22 + R() * .3)}" stroke-width="${f(1.4 + R() * 1.6)}" fill="none"/>`; } }
  b += `<path d="M60 96C80 84 120 98 160 92L360 92" stroke="#fff" stroke-opacity=".28" stroke-width="6" fill="none" stroke-linecap="round"/>`;
  b += `<ellipse cx="360" cy="152" rx="40" ry="60" fill="url(#fc)" stroke="${ring}" stroke-opacity=".6" stroke-width="3"/>`;
  for (let k = 1; k <= 5; k++) b += `<ellipse cx="${360 + k * .7}" cy="152" rx="${f(40 - k * 7)}" ry="${f(60 - k * 10.5)}" fill="none" stroke="${ring}" stroke-opacity="${f(.65 - k * .08)}" stroke-width="1.8"/>`;
  b += `<circle cx="361" cy="152" r="2.6" fill="${ring}"/><path d="M360 152L398 140" stroke="${ring}" stroke-opacity=".4" stroke-width="1.6"/></g>`;
  save(name, svg(440, 330, defs, b));
}
wood('birch', { body: ['#fbf8f0', '#d9d3c6', '#8d8579'], face: ['#f3dcb0', '#d9b27a'], ring: '#8a6236', marks: 'birch' });
wood('sandalwood', { body: ['#e9b684', '#c4864a', '#7d4a22'], face: ['#f3cf9e', '#d79c5c'], ring: '#7b4721', marks: 'grain' });

/* ---------- patchouli / sage leaf ---------- */
{
  const defs = lg('l1', [[0, '#b9dc7c'], [1, '#3d8a3c']], { x1: 0, y1: 0, x2: 1, y2: 1 }) + lg('l2', [[0, '#79b35a'], [1, '#1f5a2a']], { x1: 1, y1: 0, x2: 0, y2: 1 }) + lg('l3', [[0, '#5d9c48'], [1, '#164a22']]);
  const leaf = (id, tf) => `<g transform="${tf}"><path d="M200 400C74 340 46 190 200 24C354 190 326 340 200 400Z" fill="url(#l3)"/><path d="M200 400C74 340 46 190 200 24Z" fill="url(#l1)"/><path d="M200 400C326 340 354 190 200 24Z" fill="url(#l2)"/><path d="M200 396L200 40" stroke="#e5f5c4" stroke-opacity=".7" stroke-width="5" stroke-linecap="round"/>${[0, 1, 2, 3, 4].map((i) => { const y = 330 - i * 58; return `<path d="M200 ${y}C170 ${y - 22} 140 ${y - 30} 106 ${y - 26 + i * 6}M200 ${y}C230 ${y - 22} 260 ${y - 30} 294 ${y - 26 + i * 6}" stroke="#e5f5c4" stroke-opacity=".45" stroke-width="3" fill="none" stroke-linecap="round"/>`; }).join('')}</g>`;
  save('patchouli', svg(400, 420, defs, leaf('a', 'translate(40 18) rotate(-24 200 400) scale(.86)') + leaf('b', 'translate(-8 6) rotate(10 200 400)')));
}

/* ---------- pepper ---------- */
{
  const R = rng(11);
  const defs = rg('pp', [[0, '#8a6448'], [.5, '#4a2e1d'], [1, '#1c100a']], { cx: .36, cy: .3, r: .8 });
  const pts = []; for (let i = 0; i < 17; i++) { const a = R() * 6.28, d = Math.sqrt(R()) * 92; pts.push([150 + Math.cos(a) * d, 150 + Math.sin(a) * d * .85, 20 + R() * 7]); }
  pts.sort((a, c) => a[1] - c[1]);
  let b = ''; for (const [x, y, r] of pts) { b += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="url(#pp)"/>`; for (let k = 0; k < 3; k++) { const a = R() * 6.28; b += `<path d="M${f(x + Math.cos(a) * r * .2)} ${f(y + Math.sin(a) * r * .2)}q${f(r * .4)} ${f(r * .3)} ${f(r * .55)} ${f(-r * .1)}" stroke="#c9a37d" stroke-opacity=".35" stroke-width="1.4" fill="none"/>`; } b += `<ellipse cx="${f(x - r * .34)}" cy="${f(y - r * .4)}" rx="${f(r * .2)}" ry="${f(r * .12)}" fill="#fff" fill-opacity=".45"/>`; }
  save('pepper', svg(300, 300, defs, b));
}

/* ---------- amber ---------- */
{
  const P = [[70, 196], [112, 100], [206, 54], [304, 84], [352, 168], [322, 262], [232, 302], [128, 282]];
  const cols = ['#ffeaa6', '#ffd763', '#f8bb3a', '#ea9a1c', '#c9700a', '#e79a1c', '#fbc54a', '#ffe08a'];
  const defs = rg('amg', [[0, '#fff', .7], [1, '#fff', 0]], { cx: .3, cy: .25, r: .5 });
  let b = '';
  P.forEach((pt, i) => { const q = P[(i + 1) % P.length]; b += `<path d="M205 178L${pt[0]} ${pt[1]}L${q[0]} ${q[1]}Z" fill="${cols[i]}" stroke="#a65a06" stroke-opacity=".45" stroke-width="2.4" stroke-linejoin="round"/>`; });
  b += `<path d="M${P.map((p) => p.join(' ')).join('L')}Z" fill="none" stroke="#8a4206" stroke-opacity=".6" stroke-width="4" stroke-linejoin="round"/>`;
  b += `<path d="M130 112L206 72L286 96" stroke="#fff" stroke-opacity=".8" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><ellipse cx="150" cy="128" rx="70" ry="48" fill="url(#amg)"/>`;
  b += `<path d="M352 236L394 246L380 274Z" fill="#f5b53a" stroke="#a65a06" stroke-opacity=".5"/><path d="M28 278L58 260L66 292Z" fill="#e9a22a" stroke="#a65a06" stroke-opacity=".5"/>`;
  save('amber', svg(410, 330, defs, b));
}

/* ---------- musk pearl ---------- */
{
  const defs = rg('pe', [[0, '#ffffff'], [.4, '#f3e8f1'], [.8, '#d4bfd6'], [1, '#a98fb0']], { cx: .35, cy: .3, r: .8 }) + rg('gl', [[0, '#fff', .8], [1, '#fff', 0]]);
  const star = (x, y, s) => `<path d="M${x} ${y - s}Q${x} ${y} ${x + s} ${y}Q${x} ${y} ${x} ${y + s}Q${x} ${y} ${x - s} ${y}Q${x} ${y} ${x} ${y - s}Z" fill="#fff"/>`;
  const b = `<circle cx="200" cy="200" r="190" fill="url(#gl)"/><circle cx="200" cy="205" r="124" fill="url(#pe)"/><ellipse cx="160" cy="152" rx="46" ry="26" transform="rotate(-30 160 152)" fill="#fff" fill-opacity=".85"/>` +
    `<circle cx="318" cy="118" r="34" fill="url(#pe)"/><ellipse cx="308" cy="106" rx="12" ry="7" transform="rotate(-30 308 106)" fill="#fff" fill-opacity=".85"/><circle cx="82" cy="300" r="26" fill="url(#pe)"/><ellipse cx="75" cy="292" rx="9" ry="5" fill="#fff" fill-opacity=".85"/>` +
    star(330, 270, 18) + star(70, 120, 14) + star(240, 60, 12);
  save('musk', svg(400, 400, defs, b));
}

/* ---------- incense + smoke ---------- */
{
  const defs = `<filter id="bl"><feGaussianBlur stdDeviation="5"/></filter><filter id="bl2"><feGaussianBlur stdDeviation="1.6"/></filter>` + rg('em', [[0, '#fff2b0'], [.4, '#ff9a1a'], [1, '#ff5a00', 0]]);
  const w = (dx, k) => `M170 250C${150 + dx} 210 ${196 + dx * k} 180 ${170 + dx} 140C${146 + dx * k} 100 ${198 + dx} 74 ${176 + dx * .6} 30`;
  const b = `<path d="${w(0, 1)}" stroke="#9a8aa6" stroke-opacity=".62" stroke-width="30" fill="none" stroke-linecap="round" filter="url(#bl)"/><path d="${w(26, -1)}" stroke="#9a8aa6" stroke-opacity=".5" stroke-width="22" fill="none" stroke-linecap="round" filter="url(#bl)"/>` +
    `<path d="${w(0, 1)}" stroke="#e7dfee" stroke-opacity=".95" stroke-width="8" fill="none" stroke-linecap="round" filter="url(#bl2)"/><path d="${w(-28, -1)}" stroke="#e7dfee" stroke-opacity=".8" stroke-width="5.5" fill="none" stroke-linecap="round" filter="url(#bl2)"/>` +
    `<path d="M168 256L108 450" stroke="#7a4524" stroke-width="9" stroke-linecap="round"/><path d="M168 256L108 450" stroke="#c28552" stroke-opacity=".5" stroke-width="2.6" stroke-linecap="round"/><circle cx="169" cy="253" r="20" fill="url(#em)"/><circle cx="169" cy="253" r="6" fill="#fff"/>`;
  save('incense', svg(300, 460, defs, b));
}

/* ---------- marine splash ---------- */
{
  const R = rng(5);
  const defs = lg('wv', [[0, '#f2fdff'], [.4, '#8fdcf2'], [1, '#2a86c0']], { x1: .2, y1: 0, x2: .8, y2: 1 }) + lg('wv2', [[0, '#bff0fb'], [1, '#2a6fb0']]);
  let b = `<path d="M18 318C48 168 170 56 304 78C392 94 440 164 428 250C386 196 322 176 268 196C196 224 146 292 18 318Z" fill="url(#wv)" stroke="#1b6aa5" stroke-opacity=".35" stroke-width="2.4"/>`;
  b += `<path d="M62 280C100 190 190 110 290 110C350 112 396 150 408 200C370 170 318 160 270 176C200 204 150 262 62 280Z" fill="url(#wv2)" fill-opacity=".55"/>`;
  b += `<path d="M96 210C140 140 220 96 300 98" stroke="#fff" stroke-opacity=".75" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M300 98C340 100 380 126 402 170" stroke="#fff" stroke-opacity=".6" stroke-width="4" fill="none" stroke-linecap="round"/>`;
  for (let i = 0; i < 9; i++) b += `<circle cx="${f(240 + R() * 170)}" cy="${f(60 + R() * 100)}" r="${f(10 + R() * 14)}" fill="#fff" fill-opacity="${f(.7 + R() * .25)}"/>`;
  for (let i = 0; i < 16; i++) { const x = 250 + R() * 190, y = 20 + R() * 130, r = 3 + R() * 9; b += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="url(#wv2)" stroke="#fff" stroke-opacity=".9" stroke-width="1.6"/><circle cx="${f(x - r * .3)}" cy="${f(y - r * .3)}" r="${f(r * .25)}" fill="#fff"/>`; }
  save('marine', svg(460, 340, defs, b));
}

/* ---------- droplet + sparkle (decor) ---------- */
save('droplet', svg(60, 80, lg('d', [[0, '#ffffff'], [1, '#9fdcf5']]), `<path d="M30 4C30 4 6 36 6 54a24 24 0 0 0 48 0C54 36 30 4 30 4Z" fill="url(#d)" stroke="#fff" stroke-opacity=".9" stroke-width="2"/><ellipse cx="21" cy="50" rx="5" ry="9" fill="#fff" fill-opacity=".8" transform="rotate(20 21 50)"/>`));
save('sparkle', svg(60, 60, '', `<path d="M30 2Q30 30 58 30Q30 30 30 58Q30 30 2 30Q30 30 30 2Z" fill="#fff"/>`));
save('sparkle-gold', svg(60, 60, lg('g', [[0, '#f7e3b0'], [.5, '#d9b06a'], [1, '#a9783a']], { x2: 1, y2: 1 }), `<path d="M30 2Q30 30 58 30Q30 30 30 58Q30 30 2 30Q30 30 30 2Z" fill="url(#g)"/>`));

console.log('ingredients written to', OUT, fs.readdirSync(OUT).length, 'files');
