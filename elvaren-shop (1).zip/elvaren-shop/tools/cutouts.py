"""Builds transparent bottle cut-outs from the original product photos.
Usage: python3 tools/cutouts.py <folder-with-originals>
Expected original file names are listed in MAP below."""
import sys, os
from PIL import Image
import numpy as np
src = sys.argv[1]
MAP = {'vampire-blood':'3b9f2e8a-4bedb832-d99b-4c1d-aba3-150adbfff0e0.png','valentino':'2cc858a6-a5d36753-ef1a-4330-a839-4b8cb58a3cd8.png',
       'creed-aventus':'2bbe546c-ea5d0b0a-a1fd-4ec9-ae4e-1c996344c61e.png','layton':'3ad7dd83-5e42adad-d59a-4e8b-a751-16b2d0c94f86.png',
       'adg-profumo':'ee6c9dec-8bae933a-fe82-4c40-a2f1-587235ab9b42.png'}
out = os.path.join(os.path.dirname(__file__), '..', 'public', 'assets')
def sm(x,a,b):
    t=np.clip((x-a)/(b-a),0,1); return t*t*(3-2*t)
for k,fn in MAP.items():
    im=Image.open(os.path.join(src,fn)).convert('RGB'); a=np.asarray(im).astype(np.float32)
    alpha=1-sm(a.min(axis=2),214,249); al=np.maximum(alpha,1e-3)[...,None]
    c=np.clip((a-255*(1-al))/al,0,255)
    img=Image.fromarray(np.dstack([c,alpha[...,None]*255]).astype(np.uint8),'RGBA')
    bb=img.getchannel('A').point(lambda p:255 if p>12 else 0).getbbox(); pad=10
    img=img.crop((bb[0]-pad,bb[1]-pad,bb[2]+pad,bb[3]+pad))
    img.save(os.path.join(out,f'{k}.webp'),'WEBP',quality=88,method=6)
    s=img.copy(); s.thumbnail((420,860),Image.LANCZOS); s.save(os.path.join(out,f'{k}-sm.webp'),'WEBP',quality=88,method=6)
    print(k,img.size)
